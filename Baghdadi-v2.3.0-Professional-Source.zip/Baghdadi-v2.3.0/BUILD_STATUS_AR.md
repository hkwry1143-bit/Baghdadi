# حالة إصدار بغدادي 2.3.0

## ما تم إنجازه

تم دمج تحسينات الإشعارات، المكالمات، حالات الرسائل، قائمة الرسالة، الرد بالسحب، ثيمات المحادثة، تكبير الصور وحفظها، البصمة الصوتية، تثبيت وحذف الدردشات، وسجل المكالمات داخل المحادثة.

## التحقق المنفذ

- اجتاز `tools/clean-android-resources.sh`.
- اجتاز `tools/validate-v2.3.0.sh`.
- اجتاز فحص JavaScript لملفي Cloudflare Worker وFirebase Functions.
- اجتازت جميع ملفات XML فحص التحليل.
- لم تظهر أنماط أخطاء صياغة Java في الفحص المحلي؛ يتطلب التجميع الكامل Android SDK واعتماديات Gradle.

## حالة APK في بيئة التسليم

لم تكتمل عملية `assembleDebug` في بيئة التسليم لأن Gradle Wrapper لم يتمكن من الوصول إلى:

`https://services.gradle.org/distributions/gradle-8.9-bin.zip`

وكان الخطأ: `java.net.UnknownHostException: services.gradle.org`.

هذا فشل في تنزيل أداة البناء قبل بدء ترجمة المشروع، وليس خطأ تجميع مؤكداً داخل الشيفرة.

## بناء APK عبر GitHub Actions

المسار الجاهز:

`.github/workflows/android.yml`

بعد رفع المشروع إلى مستودع GitHub:

1. افتح تبويب **Actions**.
2. افتح **Build Baghdadi Android**.
3. اختر **Run workflow**.
4. بعد النجاح نزّل Artifact باسم `Baghdadi-v2.3.0-debug`.

الملف الناتج داخل المهمة:

`Baghdadi-v2.3.0-debug.apk`

## ملاحظات تشغيل مهمة

- انشر Cloudflare Worker الموجود في `push-relay` بعد تحديثه.
- حدّث رابط `PUSH_RELAY_URL` في إعدادات المشروع عند الحاجة.
- استخدم Cloudflare Worker أو Firebase Functions للإشعارات، ولا تشغلهما معاً للرسائل حتى لا تتكرر الإشعارات والعدادات.
- انشر `firestore.rules` الجديدة قبل اختبار حالات التسليم، سجل المكالمات، تثبيت الدردشات وحذفها.
- امنح التطبيق صلاحية الإشعارات، ملء الشاشة للمكالمات، واستثناء تحسين البطارية من شاشة الإعدادات داخل التطبيق.
