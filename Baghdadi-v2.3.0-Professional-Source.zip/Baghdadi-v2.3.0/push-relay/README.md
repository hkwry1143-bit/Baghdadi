# Baghdadi Push Relay

بوابة إشعارات صغيرة تعمل على Cloudflare Workers وتستخدم Firebase Cloud Messaging HTTP v1.

## الحماية

- تتحقق من توقيع Firebase ID Token ومشروعه ووقت صلاحيته.
- تقرأ الرسالة أو المكالمة من Firestore وتتحقق أن صاحب الطلب هو المرسل الحقيقي.
- تجلب رموز أجهزة المستقبل من Firestore؛ لا يقبل المسار رمز جهاز أو UID مستقبل يختاره العميل.
- لا ترسل نص الرسالة داخل FCM، بل إشعاراً عاماً حفاظاً على الخصوصية.
- تدعم إشعار بدء المكالمة وإنهائها لإلغاء الرنين البعيد فوراً.

## الإعداد

```bash
npx wrangler login
npx wrangler deploy
npx wrangler secret put GOOGLE_CLIENT_EMAIL
npx wrangler secret put GOOGLE_PRIVATE_KEY
```

القيم المطلوبة:

- `GOOGLE_PROJECT_ID`: قيمة عامة في `wrangler.toml`.
- `GOOGLE_CLIENT_EMAIL`: سر من حساب خدمة Google المخصص.
- `GOOGLE_PRIVATE_KEY`: سر PKCS#8 كاملاً من ملف حساب الخدمة.

للتطوير المحلي فقط، انسخ `.dev.vars.example` إلى `.dev.vars` واملأه. الملف الحقيقي مستبعد من Git.

## الفحص

```bash
node --check src/index.js
curl https://your-worker.workers.dev
```

يجب أن يعيد طلب GET حالة الخدمة فقط، بينما أي POST من دون Firebase ID Token صالح يُرفض.
