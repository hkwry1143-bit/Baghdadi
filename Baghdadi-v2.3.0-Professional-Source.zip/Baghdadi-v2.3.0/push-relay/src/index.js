const FIREBASE_ISSUER = "https://securetoken.google.com/";
const FIREBASE_JWKS = "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com";
const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";

let cachedJwks = null;
let cachedJwksUntil = 0;
let cachedGoogleToken = null;
let cachedGoogleTokenUntil = 0;

export default {
  async fetch(request, env) {
    if (request.method === "GET") return json({ ok: true, service: "baghdadi-push" });
    if (request.method !== "POST") return json({ ok: false, error: "method_not_allowed" }, 405);

    try {
      const firebaseToken = bearerToken(request.headers.get("Authorization"));
      if (!firebaseToken) return json({ ok: false, error: "unauthorized" }, 401);
      const identity = await verifyFirebaseToken(firebaseToken, env.GOOGLE_PROJECT_ID);
      const body = await readJson(request);
      const googleToken = await serviceAccessToken(env);

      let payload;
      let targetUid;
      if (body.kind === "call") {
        ({ payload, targetUid } = await authorizeCall(identity.sub, body, env, googleToken));
      } else if (body.kind === "call_end") {
        ({ payload, targetUid } = await authorizeCallEnd(identity.sub, body, env, googleToken));
      } else if (body.kind === "message") {
        ({ payload, targetUid } = await authorizeMessage(identity.sub, body, env, googleToken));
      } else {
        return json({ ok: false, error: "invalid_kind" }, 400);
      }

      const tokens = await deviceTokens(targetUid, env, googleToken);
      if (!tokens.length) return json({ ok: true, sent: 0, state: "offline" });

      const results = await Promise.all(tokens.map((token) => sendFcm(token, payload, env, googleToken)));
      const sent = results.filter(Boolean).length;
      return json({ ok: true, sent, state: sent > 0 ? "queued" : "offline" });
    } catch (error) {
      const status = Number(error && error.status) || 500;
      const code = status >= 500 ? "server_error" : String(error.message || "bad_request");
      console.error("push request failed", status, code);
      return json({ ok: false, error: code }, status);
    }
  }
};

async function authorizeCall(uid, body, env, accessToken) {
  const callId = safeId(body.callId);
  const call = await firestoreDocument(`calls/${callId}`, env, accessToken);
  const callerId = field(call, "callerId");
  const calleeId = field(call, "calleeId");
  const status = field(call, "status");
  const createdAt = field(call, "createdAt");
  if (callerId !== uid || !calleeId || !["waiting", "preparing"].includes(status)) deny("forbidden", 403);
  if (createdAt && Date.now() - Date.parse(createdAt) > 15 * 60 * 1000) deny("expired", 409);

  const caller = await firestoreDocument(`users/${uid}`, env, accessToken);
  return {
    targetUid: calleeId,
    payload: {
      kind: "call",
      callId,
      callerId: uid,
      callerName: String(field(caller, "username") || "مستخدم"),
      callerAvatar: pushSafeAvatar(field(caller, "avatar")),
      type: String(field(call, "type") || "audio")
    }
  };
}

async function authorizeCallEnd(uid, body, env, accessToken) {
  const callId = safeId(body.callId);
  const call = await firestoreDocument(`calls/${callId}`, env, accessToken);
  const callerId = field(call, "callerId");
  const calleeId = field(call, "calleeId");
  const status = field(call, "status");
  if (uid !== callerId && uid !== calleeId) deny("forbidden", 403);
  if (!["ended", "rejected", "missed", "failed", "cancelled"].includes(status)) {
    deny("call_not_finished", 409);
  }
  return {
    targetUid: uid === callerId ? calleeId : callerId,
    payload: { kind: "call_end", callId, status: String(status || "ended"), reason: String(field(call, "reason") || "") }
  };
}

async function authorizeMessage(uid, body, env, accessToken) {
  const chatId = safeId(body.chatId);
  const messageId = safeId(body.messageId);
  const [chat, message, sender] = await Promise.all([
    firestoreDocument(`chats/${chatId}`, env, accessToken),
    firestoreDocument(`chats/${chatId}/messages/${messageId}`, env, accessToken),
    firestoreDocument(`users/${uid}`, env, accessToken)
  ]);
  const participants = field(chat, "participants") || [];
  if (field(message, "senderId") !== uid || !participants.includes(uid)) deny("forbidden", 403);
  const targetUid = participants.find((participant) => participant !== uid);
  if (!targetUid) deny("invalid_chat", 400);
  return {
    targetUid,
    payload: {
      kind: "message",
      chatId,
      senderId: uid,
      senderName: String(field(sender, "username") || "مستخدم"),
      senderAvatar: pushSafeAvatar(field(sender, "avatar")),
      messageId,
      messageType: String(field(message, "type") || "text"),
      body: messageSummary(message)
    }
  };
}

async function deviceTokens(uid, env, accessToken) {
  const base = firestoreBase(env);
  const headers = { Authorization: `Bearer ${accessToken}` };
  const response = await fetch(`${base}/users/${encodeURIComponent(uid)}/devices?pageSize=100`, { headers });
  const result = response.ok ? await response.json() : {};
  const tokens = (result.documents || [])
    .filter((document) => field(document, "active") !== false)
    .map((document) => field(document, "token"))
    .filter((token) => typeof token === "string" && token.length > 20);
  if (tokens.length) return [...new Set(tokens)].slice(0, 100);

  const user = await firestoreDocument(`users/${uid}`, env, accessToken);
  const legacy = field(user, "fcmToken");
  return typeof legacy === "string" && legacy.length > 20 ? [legacy] : [];
}

async function sendFcm(token, data, env, accessToken) {
  const id = data.callId || data.messageId || data.chatId;
  const response = await fetch(`https://fcm.googleapis.com/v1/projects/${env.GOOGLE_PROJECT_ID}/messages:send`, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      message: {
        token,
        data,
        android: {
          priority: "HIGH",
          ttl: data.kind === "call" ? "60s" : "2419200s",
          collapse_key: `${data.kind}-${id}`
        }
      }
    })
  });
  if (response.ok) return true;
  console.warn("FCM rejected a device token", response.status);
  return false;
}

async function verifyFirebaseToken(token, projectId) {
  const parts = token.split(".");
  if (parts.length !== 3) deny("unauthorized", 401);
  const header = decodePart(parts[0]);
  const claims = decodePart(parts[1]);
  const now = Math.floor(Date.now() / 1000);
  if (header.alg !== "RS256" || !header.kid || claims.aud !== projectId ||
      claims.iss !== FIREBASE_ISSUER + projectId || !claims.sub ||
      Number(claims.exp) <= now || Number(claims.iat) > now + 60) deny("unauthorized", 401);
  const jwks = await googleJwks();
  const jwk = jwks.keys.find((key) => key.kid === header.kid);
  if (!jwk) deny("unauthorized", 401);
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  const valid = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, base64UrlBytes(parts[2]), new TextEncoder().encode(`${parts[0]}.${parts[1]}`));
  if (!valid) deny("unauthorized", 401);
  return claims;
}

async function googleJwks() {
  if (cachedJwks && Date.now() < cachedJwksUntil) return cachedJwks;
  const response = await fetch(FIREBASE_JWKS);
  if (!response.ok) deny("identity_service_unavailable", 503);
  cachedJwks = await response.json();
  const cacheControl = response.headers.get("Cache-Control") || "";
  const match = cacheControl.match(/max-age=(\d+)/);
  cachedJwksUntil = Date.now() + (match ? Number(match[1]) * 1000 : 60 * 60 * 1000);
  return cachedJwks;
}

async function serviceAccessToken(env) {
  if (cachedGoogleToken && Date.now() < cachedGoogleTokenUntil) return cachedGoogleToken;
  const now = Math.floor(Date.now() / 1000);
  const header = encodePart({ alg: "RS256", typ: "JWT" });
  const claims = encodePart({
    iss: env.GOOGLE_CLIENT_EMAIL,
    scope: "https://www.googleapis.com/auth/datastore https://www.googleapis.com/auth/firebase.messaging",
    aud: GOOGLE_TOKEN_URL,
    iat: now,
    exp: now + 3600
  });
  const unsigned = `${header}.${claims}`;
  const key = await crypto.subtle.importKey("pkcs8", pemBytes(env.GOOGLE_PRIVATE_KEY), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned));
  const assertion = `${unsigned}.${base64Url(new Uint8Array(signature))}`;
  const response = await fetch(GOOGLE_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion })
  });
  if (!response.ok) deny("google_auth_failed", 503);
  const result = await response.json();
  cachedGoogleToken = result.access_token;
  cachedGoogleTokenUntil = Date.now() + Math.max(300, Number(result.expires_in || 3600) - 300) * 1000;
  return cachedGoogleToken;
}

async function firestoreDocument(path, env, accessToken) {
  const response = await fetch(`${firestoreBase(env)}/${path.split("/").map(encodeURIComponent).join("/")}`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (response.status === 404) deny("not_found", 404);
  if (!response.ok) deny("firestore_unavailable", 503);
  return response.json();
}

function firestoreBase(env) {
  return `https://firestore.googleapis.com/v1/projects/${env.GOOGLE_PROJECT_ID}/databases/(default)/documents`;
}

function pushSafeAvatar(value) {
  const avatar = String(value || "");
  return /^https:\/\//i.test(avatar) && avatar.length <= 1500 ? avatar : "";
}

function messageSummary(message) {
  const type = String(field(message, "type") || "text");
  if (type === "text") {
    const text = String(field(message, "text") || "").replace(/\s+/g, " ").trim();
    return text ? text.slice(0, 180) : "رسالة جديدة";
  }
  return ({ image: "🖼 صورة", video: "🎬 فيديو", audio: "🎙 رسالة صوتية", file: "📎 ملف" })[type]
    || "رسالة جديدة";
}

function field(document, name) {
  return decodeValue(document && document.fields && document.fields[name]);
}

function decodeValue(value) {
  if (!value) return null;
  if ("stringValue" in value) return value.stringValue;
  if ("booleanValue" in value) return value.booleanValue;
  if ("integerValue" in value) return Number(value.integerValue);
  if ("doubleValue" in value) return value.doubleValue;
  if ("timestampValue" in value) return value.timestampValue;
  if ("arrayValue" in value) return (value.arrayValue.values || []).map(decodeValue);
  if ("mapValue" in value) return Object.fromEntries(Object.entries(value.mapValue.fields || {}).map(([key, nested]) => [key, decodeValue(nested)]));
  return null;
}

async function readJson(request) {
  const length = Number(request.headers.get("Content-Length") || 0);
  if (length > 16384) deny("payload_too_large", 413);
  try { return await request.json(); } catch (_) { deny("invalid_json", 400); }
}

function bearerToken(value) {
  const match = String(value || "").match(/^Bearer\s+(.+)$/i);
  return match ? match[1] : null;
}

function safeId(value) {
  const id = String(value || "");
  if (!/^[A-Za-z0-9_-]{6,160}$/.test(id)) deny("invalid_id", 400);
  return id;
}

function deny(message, status) {
  const error = new Error(message);
  error.status = status;
  throw error;
}

function decodePart(value) {
  try { return JSON.parse(new TextDecoder().decode(base64UrlBytes(value))); }
  catch (_) { deny("unauthorized", 401); }
}

function encodePart(value) {
  return base64Url(new TextEncoder().encode(JSON.stringify(value)));
}

function base64UrlBytes(value) {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  return Uint8Array.from(atob(padded), (character) => character.charCodeAt(0));
}

function base64Url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function pemBytes(pem) {
  const body = String(pem || "").replace(/\\n/g, "\n").replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g, "");
  return Uint8Array.from(atob(body), (character) => character.charCodeAt(0));
}

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
  });
}
