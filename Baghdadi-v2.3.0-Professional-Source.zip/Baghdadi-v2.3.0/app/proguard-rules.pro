-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# WebRTC M144 initializes its generated JNI bridge from native code during
# JNI_OnLoad. These classes have no ordinary Java call site, so R8 otherwise
# considers JniInit unused and removes it from release builds. The native
# library then terminates the process while looking up org/jni_zero/JniInit.
-keep class org.jni_zero.** { *; }
-keepclasseswithmembers,allowaccessmodification class ** {
    @org.jni_zero.AccessedByNative <fields>;
}
-keepclasseswithmembers,includedescriptorclasses,allowaccessmodification,allowoptimization class ** {
    @org.jni_zero.CalledByNative <methods>;
}
-keepclasseswithmembers,includedescriptorclasses,allowaccessmodification,allowoptimization class ** {
    @org.jni_zero.CalledByNativeUnchecked <methods>;
}
-keepclasseswithmembernames,includedescriptorclasses,allowaccessmodification class ** {
    native <methods>;
}

-keepattributes Signature,*Annotation*
-keep class com.baghdadi.chat.model.** { public <init>(); public <fields>; }
-keepclassmembers class * extends com.google.firebase.messaging.FirebaseMessagingService {
    public <init>();
}
