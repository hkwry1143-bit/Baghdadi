package com.baghdadi.chat.settings;

import android.content.Context;
import android.content.SharedPreferences;

public final class AppPreferences {
    private static final String FILE = "baghdadi_user_settings_v3";
    private static final String KEY_NOTIFICATION_CONTENT = "notification_content";
    private static final String KEY_FULL_SCREEN_CALLS = "full_screen_calls";
    private AppPreferences() {}
    private static SharedPreferences prefs(Context context) { return context.getSharedPreferences(FILE, Context.MODE_PRIVATE); }
    public static boolean showNotificationContent(Context context) { return prefs(context).getBoolean(KEY_NOTIFICATION_CONTENT, true); }
    public static void setShowNotificationContent(Context context, boolean enabled) { prefs(context).edit().putBoolean(KEY_NOTIFICATION_CONTENT, enabled).apply(); }
    public static boolean useFullScreenCalls(Context context) { return prefs(context).getBoolean(KEY_FULL_SCREEN_CALLS, true); }
    public static void setUseFullScreenCalls(Context context, boolean enabled) { prefs(context).edit().putBoolean(KEY_FULL_SCREEN_CALLS, enabled).apply(); }
}
