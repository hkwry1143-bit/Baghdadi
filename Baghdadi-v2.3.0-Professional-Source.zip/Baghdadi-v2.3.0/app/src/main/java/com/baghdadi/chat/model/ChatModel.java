package com.baghdadi.chat.model;
public class ChatModel {
    public String id, peerUid, peerName, peerAvatar, lastMessage, lastMessageType, lastSenderId;
    public long updatedAt;
    public int unread;
    public boolean pinned;
}
