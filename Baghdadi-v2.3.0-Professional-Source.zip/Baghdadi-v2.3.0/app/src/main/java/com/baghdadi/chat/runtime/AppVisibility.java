package com.baghdadi.chat.runtime;

public final class AppVisibility {
    private static volatile boolean foreground;
    private static volatile String currentChatId;
    private AppVisibility() {}
    public static void setForeground(boolean value) { foreground=value; if(!value) currentChatId=null; }
    public static void setCurrentChat(String chatId) { currentChatId=chatId; }
    public static void clearCurrentChat() { currentChatId=null; }
    public static boolean isCurrentConversation(String chatId) { return foreground && chatId!=null && chatId.equals(currentChatId); }
}
