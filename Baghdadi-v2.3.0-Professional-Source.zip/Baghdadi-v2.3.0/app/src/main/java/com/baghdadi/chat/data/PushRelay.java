package com.baghdadi.chat.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.baghdadi.chat.BuildConfig;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

/**
 * Sends authenticated requests to the Cloudflare push relay.
 *
 * Every request is persisted in a tiny local outbox until the relay accepts it. This makes
 * message notifications resilient when a message was queued offline or Android killed the
 * process before the network returned.
 */
public final class PushRelay {
    private static final String TAG = "BaghdadiPush";
    private static final String OUTBOX = "baghdadi_push_outbox_v3";
    private static final ScheduledExecutorService NETWORK = Executors.newScheduledThreadPool(2);
    private static final long[] RETRY_DELAYS_MS = {1_500L, 4_000L, 10_000L, 30_000L};

    private PushRelay() {}

    public static void notifyCall(Context context, String callId) {
        enqueueAndSend(context, payload("call", null, null, callId));
    }

    public static void notifyCallEnd(Context context, String callId) {
        enqueueAndSend(context, payload("call_end", null, null, callId));
    }

    /** Persist a pending message notification before Firestore has acknowledged the write. */
    public static void rememberMessage(Context context, String chatId, String messageId) {
        JSONObject value = payload("message", chatId, messageId, null);
        remember(context.getApplicationContext(), key(value), value);
    }

    public static void notifyMessage(Context context, String chatId, String messageId) {
        enqueueAndSend(context, payload("message", chatId, messageId, null));
    }

    /** Retry all locally persisted relay requests. Safe to call at app/boot startup. */
    public static void retryPending(Context context) {
        Context app = context.getApplicationContext();
        Map<String, ?> all = app.getSharedPreferences(OUTBOX, Context.MODE_PRIVATE).getAll();
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            if (!(entry.getValue() instanceof String)) continue;
            try {
                JSONObject value = new JSONObject((String) entry.getValue());
                authorizeAndPost(app, value, entry.getKey(), 0);
            } catch (Exception ignored) {
                forget(app, entry.getKey());
            }
        }
    }

    private static JSONObject payload(String kind, String chatId, String messageId, String callId) {
        JSONObject json = new JSONObject();
        try {
            json.put("kind", kind);
            if (chatId != null) json.put("chatId", chatId);
            if (messageId != null) json.put("messageId", messageId);
            if (callId != null) json.put("callId", callId);
        } catch (Exception ignored) {
        }
        return json;
    }

    private static void enqueueAndSend(Context context, JSONObject payload) {
        Context app = context.getApplicationContext();
        String key = key(payload);
        remember(app, key, payload);
        authorizeAndPost(app, payload, key, 0);
    }

    private static void authorizeAndPost(Context context, JSONObject payload, String outboxKey, int attempt) {
        if (BuildConfig.PUSH_RELAY_URL == null || BuildConfig.PUSH_RELAY_URL.trim().isEmpty()) return;
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;
        user.getIdToken(false).addOnSuccessListener(result -> {
            String token = result.getToken();
            if (token != null) NETWORK.execute(() -> post(context, user, token, payload, outboxKey, attempt));
        }).addOnFailureListener(error -> Log.w(TAG, "Unable to authorize push request", error));
    }

    private static void post(Context context, FirebaseUser user, String idToken,
                             JSONObject payload, String outboxKey, int attempt) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(BuildConfig.PUSH_RELAY_URL).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10_000);
            connection.setReadTimeout(15_000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization", "Bearer " + idToken);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
            }
            int response = connection.getResponseCode();
            String responseBody = readResponse(connection, response);
            if (response >= 200 && response < 300) {
                forget(context, outboxKey);
                Log.i(TAG, "Push relay accepted " + payload.optString("kind") + ": " + responseBody);
                return;
            }
            Log.w(TAG, "Push relay returned HTTP " + response + ": " + responseBody);
            if (response == HttpURLConnection.HTTP_UNAUTHORIZED && attempt == 0) {
                user.getIdToken(true).addOnSuccessListener(result -> {
                    String refreshed = result.getToken();
                    if (refreshed != null) NETWORK.execute(() ->
                            post(context, user, refreshed, payload, outboxKey, 1));
                }).addOnFailureListener(error -> Log.w(TAG, "Unable to refresh push authorization", error));
            } else if (shouldRetry(payload, response) && attempt < RETRY_DELAYS_MS.length) {
                retry(context, user, idToken, payload, outboxKey, attempt);
            } else if (!shouldRetry(payload, response)) {
                // Permanent validation/permission failure. Do not keep a poisoned outbox record.
                forget(context, outboxKey);
            }
        } catch (Exception error) {
            Log.w(TAG, "Push relay request failed", error);
            if (attempt < RETRY_DELAYS_MS.length) {
                retry(context, user, idToken, payload, outboxKey, attempt);
            }
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static boolean shouldRetry(JSONObject payload, int response) {
        if (response == 429 || response >= 500) return true;
        // A queued Firestore message may not be visible to the worker yet when connectivity resumes.
        return "message".equals(payload.optString("kind")) && (response == 404 || response == 409);
    }

    private static void retry(Context context, FirebaseUser user, String idToken,
                              JSONObject payload, String outboxKey, int attempt) {
        long delay = RETRY_DELAYS_MS[Math.min(attempt, RETRY_DELAYS_MS.length - 1)];
        NETWORK.schedule(() -> post(context, user, idToken, payload, outboxKey, attempt + 1),
                delay, TimeUnit.MILLISECONDS);
    }

    private static String key(JSONObject payload) {
        String kind = payload.optString("kind", "event");
        String id = payload.optString("messageId");
        if (id.trim().isEmpty()) id = payload.optString("callId");
        if (id.trim().isEmpty()) id = payload.optString("chatId");
        return kind + "_" + id;
    }

    private static void remember(Context context, String key, JSONObject payload) {
        context.getSharedPreferences(OUTBOX, Context.MODE_PRIVATE)
                .edit().putString(key, payload.toString()).apply();
    }

    private static void forget(Context context, String key) {
        context.getSharedPreferences(OUTBOX, Context.MODE_PRIVATE)
                .edit().remove(key).apply();
    }

    private static String readResponse(HttpURLConnection connection, int status) {
        InputStream stream = null;
        try {
            stream = status >= 200 && status < 400
                    ? connection.getInputStream() : connection.getErrorStream();
            if (stream == null) return "";
            StringBuilder body = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null && body.length() < 512) body.append(line);
            }
            return body.length() > 512 ? body.substring(0, 512) : body.toString();
        } catch (Exception ignored) {
            return "";
        }
    }
}
