package com.baghdadi.chat.calls;

import com.baghdadi.chat.data.FirebaseCore;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import java.util.HashMap;
import java.util.Map;

public final class ActiveCallRegistry {
    private static final long LEASE_MS=3*60*1000L;
    public interface ClaimCallback{void onClaimed();void onBusy();void onError(Exception error);}
    private ActiveCallRegistry(){}
    public static void checkPeerAvailableAndReserve(String myUid,String peerUid,String callId,ClaimCallback callback){
        if(myUid==null||peerUid==null||callId==null){callback.onError(new IllegalArgumentException("missing call identity"));return;}
        DocumentReference mine=FirebaseCore.firestore().collection("active_calls").document(myUid),theirs=FirebaseCore.firestore().collection("active_calls").document(peerUid);long now=System.currentTimeMillis();
        FirebaseCore.firestore().runTransaction(tx->{DocumentSnapshot p=tx.get(theirs);if(activeOther(p,callId,now))throw new BusyException();DocumentSnapshot m=tx.get(mine);if(activeOther(m,callId,now))throw new BusyException();tx.set(mine,state(callId,peerUid,"calling",now));return null;})
            .addOnSuccessListener(v->callback.onClaimed()).addOnFailureListener(e->{if(e instanceof BusyException||e.getCause() instanceof BusyException)callback.onBusy();else callback.onError(e);});
    }
    public static void claimIncoming(String myUid,String peerUid,String callId,ClaimCallback callback){if(myUid==null||peerUid==null||callId==null){callback.onError(new IllegalArgumentException("missing call identity"));return;}DocumentReference mine=FirebaseCore.firestore().collection("active_calls").document(myUid);long now=System.currentTimeMillis();FirebaseCore.firestore().runTransaction(tx->{DocumentSnapshot m=tx.get(mine);if(activeOther(m,callId,now))throw new BusyException();tx.set(mine,state(callId,peerUid,"ringing",now));return null;}).addOnSuccessListener(v->callback.onClaimed()).addOnFailureListener(e->{if(e instanceof BusyException||e.getCause() instanceof BusyException)callback.onBusy();else callback.onError(e);});}
    public static Task<Void> updateState(String uid,String callId,String peerUid,String status){if(uid==null||callId==null)return Tasks.forResult(null);return FirebaseCore.firestore().collection("active_calls").document(uid).set(state(callId,peerUid,status,System.currentTimeMillis()));}
    public static void release(String uid,String callId){if(uid==null||callId==null)return;DocumentReference ref=FirebaseCore.firestore().collection("active_calls").document(uid);FirebaseCore.firestore().runTransaction(tx->{DocumentSnapshot s=tx.get(ref);if(s.exists()&&callId.equals(s.getString("callId")))tx.delete(ref);return null;});}
    private static boolean activeOther(DocumentSnapshot s,String id,long now){if(s==null||!s.exists())return false;String stored=s.getString("callId");Long expires=s.getLong("expiresAtMillis");return stored!=null&&!stored.equals(id)&&expires!=null&&expires>now;}
    private static Map<String,Object> state(String callId,String peerUid,String status,long now){Map<String,Object> m=new HashMap<>();m.put("callId",callId);m.put("peerUid",peerUid==null?"":peerUid);m.put("status",status);m.put("expiresAtMillis",now+LEASE_MS);m.put("updatedAt",FieldValue.serverTimestamp());return m;}
    private static final class BusyException extends RuntimeException{BusyException(){super("busy");}}
}
