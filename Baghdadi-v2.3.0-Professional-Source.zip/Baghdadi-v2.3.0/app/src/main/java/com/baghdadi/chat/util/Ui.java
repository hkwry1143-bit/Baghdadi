package com.baghdadi.chat.util;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.PathInterpolator;
import android.widget.*;

public final class Ui {
    private Ui() {}
    public static int dp(Context c,float v){return (int)(v*c.getResources().getDisplayMetrics().density+0.5f);}
    public static TextView text(Context c,String s,float size,int color){TextView v=new TextView(c);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));v.setGravity(Gravity.CENTER_VERTICAL|Gravity.END);return v;}
    public static GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dpStatic(r));return g;}
    public static GradientDrawable outlined(int color,int strokeColor,float radius){GradientDrawable g=bg(color,radius);g.setStroke((int)dpStatic(1),strokeColor);return g;}
    private static float dpStatic(float v){return v*android.content.res.Resources.getSystem().getDisplayMetrics().density;}
    public static GradientDrawable gradient(){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(124,58,237),Color.rgb(8,145,178)});g.setCornerRadius(dpStatic(16));return g;}
    public static GradientDrawable gradientCircle(){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(139,92,246),Color.rgb(14,165,233)});g.setShape(GradientDrawable.OVAL);return g;}
    public static GradientDrawable screenGradient(){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(4,7,18),Color.rgb(15,20,42),Color.rgb(22,13,48)});g.setCornerRadius(0);return g;}
    public static GradientDrawable elevatedPanel(float radius){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(20,28,49),Color.rgb(12,18,34)});
        g.setCornerRadius(dpStatic(radius));
        g.setStroke((int)dpStatic(1),Color.argb(48,165,180,252));
        return g;
    }
    public static Drawable ripple(Drawable content){return new RippleDrawable(ColorStateList.valueOf(Color.argb(64,255,255,255)),content,null);}
    public static Drawable gradientRipple(){
        return ripple(gradient());
    }
    public static Button button(Context c,String label){
        Button b=new Button(c);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        b.setPadding(dp(c,8),0,dp(c,8),0);
        b.setMinHeight(dp(c,44));
        b.setSoundEffectsEnabled(true);
        pressFeedback(b);
        return b;
    }
    public static ImageButton imageButton(Context c,int drawable,String description,int surface,float radius){
        ImageButton button=new ImageButton(c);
        button.setImageResource(drawable);
        button.setContentDescription(description);
        button.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        button.setPadding(dp(c,9),dp(c,9),dp(c,9),dp(c,9));
        button.setBackground(ripple(bg(surface,radius)));
        button.setSoundEffectsEnabled(true);
        button.setFocusable(true);
        pressFeedback(button);
        return button;
    }
    public static void enter(View view,long delay){
        view.setAlpha(0f);
        view.setTranslationY(dp(view.getContext(),10));
        view.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(220)
                .setInterpolator(new PathInterpolator(.2f,0f,0f,1f)).start();
    }
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    public static void pressFeedback(View view){
        view.setOnTouchListener((v,event)->{
            if(!v.isEnabled()) return false;
            if(event.getAction()==MotionEvent.ACTION_DOWN){
                v.animate().scaleX(0.965f).scaleY(0.965f).setDuration(65).start();
            }else if(event.getAction()==MotionEvent.ACTION_UP||event.getAction()==MotionEvent.ACTION_CANCEL){
                v.animate().scaleX(1f).scaleY(1f).setDuration(105).start();
                if(event.getAction()==MotionEvent.ACTION_UP){
                    v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                }
            }
            return false;
        });
    }
    public static void margin(View v,int l,int t,int r,int b,Context c){if(v.getLayoutParams() instanceof ViewGroup.MarginLayoutParams){ViewGroup.MarginLayoutParams p=(ViewGroup.MarginLayoutParams)v.getLayoutParams();p.setMargins(dp(c,l),dp(c,t),dp(c,r),dp(c,b));v.setLayoutParams(p);}}
}
