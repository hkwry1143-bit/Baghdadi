package com.baghdadi.chat.service;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.baghdadi.chat.calls.ActiveCallRegistry;
import com.baghdadi.chat.calls.CallLogWriter;
import com.baghdadi.chat.data.FirebaseCore;
import com.baghdadi.chat.data.PushRelay;
import com.baghdadi.chat.util.AppSounds;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;

public final class CallActionReceiver extends BroadcastReceiver {
    public static final String ACTION_REJECT="com.baghdadi.chat.REJECT_CALL";
    public static final String ACTION_END="com.baghdadi.chat.END_CALL";
    @Override public void onReceive(Context context,Intent intent){
        String callId=intent.getStringExtra("callId");if(callId==null||callId.trim().isEmpty())return;
        NotificationManager manager=context.getSystemService(NotificationManager.class);if(manager!=null)manager.cancel(notificationId(callId));context.stopService(new Intent(context,CallForegroundService.class));
        FirebaseCore.init(context);FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();if(user==null)return;PendingResult pending=goAsync();boolean rejected=ACTION_REJECT.equals(intent.getAction());String status=rejected?"rejected":"ended";if(rejected)AppSounds.playHangupTone(context.getApplicationContext());
        FirebaseCore.firestore().collection("calls").document(callId).update("status",status,"reason",rejected?"rejected":"hangup","endedAt",FieldValue.serverTimestamp(),"updatedAt",FieldValue.serverTimestamp()).addOnCompleteListener(task->{ActiveCallRegistry.release(user.getUid(),callId);if(task.isSuccessful()){PushRelay.notifyCallEnd(context,callId);CallLogWriter.write(callId);}pending.finish();});
    }
    public static int notificationId(String callId){return 0x43000000|(callId.hashCode()&0x00ffffff);}
}
