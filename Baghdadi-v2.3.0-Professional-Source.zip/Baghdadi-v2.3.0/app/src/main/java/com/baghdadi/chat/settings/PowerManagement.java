package com.baghdadi.chat.settings;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import java.util.ArrayList;
import java.util.List;

/** Helpers for Android and OEM background-execution settings. User approval is always required. */
public final class PowerManagement {
    private PowerManagement() {}

    public static boolean isIgnoringOptimizations(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager manager = context.getSystemService(PowerManager.class);
        return manager != null && manager.isIgnoringBatteryOptimizations(context.getPackageName());
    }

    public static void requestIgnoreOptimizations(Activity activity) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || isIgnoringOptimizations(activity)) {
            openBackgroundSettings(activity);
            return;
        }
        try {
            activity.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + activity.getPackageName())));
        } catch (Exception ignored) {
            try {
                activity.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception second) {
                openBackgroundSettings(activity);
            }
        }
    }

    /** Opens an OEM auto-start/background screen when present, otherwise the app details screen. */
    public static void openBackgroundSettings(Activity activity) {
        for (Intent intent : manufacturerIntents(activity)) {
            try {
                if (intent.resolveActivity(activity.getPackageManager()) != null) {
                    activity.startActivity(intent);
                    return;
                }
            } catch (Exception ignored) {
            }
        }
        try {
            activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + activity.getPackageName())));
        } catch (Exception ignored) {
            activity.startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private static List<Intent> manufacturerIntents(Context context) {
        List<Intent> intents = new ArrayList<>();
        add(intents, "com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity");
        add(intents, "com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity");
        add(intents, "com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity");
        add(intents, "com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity");
        add(intents, "com.oplus.safecenter", "com.oplus.safecenter.startupapp.StartupAppListActivity");
        add(intents, "com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity");
        add(intents, "com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity");
        add(intents, "com.asus.mobilemanager", "com.asus.mobilemanager.entry.FunctionActivity");
        Intent battery = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
        intents.add(battery);
        return intents;
    }

    private static void add(List<Intent> intents, String packageName, String className) {
        intents.add(new Intent().setComponent(new ComponentName(packageName, className)));
    }
}
