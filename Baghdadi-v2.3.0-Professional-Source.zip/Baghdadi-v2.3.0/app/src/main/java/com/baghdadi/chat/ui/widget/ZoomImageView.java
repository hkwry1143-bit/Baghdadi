package com.baghdadi.chat.ui.widget;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

public final class ZoomImageView extends ImageView {
    private final Matrix matrix=new Matrix();private final ScaleGestureDetector scaleDetector;private final GestureDetector gestureDetector;private float scale=1f,lastX,lastY;
    public ZoomImageView(Context context){super(context);setScaleType(ScaleType.MATRIX);scaleDetector=new ScaleGestureDetector(context,new ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(ScaleGestureDetector d){float next=clamp(scale*d.getScaleFactor(),1f,5f),factor=next/scale;scale=next;matrix.postScale(factor,factor,d.getFocusX(),d.getFocusY());setImageMatrix(matrix);return true;}});gestureDetector=new GestureDetector(context,new GestureDetector.SimpleOnGestureListener(){@Override public boolean onDoubleTap(MotionEvent e){resetZoom(scale>1.2f?1f:2.5f,e.getX(),e.getY());return true;}});}
    @Override public void setImageDrawable(Drawable drawable){super.setImageDrawable(drawable);post(()->resetZoom(1f,getWidth()/2f,getHeight()/2f));}
    @Override public boolean onTouchEvent(MotionEvent e){scaleDetector.onTouchEvent(e);gestureDetector.onTouchEvent(e);switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:lastX=e.getX();lastY=e.getY();getParent().requestDisallowInterceptTouchEvent(true);break;case MotionEvent.ACTION_MOVE:if(!scaleDetector.isInProgress()&&scale>1f){matrix.postTranslate(e.getX()-lastX,e.getY()-lastY);setImageMatrix(matrix);lastX=e.getX();lastY=e.getY();}break;case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:getParent().requestDisallowInterceptTouchEvent(false);break;}return true;}
    private void resetZoom(float target,float px,float py){matrix.reset();Drawable d=getDrawable();if(d==null||getWidth()==0||getHeight()==0||d.getIntrinsicWidth()<=0||d.getIntrinsicHeight()<=0)return;float fit=Math.min((float)getWidth()/d.getIntrinsicWidth(),(float)getHeight()/d.getIntrinsicHeight()),dx=(getWidth()-d.getIntrinsicWidth()*fit)/2f,dy=(getHeight()-d.getIntrinsicHeight()*fit)/2f;matrix.postScale(fit,fit);matrix.postTranslate(dx,dy);scale=1f;if(target>1f){matrix.postScale(target,target,px,py);scale=target;}setImageMatrix(matrix);}
    private static float clamp(float v,float min,float max){return Math.max(min,Math.min(max,v));}
}
