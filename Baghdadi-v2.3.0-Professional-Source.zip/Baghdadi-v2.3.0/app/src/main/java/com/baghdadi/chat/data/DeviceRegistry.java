package com.baghdadi.chat.data;

import android.content.Context;
import android.os.Build;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.SetOptions;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class DeviceRegistry {
    private DeviceRegistry() {}

    public static void register(Context context, String uid, String token) {
        if (uid == null || token == null || token.trim().isEmpty()) return;
        Map<String, Object> device = new HashMap<>();
        device.put("token", token);
        device.put("platform", "android");
        device.put("manufacturer", Build.MANUFACTURER);
        device.put("model", Build.MODEL);
        device.put("sdk", Build.VERSION.SDK_INT);
        device.put("active", true);
        device.put("updatedAt", FieldValue.serverTimestamp());
        FirebaseCore.firestore()
                .collection("users").document(uid)
                .collection("devices").document(deviceId(context))
                .set(device, SetOptions.merge());
        // يبقى الحقل المفرد متوافقاً مع وظيفة الإشعارات المنشورة في الإصدارات السابقة.
        FirebaseCore.firestore().collection("users").document(uid)
                .set(java.util.Collections.singletonMap("fcmToken", token), SetOptions.merge());
    }

    public static void unregister(Context context, String uid) {
        if (uid == null) return;
        FirebaseCore.firestore()
                .collection("users").document(uid)
                .collection("devices").document(deviceId(context))
                .update("active", false, "updatedAt", FieldValue.serverTimestamp());
    }

    private static String deviceId(Context context) {
        android.content.SharedPreferences preferences = context.getSharedPreferences(
                "baghdadi_device", Context.MODE_PRIVATE);
        String id = preferences.getString("notification_device_id", null);
        if (id != null) return id;
        id = UUID.randomUUID().toString().replace("-", "");
        preferences.edit().putString("notification_device_id", id).apply();
        return id;
    }
}
