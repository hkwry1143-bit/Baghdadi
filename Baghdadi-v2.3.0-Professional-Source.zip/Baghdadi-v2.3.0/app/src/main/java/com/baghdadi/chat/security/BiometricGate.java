package com.baghdadi.chat.security;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;

public final class BiometricGate {
    public static final int REQUEST_DEVICE_CREDENTIAL = 9107;

    public interface Callback {
        void onSuccess();
        void onFailure(String message);
    }

    private BiometricGate() {}

    public static boolean isAvailable(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            BiometricManager manager = activity.getSystemService(BiometricManager.class);
            return manager != null && manager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
        }
        KeyguardManager keyguard = (KeyguardManager) activity.getSystemService(Context.KEYGUARD_SERVICE);
        return keyguard != null && keyguard.isDeviceSecure();
    }

    public static Intent credentialIntent(Activity activity) {
        KeyguardManager keyguard = (KeyguardManager) activity.getSystemService(Context.KEYGUARD_SERVICE);
        if (keyguard == null) return null;
        return keyguard.createConfirmDeviceCredentialIntent(
                "فتح بغدادي", "استخدم قفل الجهاز للمتابعة");
    }

    public static void authenticate(Activity activity, Callback callback) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            Intent intent = credentialIntent(activity);
            if (intent == null) callback.onFailure("لم يتم إعداد بصمة أو قفل آمن على الجهاز.");
            else activity.startActivityForResult(intent, REQUEST_DEVICE_CREDENTIAL);
            return;
        }

        BiometricPrompt.Builder builder = new BiometricPrompt.Builder(activity)
                .setTitle("فتح بغدادي")
                .setSubtitle("أكد هويتك بالبصمة")
                .setDescription("تبقى محادثاتك مقفلة على هذا الجهاز");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setDeviceCredentialAllowed(true);
        } else {
            builder.setNegativeButton("إلغاء", activity.getMainExecutor(), (dialog, which) ->
                    callback.onFailure("تم إلغاء التحقق."));
        }
        BiometricPrompt prompt = builder.build();
        prompt.authenticate(new CancellationSignal(), activity.getMainExecutor(),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        callback.onSuccess();
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, CharSequence errString) {
                        callback.onFailure(String.valueOf(errString));
                    }
                });
    }
}
