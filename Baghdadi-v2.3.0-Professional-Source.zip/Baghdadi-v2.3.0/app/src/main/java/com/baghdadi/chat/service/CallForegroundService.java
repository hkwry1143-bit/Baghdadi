package com.baghdadi.chat.service;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import com.baghdadi.chat.R;
import com.baghdadi.chat.ui.CallActivity;

public final class CallForegroundService extends Service {
    public static final String ACTION_START = "com.baghdadi.chat.START_ACTIVE_CALL";
    public static final String ACTION_STOP = "com.baghdadi.chat.STOP_ACTIVE_CALL";
    private static final int NOTIFICATION_ID = 8001;

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            NotificationChannels.ensureAll(this);
        } catch (RuntimeException ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            return startCallNotification(intent, startId);
        } catch (RuntimeException exception) {
            try {
                stopForeground(true);
            } catch (RuntimeException ignored) {
            }
            stopSelfResult(startId);
            return START_NOT_STICKY;
        }
    }

    private int startCallNotification(Intent intent, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopForeground(true);
            stopSelfResult(startId);
            return START_NOT_STICKY;
        }
        String callId = intent == null ? null : intent.getStringExtra("callId");
        String peerName = intent == null ? null : intent.getStringExtra("peerName");
        boolean video = intent != null && intent.getBooleanExtra("video", false);

        Intent openIntent = new Intent(this, CallActivity.class);
        if (intent != null && intent.getExtras() != null) openIntent.putExtras(intent.getExtras());
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open = PendingIntent.getActivity(
                this, 8001, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());

        Intent endIntent = new Intent(this, CallActionReceiver.class)
                .setAction(CallActionReceiver.ACTION_END)
                .putExtra("callId", callId);
        PendingIntent end = PendingIntent.getBroadcast(
                this, 8002, endIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, NotificationChannels.ACTIVE_CALL)
                : new Notification.Builder(this);
        Notification notification = builder
                .setSmallIcon(R.drawable.ic_stat_baghdadi)
                .setColor(Color.rgb(124, 58, 237))
                .setContentTitle(peerName == null ? "مكالمة بغدادي" : peerName)
                .setContentText(video ? "مكالمة فيديو جارية" : "مكالمة صوتية جارية")
                .setCategory(Notification.CATEGORY_CALL)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat_baghdadi),
                        "إنهاء", end).build())
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            if (video) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA;
            startForeground(NOTIFICATION_ID, notification, type);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static int immutableFlag() {
        return PendingIntent.FLAG_IMMUTABLE;
    }
}
