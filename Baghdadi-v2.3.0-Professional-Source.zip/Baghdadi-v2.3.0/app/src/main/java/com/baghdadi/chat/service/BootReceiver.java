package com.baghdadi.chat.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.baghdadi.chat.data.DeviceRegistry;
import com.baghdadi.chat.data.FirebaseCore;
import com.baghdadi.chat.data.PushRelay;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.messaging.FirebaseMessaging;

public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        FirebaseCore.init(context); NotificationChannels.ensureAll(context); PushRelay.retryPending(context);
        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser(); if(user==null)return;
        PendingResult pending=goAsync();
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{
            if(task.isSuccessful()&&task.getResult()!=null)DeviceRegistry.register(context,user.getUid(),task.getResult());
            pending.finish();
        });
    }
}
