package com.baghdadi.chat;

import android.app.Application;
import com.baghdadi.chat.data.FirebaseCore;
import com.baghdadi.chat.service.NotificationChannels;

public final class BaghdadiApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseCore.init(this);
        NotificationChannels.ensureAll(this);
    }
}
