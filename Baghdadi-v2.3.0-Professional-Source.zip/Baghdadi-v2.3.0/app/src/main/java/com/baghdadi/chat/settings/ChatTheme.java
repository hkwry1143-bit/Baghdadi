package com.baghdadi.chat.settings;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;

public final class ChatTheme {
    private static final String FILE="baghdadi_chat_themes_v2";
    public final int first,second; public final boolean gradient;
    private ChatTheme(int first,int second,boolean gradient){this.first=first;this.second=second;this.gradient=gradient;}
    public static ChatTheme load(Context context,String chatId){SharedPreferences p=context.getSharedPreferences(FILE,Context.MODE_PRIVATE);String k=key(chatId);return new ChatTheme(p.getInt(k+"_first",Color.rgb(76,29,149)),p.getInt(k+"_second",Color.rgb(8,145,178)),p.getBoolean(k+"_gradient",true));}
    public static void save(Context context,String chatId,int first,int second,boolean gradient){String k=key(chatId);context.getSharedPreferences(FILE,Context.MODE_PRIVATE).edit().putInt(k+"_first",first).putInt(k+"_second",second).putBoolean(k+"_gradient",gradient).apply();}
    public static void reset(Context context,String chatId){String k=key(chatId);context.getSharedPreferences(FILE,Context.MODE_PRIVATE).edit().remove(k+"_first").remove(k+"_second").remove(k+"_gradient").apply();}
    private static String key(String id){return "chat_"+(id==null?"default":Integer.toHexString(id.hashCode()));}
    public GradientDrawable screen(){int a=blend(first,Color.BLACK,.72f),b=blend(second,Color.BLACK,.82f);return drawable(gradient?new int[]{a,b}:new int[]{a,a},0);}
    public GradientDrawable outgoing(float radius){int a=blend(first,Color.BLACK,.20f),b=blend(second,Color.BLACK,.35f);return drawable(gradient?new int[]{a,b}:new int[]{a,a},radius);}
    public GradientDrawable incoming(float radius){int a=blend(first,Color.BLACK,.68f),b=blend(second,Color.BLACK,.72f);return drawable(gradient?new int[]{a,b}:new int[]{a,a},radius);}
    public GradientDrawable panel(float radius){int a=blend(first,Color.BLACK,.77f),b=blend(second,Color.BLACK,.80f);return drawable(gradient?new int[]{a,b}:new int[]{a,a},radius);}
    public int accent(){return blend(first,second,.45f);} public int secondaryAccent(){return second;}
    private static GradientDrawable drawable(int[] colors,float radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors);d.setCornerRadius(radius);return d;}
    public static int blend(int from,int to,float ratio){float i=1f-ratio;return Color.rgb(Math.round(Color.red(from)*i+Color.red(to)*ratio),Math.round(Color.green(from)*i+Color.green(to)*ratio),Math.round(Color.blue(from)*i+Color.blue(to)*ratio));}
}
