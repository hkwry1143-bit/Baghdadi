package com.baghdadi.chat.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.baghdadi.chat.R;
import com.baghdadi.chat.BuildConfig;
import com.baghdadi.chat.data.FirebaseCore;
import com.baghdadi.chat.data.PushRelay;
import com.baghdadi.chat.calls.ActiveCallRegistry;
import com.baghdadi.chat.calls.CallLogWriter;
import com.baghdadi.chat.service.CallActionReceiver;
import com.baghdadi.chat.service.CallForegroundService;
import com.baghdadi.chat.util.Ui;
import com.baghdadi.chat.util.AppSounds;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.ListenerRegistration;
import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.Camera1Enumerator;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraEnumerator;
import org.webrtc.CameraVideoCapturer;
import org.webrtc.DataChannel;
import org.webrtc.DefaultVideoDecoderFactory;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.MediaStreamTrack;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RtpReceiver;
import org.webrtc.RtpTransceiver;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceTextureHelper;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoCapturer;
import org.webrtc.VideoSource;
import org.webrtc.VideoTrack;
import org.webrtc.audio.AudioDeviceModule;
import org.webrtc.audio.JavaAudioDeviceModule;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class CallActivity extends Activity {
    private static final int REQUEST_MEDIA = 101;
    private static final int BG = Color.rgb(5, 7, 17);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final List<IceCandidate> pendingRemoteCandidates = new ArrayList<>();

    private String callId;
    private String role;
    private String type;
    private String peerUid;
    private String peerName;
    private String peerAvatar;
    private DocumentReference callRef;

    private PeerConnectionFactory factory;
    private PeerConnection peerConnection;
    private EglBase egl;
    private AudioDeviceModule audioDeviceModule;
    private AudioSource audioSource;
    private VideoSource videoSource;
    private SurfaceTextureHelper surfaceTextureHelper;
    private SurfaceViewRenderer localView;
    private SurfaceViewRenderer remoteView;
    private MediaStream localStream;
    private AudioTrack localAudio;
    private VideoTrack localVideo;
    private CameraVideoCapturer cameraCapturer;

    private ListenerRegistration callRegistration;
    private ListenerRegistration candidatesRegistration;
    private MediaPlayer ringtonePlayer;
    private MediaPlayer ringbackPlayer;
    private Runnable timerRunnable;
    private Runnable ringTimeoutRunnable;
    private AudioManager audioManager;

    private TextView stateView;
    private TextView timerView;
    private TextView nameView;
    private LinearLayout incomingControls;
    private LinearLayout activeControls;
    private FrameLayout callerStage;
    private ImageView callerImage;
    private View pulseOuter;
    private View pulseInner;
    private ImageButton muteButton;
    private ImageButton cameraButton;
    private ImageButton speakerButton;
    private Runnable avatarPulseRunnable;
    private boolean pulseExpanded;

    private boolean accepted;
    private boolean ending;
    private boolean mediaCreated;
    private boolean localTracksAdded;
    private boolean remoteDescriptionReady;
    private boolean answerApplied;
    private boolean microphoneEnabled = true;
    private boolean cameraEnabled = true;
    private boolean speakerEnabled;
    private boolean foregroundServiceStarted;
    private boolean cleanedUp;
    private boolean initializing;
    private long connectedAt;
    private long lastRegistryRefresh;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }

        FirebaseCore.init(this);
        callId = getIntent().getStringExtra("callId");
        role = safe(getIntent().getStringExtra("role"), "callee");
        type = safe(getIntent().getStringExtra("type"), "audio");
        peerUid = getIntent().getStringExtra("peerUid");
        peerName = safe(getIntent().getStringExtra("peerName"), "مستخدم");
        peerAvatar = safe(getIntent().getStringExtra("peerAvatar"), "");
        if (callId == null || !("caller".equals(role) || "callee".equals(role))) {
            finish();
            return;
        }
        if (BuildConfig.DEBUG && getIntent().getBooleanExtra("uiPreview", false)) {
            buildUi();
            applyPeerAvatar();
            return;
        }
        callRef = FirebaseCore.firestore().collection("calls").document(callId);
        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        if (notificationManager != null) {
            notificationManager.cancel(CallActionReceiver.notificationId(callId));
        }

        if ("callee".equals(role)) {
            String uid = FirebaseCore.auth().getCurrentUser() == null ? null
                    : FirebaseCore.auth().getCurrentUser().getUid();
            ActiveCallRegistry.claimIncoming(uid, peerUid, callId, new ActiveCallRegistry.ClaimCallback() {
                @Override public void onClaimed() { startCallUi(); }
                @Override public void onBusy() {
                    AppSounds.playHangupTone(getApplicationContext());
                    callRef.update("status", "rejected", "reason", "busy",
                            "endedAt", FieldValue.serverTimestamp(),
                            "updatedAt", FieldValue.serverTimestamp())
                            .addOnCompleteListener(task -> {
                                PushRelay.notifyCallEnd(getApplicationContext(), callId);
                                CallLogWriter.write(callId);
                                finish();
                            });
                }
                @Override public void onError(Exception error) {
                    ending = true;
                    AppSounds.playHangupTone(getApplicationContext());
                    callRef.update("status", "rejected", "reason", "registry_error",
                            "endedAt", FieldValue.serverTimestamp(),
                            "updatedAt", FieldValue.serverTimestamp())
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    PushRelay.notifyCallEnd(getApplicationContext(), callId);
                                }
                                CallLogWriter.write(callId);
                                cleanup();
                                finish();
                            });
                }
            });
        } else {
            startCallUi();
        }
    }

    private void startCallUi() {
        if (isFinishing() || isDestroyed()) return;
        try {
            buildUi();
            loadPeerIdentity();
            if (!hasMediaPermissions()) requestMediaPermissions();
            else initializeCall();
        } catch (RuntimeException | LinkageError error) {
            showInitializationFailure(error);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(Ui.screenGradient());

        if ("video".equals(type)) {
            remoteView = new SurfaceViewRenderer(this);
            remoteView.setVisibility(View.INVISIBLE);
            root.addView(remoteView, new FrameLayout.LayoutParams(-1, -1));

            FrameLayout localFrame = new FrameLayout(this);
            localFrame.setPadding(Ui.dp(this, 2), Ui.dp(this, 2), Ui.dp(this, 2), Ui.dp(this, 2));
            localFrame.setBackground(Ui.outlined(Color.argb(180, 15, 23, 42),
                    Color.argb(180, 196, 181, 253), 20));
            localView = new SurfaceViewRenderer(this);
            localFrame.addView(localView, new FrameLayout.LayoutParams(-1, -1));
            FrameLayout.LayoutParams localParams = new FrameLayout.LayoutParams(
                    Ui.dp(this, 112), Ui.dp(this, 158), Gravity.TOP | Gravity.END);
            localParams.setMargins(0, Ui.dp(this, 82), Ui.dp(this, 16), 0);
            root.addView(localFrame, localParams);
        }

        LinearLayout overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.CENTER_HORIZONTAL);
        overlay.setPadding(Ui.dp(this, 16), Ui.dp(this, 24), Ui.dp(this, 16), Ui.dp(this, 18));

        TextView callKind = Ui.text(this,
                "video".equals(type) ? "مكالمة فيديو مشفّرة" : "مكالمة صوتية مشفّرة",
                12, Color.rgb(216, 211, 242));
        callKind.setGravity(Gravity.CENTER);
        callKind.setBackground(Ui.outlined(Color.argb(130, 30, 41, 66),
                Color.argb(150, 124, 58, 237), 24));
        overlay.addView(callKind, new LinearLayout.LayoutParams(Ui.dp(this, 190), Ui.dp(this, 38)));

        View upperSpacer = new View(this);
        overlay.addView(upperSpacer, new LinearLayout.LayoutParams(1, 0, 1));

        callerStage = new FrameLayout(this);
        pulseOuter = new View(this);
        pulseOuter.setBackground(Ui.outlined(Color.argb(26, 124, 58, 237),
                Color.argb(90, 129, 140, 248), 120));
        FrameLayout.LayoutParams outerParams = new FrameLayout.LayoutParams(
                Ui.dp(this, 214), Ui.dp(this, 214), Gravity.CENTER);
        callerStage.addView(pulseOuter, outerParams);
        pulseInner = new View(this);
        pulseInner.setBackground(Ui.outlined(Color.argb(35, 14, 165, 233),
                Color.argb(125, 34, 211, 238), 100));
        FrameLayout.LayoutParams innerParams = new FrameLayout.LayoutParams(
                Ui.dp(this, 180), Ui.dp(this, 180), Gravity.CENTER);
        callerStage.addView(pulseInner, innerParams);

        TextView avatarLetter = Ui.text(this,
                peerName.substring(0, 1).toUpperCase(java.util.Locale.getDefault()),
                48, Color.WHITE);
        avatarLetter.setGravity(Gravity.CENTER);
        avatarLetter.setTypeface(null, android.graphics.Typeface.BOLD);
        avatarLetter.setBackground(Ui.gradientCircle());
        avatarLetter.setElevation(Ui.dp(this, 8));
        FrameLayout.LayoutParams letterParams = new FrameLayout.LayoutParams(
                Ui.dp(this, 148), Ui.dp(this, 148), Gravity.CENTER);
        callerStage.addView(avatarLetter, letterParams);

        callerImage = new ImageView(this);
        callerImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        callerImage.setClipToOutline(true);
        callerImage.setElevation(Ui.dp(this, 10));
        callerStage.addView(callerImage, new FrameLayout.LayoutParams(letterParams));
        overlay.addView(callerStage, new LinearLayout.LayoutParams(
                Ui.dp(this, 224), Ui.dp(this, 224)));

        nameView = Ui.text(this, peerName, 27, Color.WHITE);
        nameView.setGravity(Gravity.CENTER);
        nameView.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(-1, Ui.dp(this, 48));
        nameParams.topMargin = Ui.dp(this, 8);
        overlay.addView(nameView, nameParams);

        stateView = Ui.text(this,
                "caller".equals(role) ? "بانتظار اتصال الطرف الآخر بالإنترنت…" : "مكالمة واردة",
                14, Color.rgb(183, 194, 220));
        stateView.setGravity(Gravity.CENTER);
        stateView.setBackground(Ui.bg(Color.argb(95, 10, 15, 29), 18));
        overlay.addView(stateView, new LinearLayout.LayoutParams(-1, Ui.dp(this, 38)));

        timerView = Ui.text(this, "00:00", 16, Color.rgb(196, 181, 253));
        timerView.setGravity(Gravity.CENTER);
        timerView.setVisibility(View.INVISIBLE);
        timerView.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        overlay.addView(timerView, new LinearLayout.LayoutParams(-1, Ui.dp(this, 34)));

        View lowerSpacer = new View(this);
        overlay.addView(lowerSpacer, new LinearLayout.LayoutParams(1, 0, 1));

        activeControls = new LinearLayout(this);
        activeControls.setGravity(Gravity.CENTER);
        activeControls.setPadding(Ui.dp(this, 7), Ui.dp(this, 7), Ui.dp(this, 7), Ui.dp(this, 7));
        activeControls.setBackground(Ui.outlined(Color.argb(190, 15, 23, 42),
                Color.argb(120, 71, 85, 113), 28));
        muteButton = control(R.drawable.ic_mic_active, "كتم الميكروفون", true);
        cameraButton = control(R.drawable.ic_video_call, "إيقاف الكاميرا", false);
        speakerButton = control(R.drawable.ic_speaker_off, "تشغيل مكبر الصوت", true);
        ImageButton switchCamera = control(R.drawable.ic_switch_camera, "تبديل الكاميرا", false);
        switchCamera.setPadding(Ui.dp(this, 15), Ui.dp(this, 15), Ui.dp(this, 15), Ui.dp(this, 15));
        ImageButton hangup = control(R.drawable.ic_call_end, "إنهاء المكالمة", true);
        activeControls.addView(muteButton, controlParams());
        if ("video".equals(type)) {
            activeControls.addView(cameraButton, controlParams());
            activeControls.addView(switchCamera, controlParams());
        }
        activeControls.addView(speakerButton, controlParams());
        activeControls.addView(hangup, controlParams());
        activeControls.setVisibility("callee".equals(role) ? View.GONE : View.VISIBLE);
        overlay.addView(activeControls, new LinearLayout.LayoutParams(-1, Ui.dp(this, 82)));

        incomingControls = new LinearLayout(this);
        incomingControls.setGravity(Gravity.CENTER);
        ImageButton acceptButton = control(R.drawable.ic_call_accept, "قبول المكالمة", true);
        ImageButton rejectButton = control(R.drawable.ic_call_end, "رفض المكالمة", true);
        incomingControls.addView(actionColumn(acceptButton, "قبول"));
        incomingControls.addView(actionColumn(rejectButton, "رفض"));
        incomingControls.setVisibility("callee".equals(role) ? View.VISIBLE : View.GONE);
        overlay.addView(incomingControls, new LinearLayout.LayoutParams(-1, Ui.dp(this, 96)));

        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        Ui.enter(callKind, 0);
        Ui.enter(callerStage, 80);
        Ui.enter(nameView, 140);
        Ui.enter(stateView, 180);
        startAvatarPulse();

        muteButton.setOnClickListener(v -> toggleMicrophone());
        cameraButton.setOnClickListener(v -> toggleCamera());
        speakerButton.setOnClickListener(v -> toggleSpeaker());
        switchCamera.setOnClickListener(v -> {
            if (cameraCapturer != null) cameraCapturer.switchCamera(null);
        });
        hangup.setOnClickListener(v -> endCall(true));
        acceptButton.setOnClickListener(v -> acceptIncoming());
        rejectButton.setOnClickListener(v -> rejectIncoming());
    }

    private ImageButton control(int drawable, String description, boolean artworkHasCircle) {
        ImageButton button = Ui.imageButton(this, drawable, description,
                artworkHasCircle ? Color.TRANSPARENT : Color.rgb(35, 45, 69), 30);
        button.setPadding(Ui.dp(this, artworkHasCircle ? 2 : 11),
                Ui.dp(this, artworkHasCircle ? 2 : 11),
                Ui.dp(this, artworkHasCircle ? 2 : 11),
                Ui.dp(this, artworkHasCircle ? 2 : 11));
        return button;
    }

    private LinearLayout actionColumn(ImageButton button, String label) {
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER);
        column.addView(button, new LinearLayout.LayoutParams(Ui.dp(this, 68), Ui.dp(this, 68)));
        TextView caption = Ui.text(this, label, 13, Color.WHITE);
        caption.setGravity(Gravity.CENTER);
        column.addView(caption, new LinearLayout.LayoutParams(-1, Ui.dp(this, 28)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                Ui.dp(this, 112), Ui.dp(this, 96));
        params.setMargins(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        column.setLayoutParams(params);
        return column;
    }

    private LinearLayout.LayoutParams controlParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                Ui.dp(this, 58), Ui.dp(this, 58));
        params.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
        return params;
    }

    private void loadPeerIdentity() {
        applyPeerAvatar();
        if (peerUid == null || peerUid.trim().isEmpty()) return;
        FirebaseCore.firestore().collection("users").document(peerUid).get()
                .addOnSuccessListener(snapshot -> {
                    if (!snapshot.exists() || ending) return;
                    String loadedName = snapshot.getString("username");
                    String loadedAvatar = snapshot.getString("avatar");
                    if (loadedName != null && !loadedName.trim().isEmpty()) {
                        peerName = loadedName;
                        if (nameView != null) nameView.setText(loadedName);
                    }
                    if (loadedAvatar != null && !loadedAvatar.trim().isEmpty()) {
                        peerAvatar = loadedAvatar;
                        applyPeerAvatar();
                    }
                });
    }

    private void applyPeerAvatar() {
        if (callerImage == null) return;
        callerImage.setContentDescription("صورة " + peerName);
        if (peerAvatar == null || peerAvatar.trim().isEmpty()) {
            callerImage.setImageResource(R.drawable.ic_default_avatar);
            return;
        }
        com.bumptech.glide.Glide.with(this)
                .load(peerAvatar)
                .circleCrop()
                .placeholder(R.drawable.ic_default_avatar)
                .error(R.drawable.ic_default_avatar)
                .into(callerImage);
    }

    private void startAvatarPulse() {
        avatarPulseRunnable = new Runnable() {
            @Override public void run() {
                if (ending || callerStage == null || callerStage.getVisibility() != View.VISIBLE) return;
                pulseExpanded = !pulseExpanded;
                float stageScale = pulseExpanded ? 1.025f : 1f;
                callerStage.animate().scaleX(stageScale).scaleY(stageScale).setDuration(900).start();
                if (pulseOuter != null) pulseOuter.animate()
                        .scaleX(pulseExpanded ? 1.10f : 1f)
                        .scaleY(pulseExpanded ? 1.10f : 1f)
                        .alpha(pulseExpanded ? .38f : .72f).setDuration(900).start();
                if (pulseInner != null) pulseInner.animate()
                        .scaleX(pulseExpanded ? 1.045f : 1f)
                        .scaleY(pulseExpanded ? 1.045f : 1f)
                        .alpha(pulseExpanded ? .70f : 1f).setDuration(900).start();
                mainHandler.postDelayed(this, 920);
            }
        };
        mainHandler.post(avatarPulseRunnable);
    }

    private boolean hasMediaPermissions() {
        boolean microphone = checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
        boolean camera = !"video".equals(type)
                || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        return microphone && camera;
    }

    private void requestMediaPermissions() {
        if ("video".equals(type)) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA},
                    REQUEST_MEDIA);
        } else {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode != REQUEST_MEDIA) return;
        if (hasMediaPermissions()) {
            initializeCall();
        } else {
            ending = true;
            AppSounds.playHangupTone(getApplicationContext());
            String finalStatus = "callee".equals(role) ? "rejected" : "ended";
            callRef.update("status", finalStatus, "reason", "permission_denied",
                    "endedAt", FieldValue.serverTimestamp(),
                    "updatedAt", FieldValue.serverTimestamp())
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            PushRelay.notifyCallEnd(getApplicationContext(), callId);
                        }
                        CallLogWriter.write(callId);
                        cleanup();
                        toast("يجب منح الميكروفون والكاميرا لإجراء المكالمة.");
                        finish();
                    });
        }
    }

    private void initializeCall() {
        if (initializing || factory != null || ending) return;
        initializing = true;
        try {
            configureAudio();
            PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions.builder(this)
                            .setEnableInternalTracer(false)
                            .createInitializationOptions());
            audioDeviceModule = JavaAudioDeviceModule.builder(this)
                    .setUseHardwareAcousticEchoCanceler(false)
                    .setUseHardwareNoiseSuppressor(false)
                    .setStopRecordingOnMute(false)
                    .setAudioRecordErrorCallback(new JavaAudioDeviceModule.AudioRecordErrorCallback() {
                        @Override public void onWebRtcAudioRecordInitError(String error) {
                            reportMediaError("تعذر تهيئة ميكروفون المكالمة", error);
                        }
                        @Override public void onWebRtcAudioRecordStartError(
                                JavaAudioDeviceModule.AudioRecordStartErrorCode code, String error) {
                            reportMediaError("تعذر تشغيل ميكروفون المكالمة", code + ":" + error);
                        }
                        @Override public void onWebRtcAudioRecordError(String error) {
                            reportMediaError("حدث خطأ في ميكروفون المكالمة", error);
                        }
                    })
                    .setAudioTrackErrorCallback(new JavaAudioDeviceModule.AudioTrackErrorCallback() {
                        @Override public void onWebRtcAudioTrackInitError(String error) {
                            reportMediaError("تعذر تهيئة صوت المكالمة", error);
                        }
                        @Override public void onWebRtcAudioTrackStartError(
                                JavaAudioDeviceModule.AudioTrackStartErrorCode code, String error) {
                            reportMediaError("تعذر تشغيل صوت المكالمة", code + ":" + error);
                        }
                        @Override public void onWebRtcAudioTrackError(String error) {
                            reportMediaError("حدث خطأ في صوت المكالمة", error);
                        }
                    })
                    .createAudioDeviceModule();
            PeerConnectionFactory.Builder builder = PeerConnectionFactory.builder()
                    .setAudioDeviceModule(audioDeviceModule);
            if ("video".equals(type)) {
                if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
                    throw new IllegalStateException("لا توجد كاميرا متاحة");
                }
                egl = EglBase.create();
                builder.setVideoEncoderFactory(new DefaultVideoEncoderFactory(
                                egl.getEglBaseContext(), true, true))
                        .setVideoDecoderFactory(new DefaultVideoDecoderFactory(
                                egl.getEglBaseContext()));
            }
            factory = builder.createPeerConnectionFactory();

            if (remoteView != null) {
                remoteView.init(egl.getEglBaseContext(), null);
                remoteView.setMirror(false);
                remoteView.setEnableHardwareScaler(true);
                localView.init(egl.getEglBaseContext(), null);
                localView.setMirror(true);
                localView.setEnableHardwareScaler(true);
                localView.setZOrderMediaOverlay(true);
            }
            createPeerConnection();
            listenToCall();
            listenToRemoteCandidates();

            if ("caller".equals(role)) {
                createLocalMedia();
                addLocalTracks();
                createOffer();
                scheduleMissedTimeout();
            } else {
                markRingingIfWaiting();
                if (getIntent().getBooleanExtra("autoAccept", false)) acceptIncoming();
                else startRingtone();
            }
        } catch (RuntimeException | LinkageError error) {
            initializing = false;
            showInitializationFailure(error);
        }
    }

    private void configureAudio() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager == null) return;
        audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
        speakerEnabled = "video".equals(type);
        audioManager.setSpeakerphoneOn(speakerEnabled);
        audioManager.requestAudioFocus(
                focusChange -> {}, AudioManager.STREAM_VOICE_CALL, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
        speakerButton.setImageResource(speakerEnabled
                ? R.drawable.ic_speaker_on : R.drawable.ic_speaker_off);
    }

    private void createPeerConnection() {
        List<PeerConnection.IceServer> iceServers = new ArrayList<>();
        iceServers.add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302")
                .createIceServer());
        iceServers.add(PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302")
                .createIceServer());

        PeerConnection.RTCConfiguration config = new PeerConnection.RTCConfiguration(iceServers);
        config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;
        config.continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY;
        config.tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.ENABLED;
        config.bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE;
        peerConnection = factory.createPeerConnection(config, new PeerObserver());
        if (peerConnection == null) throw new IllegalStateException("تعذر إنشاء قناة WebRTC");
    }

    private void createLocalMedia() {
        if (mediaCreated) return;
        mediaCreated = true;
        localStream = factory.createLocalMediaStream("BAGHDADI_" + UUID.randomUUID());
        MediaConstraints audioConstraints = new MediaConstraints();
        audioConstraints.optional.add(new MediaConstraints.KeyValuePair("googEchoCancellation", "true"));
        audioConstraints.optional.add(new MediaConstraints.KeyValuePair("googNoiseSuppression", "true"));
        audioConstraints.optional.add(new MediaConstraints.KeyValuePair("googAutoGainControl", "true"));
        audioConstraints.optional.add(new MediaConstraints.KeyValuePair("googHighpassFilter", "true"));
        audioSource = factory.createAudioSource(audioConstraints);
        localAudio = factory.createAudioTrack("AUDIO_" + UUID.randomUUID(), audioSource);
        localStream.addTrack(localAudio);

        if ("video".equals(type)) {
            cameraCapturer = createCameraCapturer();
            if (cameraCapturer == null) throw new IllegalStateException("لا توجد كاميرا متاحة");
            videoSource = factory.createVideoSource(cameraCapturer.isScreencast());
            surfaceTextureHelper = SurfaceTextureHelper.create(
                    "BaghdadiCamera", egl.getEglBaseContext());
            cameraCapturer.initialize(
                    surfaceTextureHelper, this, videoSource.getCapturerObserver());
            localVideo = factory.createVideoTrack("VIDEO_" + UUID.randomUUID(), videoSource);
            localVideo.addSink(localView);
            localStream.addTrack(localVideo);
            cameraCapturer.startCapture(1280, 720, 30);
        }
    }

    private CameraVideoCapturer createCameraCapturer() {
        CameraEnumerator enumerator = null;
        if (Camera2Enumerator.isSupported(this)) {
            try {
                enumerator = new Camera2Enumerator(this);
                CameraVideoCapturer camera = findCamera(enumerator);
                if (camera != null) return camera;
            } catch (RuntimeException ignored) {
                enumerator = null;
            }
        }
        try {
            enumerator = new Camera1Enumerator(true);
        } catch (RuntimeException ignored) {
            return null;
        }
        return findCamera(enumerator);
    }

    private CameraVideoCapturer findCamera(CameraEnumerator enumerator) {
        for (String name : enumerator.getDeviceNames()) {
            if (enumerator.isFrontFacing(name)) {
                CameraVideoCapturer capturer = enumerator.createCapturer(name, new CameraEvents());
                if (capturer != null) return capturer;
            }
        }
        for (String name : enumerator.getDeviceNames()) {
            CameraVideoCapturer capturer = enumerator.createCapturer(name, new CameraEvents());
            if (capturer != null) return capturer;
        }
        return null;
    }

    private void addLocalTracks() {
        if (localTracksAdded || localStream == null) return;
        localTracksAdded = true;
        for (AudioTrack track : localStream.audioTracks) {
            peerConnection.addTrack(track, Collections.singletonList("BAGHDADI_STREAM"));
        }
        for (VideoTrack track : localStream.videoTracks) {
            peerConnection.addTrack(track, Collections.singletonList("BAGHDADI_STREAM"));
        }
    }

    private void createOffer() {
        setCallState("بانتظار اتصال الطرف الآخر بالإنترنت…");
        peerConnection.createOffer(new SdpCallback() {
            @Override
            public void onCreateSuccess(SessionDescription description) {
                protectWebRtcCallback(() -> peerConnection.setLocalDescription(new SdpCallback() {
                    @Override
                    public void onSetSuccess() {
                        protectWebRtcCallback(() -> {
                            Map<String, Object> offer = new HashMap<>();
                            offer.put("type", description.type.canonicalForm());
                            offer.put("sdp", description.description);
                            callRef.update(
                                    "offer", offer,
                                    "callerState", "ready",
                                    "updatedAt", FieldValue.serverTimestamp());
                        });
                    }
                }, description));
            }

            @Override
            public void onCreateFailure(String error) {
                failCall("تعذر إنشاء الاتصال: " + error);
            }
        }, offerConstraints());
    }

    private void acceptIncoming() {
        if (accepted || ending) return;
        accepted = true;
        stopRinging();
        incomingControls.setVisibility(View.GONE);
        activeControls.setVisibility(View.VISIBLE);
        activeControls.setAlpha(0f);
        activeControls.animate().alpha(1f).setDuration(260).start();
        setCallState("جارٍ قبول المكالمة…");
        try {
            createLocalMedia();
            addLocalTracks();
        } catch (RuntimeException | LinkageError error) {
            showInitializationFailure(error);
            return;
        }
        String uid = FirebaseCore.auth().getCurrentUser() == null ? null : FirebaseCore.auth().getCurrentUser().getUid();
        ActiveCallRegistry.updateState(uid, callId, peerUid, "accepted");
        callRef.update(
                "status", "accepted",
                "calleeState", "accepted",
                "acceptedAt", FieldValue.serverTimestamp(),
                "updatedAt", FieldValue.serverTimestamp())
                .addOnSuccessListener(unused -> {
                    loadOfferAndAnswer();
                });
    }

    @SuppressWarnings("unchecked")
    private void loadOfferAndAnswer() {
        if (!accepted || remoteDescriptionReady || ending) return;
        callRef.get().addOnSuccessListener(snapshot -> {
            Map<String, Object> offer = (Map<String, Object>) snapshot.get("offer");
            if (offer == null) {
                setCallState("تم القبول — بانتظار تجهيز المتصل…");
                return;
            }
            SessionDescription description = new SessionDescription(
                    SessionDescription.Type.fromCanonicalForm(String.valueOf(offer.get("type"))),
                    String.valueOf(offer.get("sdp")));
            peerConnection.setRemoteDescription(new SdpCallback() {
                @Override
                public void onSetSuccess() {
                    protectWebRtcCallback(() -> {
                        remoteDescriptionReady = true;
                        drainRemoteCandidates();
                        createAnswer();
                    });
                }

                @Override
                public void onSetFailure(String error) {
                    failCall("تعذر قراءة الاتصال: " + error);
                }
            }, description);
        });
    }

    private void createAnswer() {
        peerConnection.createAnswer(new SdpCallback() {
            @Override
            public void onCreateSuccess(SessionDescription description) {
                protectWebRtcCallback(() -> peerConnection.setLocalDescription(new SdpCallback() {
                    @Override
                    public void onSetSuccess() {
                        protectWebRtcCallback(() -> {
                            Map<String, Object> answer = new HashMap<>();
                            answer.put("type", description.type.canonicalForm());
                            answer.put("sdp", description.description);
                            callRef.update(
                                    "answer", answer,
                                    "answerReadyAt", FieldValue.serverTimestamp(),
                                    "updatedAt", FieldValue.serverTimestamp())
                                    .addOnSuccessListener(unused ->
                                            setCallState("تم الرد — جارٍ إنشاء الاتصال…"));
                        });
                    }
                }, description));
            }

            @Override
            public void onCreateFailure(String error) {
                failCall("تعذر الرد: " + error);
            }
        }, offerConstraints());
    }

    @SuppressWarnings("unchecked")
    private void listenToCall() {
        callRegistration = callRef.addSnapshotListener((snapshot, error) -> {
            if (error != null || snapshot == null || !snapshot.exists() || ending) return;
            String status = snapshot.getString("status");
            if ("ended".equals(status) || "rejected".equals(status)
                    || "missed".equals(status) || "expired".equals(status)) {
                if ("rejected".equals(status)) {
                    AppSounds.playHangupTone(getApplicationContext());
                    if ("busy".equals(snapshot.getString("reason"))) toast("الشخص في مكالمة أخرى.");
                    else toast("تم رفض المكالمة.");
                } else if (("missed".equals(status) || "expired".equals(status)) && "caller".equals(role)) {
                    toast("لم يتم الرد على المكالمة.");
                }
                CallLogWriter.write(callId);
                endCall(false);
                return;
            }

            if ("caller".equals(role)) {
                if ("waiting".equals(status) || "preparing".equals(status)) {
                    stopRingbackOnly();
                    setCallState("بانتظار اتصال الطرف الآخر بالإنترنت…");
                } else if ("ringing".equals(status)) {
                    setCallState("يرن الآن لدى الطرف الآخر…");
                    startRingback();
                } else if ("accepted".equals(status)) {
                    stopRingbackOnly();
                    setCallState("تم الرد — جارٍ إنشاء الاتصال…");
                }

                Map<String, Object> answer = (Map<String, Object>) snapshot.get("answer");
                if (answer != null && !answerApplied) applyAnswer(answer);
            } else if (accepted && !remoteDescriptionReady && snapshot.get("offer") != null) {
                loadOfferAndAnswer();
            }
        });
    }

    private void applyAnswer(Map<String, Object> answer) {
        answerApplied = true;
        SessionDescription description = new SessionDescription(
                SessionDescription.Type.fromCanonicalForm(String.valueOf(answer.get("type"))),
                String.valueOf(answer.get("sdp")));
        peerConnection.setRemoteDescription(new SdpCallback() {
            @Override
            public void onSetSuccess() {
                protectWebRtcCallback(() -> {
                    remoteDescriptionReady = true;
                    drainRemoteCandidates();
                    setCallState("جارٍ فحص أفضل مسار للشبكة…");
                });
            }

            @Override
            public void onSetFailure(String error) {
                answerApplied = false;
                failCall("تعذر تثبيت الرد: " + error);
            }
        }, description);
    }

    private void listenToRemoteCandidates() {
        String collection = "caller".equals(role) ? "calleeCandidates" : "callerCandidates";
        candidatesRegistration = callRef.collection(collection).addSnapshotListener((snapshot, error) -> {
            if (error != null || snapshot == null || peerConnection == null) return;
            for (DocumentChange change : snapshot.getDocumentChanges()) {
                if (change.getType() != DocumentChange.Type.ADDED) continue;
                Map<String, Object> data = change.getDocument().getData();
                Object line = data.get("sdpMLineIndex");
                if (!(line instanceof Number) || data.get("candidate") == null) continue;
                IceCandidate candidate = new IceCandidate(
                        String.valueOf(data.get("sdpMid")),
                        ((Number) line).intValue(),
                        String.valueOf(data.get("candidate")));
                if (remoteDescriptionReady) peerConnection.addIceCandidate(candidate);
                else pendingRemoteCandidates.add(candidate);
            }
        });
    }

    private void drainRemoteCandidates() {
        if (peerConnection == null) return;
        for (IceCandidate candidate : pendingRemoteCandidates) {
            peerConnection.addIceCandidate(candidate);
        }
        pendingRemoteCandidates.clear();
    }

    private MediaConstraints offerConstraints() {
        MediaConstraints constraints = new MediaConstraints();
        constraints.mandatory.add(new MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"));
        constraints.mandatory.add(new MediaConstraints.KeyValuePair(
                "OfferToReceiveVideo", String.valueOf("video".equals(type))));
        return constraints;
    }

    private void markRingingIfWaiting() {
        callRef.get().addOnSuccessListener(snapshot -> {
            String status = snapshot.getString("status");
            if ("waiting".equals(status) || "preparing".equals(status)) {
                callRef.update(
                        "status", "ringing",
                        "deliveredAt", FieldValue.serverTimestamp(),
                        "updatedAt", FieldValue.serverTimestamp());
            } else if ("ended".equals(status) || "rejected".equals(status)
                    || "expired".equals(status)) {
                if ("rejected".equals(status)) AppSounds.playHangupTone(getApplicationContext());
                CallLogWriter.write(callId);
                endCall(false);
            }
        });
    }

    private void startForegroundCallService() {
        if (foregroundServiceStarted || ending) return;
        Intent service = new Intent(this, CallForegroundService.class)
                .setAction(CallForegroundService.ACTION_START)
                .putExtra("callId", callId)
                .putExtra("role", role)
                .putExtra("type", type)
                .putExtra("peerUid", peerUid)
                .putExtra("peerName", peerName)
                .putExtra("peerAvatar", peerAvatar)
                .putExtra("video", "video".equals(type));
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
            foregroundServiceStarted = true;
        } catch (RuntimeException ignored) {
            foregroundServiceStarted = false;
        }
    }

    private void stopForegroundCallService() {
        if (!foregroundServiceStarted) return;
        try {
            stopService(new Intent(this, CallForegroundService.class));
        } catch (RuntimeException ignored) {
        }
        foregroundServiceStarted = false;
    }

    private void toggleMicrophone() {
        microphoneEnabled = !microphoneEnabled;
        if (localAudio != null) localAudio.setEnabled(microphoneEnabled);
        muteButton.setImageResource(microphoneEnabled
                ? R.drawable.ic_mic_active : R.drawable.ic_mic_muted);
        muteButton.setContentDescription(microphoneEnabled ? "كتم الميكروفون" : "تشغيل الميكروفون");
    }

    private void toggleCamera() {
        cameraEnabled = !cameraEnabled;
        if (localVideo != null) localVideo.setEnabled(cameraEnabled);
        cameraButton.setImageResource(R.drawable.ic_video_call);
        cameraButton.setAlpha(cameraEnabled ? 1f : .38f);
        cameraButton.setContentDescription(cameraEnabled ? "إيقاف الكاميرا" : "تشغيل الكاميرا");
    }

    private void toggleSpeaker() {
        speakerEnabled = !speakerEnabled;
        if (audioManager != null) audioManager.setSpeakerphoneOn(speakerEnabled);
        speakerButton.setImageResource(speakerEnabled
                ? R.drawable.ic_speaker_on : R.drawable.ic_speaker_off);
        speakerButton.setContentDescription(speakerEnabled ? "إيقاف مكبر الصوت" : "تشغيل مكبر الصوت");
    }

    private void onConnected() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::onConnected);
            return;
        }
        if (ending) return;
        stopRinging();
        startForegroundCallService();
        if (connectedAt == 0) {
            connectedAt = System.currentTimeMillis();
            String uid = FirebaseCore.auth().getCurrentUser() == null ? null : FirebaseCore.auth().getCurrentUser().getUid();
            ActiveCallRegistry.updateState(uid, callId, peerUid, "connected");
            callRef.update(
                    "status", "connected",
                    "connectedAt", FieldValue.serverTimestamp(),
                    "updatedAt", FieldValue.serverTimestamp());
            startTimer();
        }
        setCallState("متصل بأفضل مسار متاح ✓");
    }

    private void startTimer() {
        timerView.setVisibility(View.VISIBLE);
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                if (connectedAt == 0 || ending) return;
                long now = System.currentTimeMillis();
                long seconds = (now - connectedAt) / 1000;
                timerView.setText(String.format(java.util.Locale.US, "%02d:%02d",
                        seconds / 60, seconds % 60));
                if (now - lastRegistryRefresh > 60 * 1000L) {
                    lastRegistryRefresh = now;
                    String uid = FirebaseCore.auth().getCurrentUser() == null ? null
                            : FirebaseCore.auth().getCurrentUser().getUid();
                    ActiveCallRegistry.updateState(uid, callId, peerUid, "connected");
                }
                mainHandler.postDelayed(this, 1000);
            }
        };
        mainHandler.post(timerRunnable);
    }

    private void scheduleMissedTimeout() {
        if (!"caller".equals(role) || ringTimeoutRunnable != null) return;
        ringTimeoutRunnable = () -> {
            if (ending || connectedAt > 0 || callRef == null) return;
            FirebaseCore.firestore().runTransaction(tx -> {
                DocumentSnapshot snapshot = tx.get(callRef);
                String status = snapshot.getString("status");
                if ("waiting".equals(status) || "preparing".equals(status) || "ringing".equals(status)) {
                    tx.update(callRef, "status", "missed", "reason", "no_answer",
                            "endedAt", FieldValue.serverTimestamp(),
                            "updatedAt", FieldValue.serverTimestamp());
                    return true;
                }
                return false;
            }).addOnSuccessListener(changed -> {
                if (Boolean.TRUE.equals(changed)) {
                    PushRelay.notifyCallEnd(getApplicationContext(), callId);
                    CallLogWriter.write(callId);
                    toast("لم يتم الرد على المكالمة.");
                    endCall(false);
                }
            });
        };
        mainHandler.postDelayed(ringTimeoutRunnable, 90_000L);
    }

    private void startRingtone() {
        if (ringtonePlayer != null || ending) return;
        AppSounds.stopPreview();
        ringtonePlayer = AppSounds.createIncomingRingtone(this);
        if (ringtonePlayer == null) return;
        try {
            ringtonePlayer.start();
        } catch (RuntimeException error) {
            AppSounds.stopAndRelease(ringtonePlayer);
            ringtonePlayer = null;
        }
    }

    private void startRingback() {
        if (ringbackPlayer != null || ending || connectedAt != 0) return;
        AppSounds.stopPreview();
        ringbackPlayer = AppSounds.createRingback(this);
        if (ringbackPlayer == null) return;
        try {
            ringbackPlayer.start();
        } catch (RuntimeException error) {
            AppSounds.stopAndRelease(ringbackPlayer);
            ringbackPlayer = null;
        }
    }

    private void stopRingbackOnly() {
        AppSounds.stopAndRelease(ringbackPlayer);
        ringbackPlayer = null;
    }

    private void stopRinging() {
        AppSounds.stopAndRelease(ringtonePlayer);
        ringtonePlayer = null;
        stopRingbackOnly();
    }

    private void rejectIncoming() {
        if (ending) return;
        stopRinging();
        AppSounds.playHangupTone(getApplicationContext());
        ending = true;
        callRef.update(
                "status", "rejected", "reason", "rejected",
                "endedAt", FieldValue.serverTimestamp(),
                "updatedAt", FieldValue.serverTimestamp())
                .addOnCompleteListener(task -> {
                    PushRelay.notifyCallEnd(getApplicationContext(), callId);
                    CallLogWriter.write(callId);
                    cleanup();
                    finish();
                });
    }

    private void failCall(String message) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(() -> failCall(message));
            return;
        }
        if (ending) return;
        toast(message);
        if (callRef != null) callRef.update("failure", message, "updatedAt", FieldValue.serverTimestamp());
        setCallState(message);
    }

    private void setCallState(String message) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(() -> setCallState(message));
            return;
        }
        if (!ending && stateView != null) stateView.setText(message);
    }

    private void protectWebRtcCallback(Runnable action) {
        try {
            action.run();
        } catch (RuntimeException | LinkageError error) {
            mainHandler.post(() -> showInitializationFailure(error));
        }
    }

    private void reportMediaError(String friendlyMessage, String technicalMessage) {
        mainHandler.post(() -> {
            if (ending) return;
            if (callRef != null) {
                String detail = technicalMessage == null ? "unknown"
                        : technicalMessage.replace('\n', ' ').replace('\r', ' ');
                if (detail.length() > 180) detail = detail.substring(0, 180);
                callRef.update(
                        "failureCode", detail,
                        "updatedAt", FieldValue.serverTimestamp());
            }
            failCall(friendlyMessage);
        });
    }

    private void showInitializationFailure(Throwable error) {
        if (ending) return;
        ending = true;
        stopRinging();
        String code = error == null ? "Unknown" : error.getClass().getSimpleName();
        if (callRef != null) {
            callRef.update(
                    "status", "ended",
                    "reason", "media_initialization_failed",
                    "failureCode", code,
                    "endedAt", FieldValue.serverTimestamp(),
                    "updatedAt", FieldValue.serverTimestamp())
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            PushRelay.notifyCallEnd(getApplicationContext(), callId);
                        }
                        CallLogWriter.write(callId);
                    });
        }
        cleanup();
        String message = "video".equals(type)
                ? "تعذر فتح الكاميرا أو نظام الاتصال على هذا الجهاز."
                : "تعذر فتح الميكروفون أو نظام الاتصال على هذا الجهاز.";
        if (stateView != null) stateView.setText(message);
        if (isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this)
                .setTitle("تعذر بدء المكالمة")
                .setMessage(message + "\nتم منع إغلاق التطبيق تلقائياً. يمكنك العودة والمحاولة مجدداً.")
                .setCancelable(false)
                .setPositiveButton("العودة للمحادثة", (dialog, which) -> finish())
                .show();
    }

    private void endCall(boolean notifyRemote) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(() -> endCall(notifyRemote));
            return;
        }
        if (ending) return;
        ending = true;
        stopRinging();
        if (notifyRemote && callRef != null) {
            callRef.update(
                    "status", "ended", "reason", connectedAt > 0 ? "completed" : "cancelled",
                    "endedAt", FieldValue.serverTimestamp(),
                    "updatedAt", FieldValue.serverTimestamp())
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) PushRelay.notifyCallEnd(getApplicationContext(), callId);
                        CallLogWriter.write(callId);
                    });
        }
        cleanup();
        finish();
    }

    private void cleanup() {
        if (cleanedUp) return;
        cleanedUp = true;
        if (timerRunnable != null) mainHandler.removeCallbacks(timerRunnable);
        if (ringTimeoutRunnable != null) mainHandler.removeCallbacks(ringTimeoutRunnable);
        ringTimeoutRunnable = null;
        String uid = FirebaseCore.auth().getCurrentUser() == null ? null : FirebaseCore.auth().getCurrentUser().getUid();
        ActiveCallRegistry.release(uid, callId);
        if (avatarPulseRunnable != null) mainHandler.removeCallbacks(avatarPulseRunnable);
        avatarPulseRunnable = null;
        if (callerStage != null) callerStage.animate().cancel();
        if (pulseOuter != null) pulseOuter.animate().cancel();
        if (pulseInner != null) pulseInner.animate().cancel();
        if (callRegistration != null) safely(callRegistration::remove);
        if (candidatesRegistration != null) safely(candidatesRegistration::remove);
        callRegistration = null;
        candidatesRegistration = null;
        stopForegroundCallService();

        if (cameraCapturer != null) {
            try {
                cameraCapturer.stopCapture();
            } catch (Exception ignored) {
            }
            safely(cameraCapturer::dispose);
            cameraCapturer = null;
        }
        if (localVideo != null) safely(localVideo::dispose);
        if (localAudio != null) safely(localAudio::dispose);
        if (videoSource != null) safely(videoSource::dispose);
        if (audioSource != null) safely(audioSource::dispose);
        if (surfaceTextureHelper != null) safely(surfaceTextureHelper::dispose);
        if (peerConnection != null) safely(peerConnection::dispose);
        if (localView != null) safely(localView::release);
        if (remoteView != null) safely(remoteView::release);
        if (audioDeviceModule != null) safely(audioDeviceModule::release);
        if (factory != null) safely(factory::dispose);
        if (egl != null) safely(egl::release);

        if (audioManager != null) {
            safely(() -> audioManager.setSpeakerphoneOn(false));
            safely(() -> audioManager.setMode(AudioManager.MODE_NORMAL));
            safely(() -> audioManager.abandonAudioFocus(null));
        }
    }

    private void safely(Runnable action) {
        try {
            action.run();
        } catch (RuntimeException | LinkageError ignored) {
        }
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("إنهاء المكالمة؟")
                .setMessage("يمكنك إبقاء المكالمة جارية والعودة إليها من الإشعار.")
                .setPositiveButton("إنهاء", (dialog, which) -> endCall(true))
                .setNegativeButton("استمرار", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        if (!ending) {
            ending = true;
            stopRinging();
            if (!isChangingConfigurations() && callRef != null) {
                callRef.update(
                                "status", "ended",
                                "reason", "activity_closed",
                                "endedAt", FieldValue.serverTimestamp(),
                                "updatedAt", FieldValue.serverTimestamp())
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) PushRelay.notifyCallEnd(getApplicationContext(), callId);
                            CallLogWriter.write(callId);
                        });
            }
            cleanup();
        }
        super.onDestroy();
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private static String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value;
    }

    private final class PeerObserver implements PeerConnection.Observer {
        @Override public void onSignalingChange(PeerConnection.SignalingState state) {}

        @Override
        public void onIceConnectionChange(PeerConnection.IceConnectionState state) {
            mainHandler.post(() -> {
                if (ending) return;
                if (state == PeerConnection.IceConnectionState.CONNECTED
                        || state == PeerConnection.IceConnectionState.COMPLETED) {
                    onConnected();
                } else if (state == PeerConnection.IceConnectionState.CHECKING) {
                    setCallState("جارٍ فحص أفضل مسار للشبكة…");
                } else if (state == PeerConnection.IceConnectionState.DISCONNECTED) {
                    setCallState("انقطع الاتصال مؤقتًا — نحاول الاستعادة…");
                } else if (state == PeerConnection.IceConnectionState.FAILED) {
                    setCallState("تعذر عبور الشبكة — يلزم خادم TURN لهذه الشبكة");
                }
            });
        }

        @Override public void onIceConnectionReceivingChange(boolean receiving) {}
        @Override public void onIceGatheringChange(PeerConnection.IceGatheringState state) {}

        @Override
        public void onIceCandidate(IceCandidate candidate) {
            protectWebRtcCallback(() -> {
                Map<String, Object> data = new HashMap<>();
                data.put("sdpMid", candidate.sdpMid);
                data.put("sdpMLineIndex", candidate.sdpMLineIndex);
                data.put("candidate", candidate.sdp);
                callRef.collection("caller".equals(role) ? "callerCandidates" : "calleeCandidates")
                        .add(data);
            });
        }

        @Override public void onIceCandidatesRemoved(IceCandidate[] candidates) {}

        @Override
        public void onAddStream(MediaStream stream) {
            protectWebRtcCallback(() -> {
                if (!stream.videoTracks.isEmpty()) attachRemoteVideo(stream.videoTracks.get(0));
                if (!stream.audioTracks.isEmpty()) stream.audioTracks.get(0).setEnabled(true);
            });
        }

        @Override public void onRemoveStream(MediaStream stream) {}
        @Override public void onDataChannel(DataChannel dataChannel) {}
        @Override public void onRenegotiationNeeded() {}

        @Override
        public void onAddTrack(RtpReceiver receiver, MediaStream[] mediaStreams) {
            protectWebRtcCallback(() -> {
                MediaStreamTrack track = receiver.track();
                if (track instanceof VideoTrack) attachRemoteVideo((VideoTrack) track);
            });
        }

        @Override
        public void onTrack(RtpTransceiver transceiver) {
            protectWebRtcCallback(() -> {
                MediaStreamTrack track = transceiver.getReceiver().track();
                if (track instanceof VideoTrack) attachRemoteVideo((VideoTrack) track);
            });
        }
    }

    private void attachRemoteVideo(VideoTrack track) {
        if (remoteView == null) return;
        mainHandler.post(() -> {
            if (ending || remoteView == null) return;
            try {
                track.addSink(remoteView);
                remoteView.setVisibility(View.VISIBLE);
                if (callerStage != null && callerStage.getVisibility() == View.VISIBLE) {
                    if (avatarPulseRunnable != null) mainHandler.removeCallbacks(avatarPulseRunnable);
                    callerStage.animate().alpha(0f).scaleX(.86f).scaleY(.86f)
                            .setDuration(360).withEndAction(() -> callerStage.setVisibility(View.GONE)).start();
                }
            } catch (RuntimeException | LinkageError error) {
                showInitializationFailure(error);
            }
        });
    }

    private final class CameraEvents implements CameraVideoCapturer.CameraEventsHandler {
        @Override public void onCameraError(String error) { mainHandler.post(() -> failCall(error)); }
        @Override public void onCameraDisconnected() { mainHandler.post(() -> setCallState("انقطعت الكاميرا")); }
        @Override public void onCameraFreezed(String error) { mainHandler.post(() -> setCallState("توقفت الكاميرا مؤقتًا")); }
        @Override public void onCameraOpening(String cameraName) {}
        @Override public void onFirstFrameAvailable() {}
        @Override public void onCameraClosed() {}
    }

    private static class SdpCallback implements SdpObserver {
        @Override public void onCreateSuccess(SessionDescription description) {}
        @Override public void onSetSuccess() {}
        @Override public void onCreateFailure(String error) {}
        @Override public void onSetFailure(String error) {}
    }
}
