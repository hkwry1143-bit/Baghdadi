package com.baghdadi.chat.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import com.baghdadi.chat.R;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

public final class AppSounds {
    private static final String PREFS = "baghdadi_audio";
    private static final String KEY_RINGTONE = "incoming_ringtone";
    public static final String RINGTONE_PROFESSIONAL = "professional";
    public static final String RINGTONE_OFFICIAL = "official";

    private static final Object PREVIEW_LOCK = new Object();
    private static final Set<MediaPlayer> ACTIVE_ONE_SHOTS =
            Collections.newSetFromMap(new IdentityHashMap<>());
    private static MediaPlayer previewPlayer;
    private static int previewGeneration;

    private AppSounds() {}

    public static String selectedRingtone(Context context) {
        return preferences(context).getString(KEY_RINGTONE, RINGTONE_PROFESSIONAL);
    }

    public static boolean isOfficialSelected(Context context) {
        return RINGTONE_OFFICIAL.equals(selectedRingtone(context));
    }

    public static void selectRingtone(Context context, String value) {
        String normalized = RINGTONE_OFFICIAL.equals(value)
                ? RINGTONE_OFFICIAL : RINGTONE_PROFESSIONAL;
        preferences(context).edit().putString(KEY_RINGTONE, normalized).apply();
    }

    public static int selectedRingtoneResource(Context context) {
        return isOfficialSelected(context)
                ? R.raw.official_ringtone : R.raw.professional_ringtone;
    }

    public static String selectedRingtoneLabel(Context context) {
        return isOfficialSelected(context)
                ? "النغمة الرسمية" : "النغمة الاحترافية";
    }

    public static MediaPlayer createIncomingRingtone(Context context) {
        return createPlayer(
                context,
                selectedRingtoneResource(context),
                AudioAttributes.USAGE_NOTIFICATION_RINGTONE,
                true);
    }

    public static MediaPlayer createRingback(Context context) {
        return createPlayer(
                context,
                R.raw.whatsapp_ringback,
                AudioAttributes.USAGE_VOICE_COMMUNICATION_SIGNALLING,
                true);
    }

    public static void playHangupTone(Context context) {
        playOneShot(
                context,
                R.raw.hangup_tone,
                AudioAttributes.USAGE_VOICE_COMMUNICATION_SIGNALLING);
    }

    public static void previewSelectedRingtone(Context context) {
        synchronized (PREVIEW_LOCK) {
            stopPreviewLocked();
            int generation = ++previewGeneration;
            previewPlayer = createPlayer(
                    context,
                    selectedRingtoneResource(context),
                    AudioAttributes.USAGE_MEDIA,
                    false);
            if (previewPlayer == null) return;
            MediaPlayer player = previewPlayer;
            player.setVolume(0.82f, 0.82f);
            player.setOnCompletionListener(completed -> {
                synchronized (PREVIEW_LOCK) {
                    if (previewPlayer == completed) {
                        release(completed);
                        previewPlayer = null;
                    }
                }
            });
            player.start();
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                synchronized (PREVIEW_LOCK) {
                    if (generation == previewGeneration && previewPlayer == player) {
                        stopPreviewLocked();
                    }
                }
            }, 6500L);
        }
    }

    public static void stopPreview() {
        synchronized (PREVIEW_LOCK) {
            previewGeneration++;
            stopPreviewLocked();
        }
    }

    public static MediaPlayer createPlayer(
            Context context,
            int rawResource,
            int usage,
            boolean looping) {
        MediaPlayer player = new MediaPlayer();
        try (AssetFileDescriptor descriptor = context.getResources().openRawResourceFd(rawResource)) {
            if (descriptor == null) {
                release(player);
                return null;
            }
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            player.setDataSource(
                    descriptor.getFileDescriptor(),
                    descriptor.getStartOffset(),
                    descriptor.getLength());
            player.setLooping(looping);
            player.prepare();
            return player;
        } catch (Exception error) {
            release(player);
            return null;
        }
    }

    private static void playOneShot(Context context, int rawResource, int usage) {
        MediaPlayer player = createPlayer(context.getApplicationContext(), rawResource, usage, false);
        if (player == null) return;
        synchronized (ACTIVE_ONE_SHOTS) {
            ACTIVE_ONE_SHOTS.add(player);
        }
        player.setOnCompletionListener(AppSounds::finishOneShot);
        player.setOnErrorListener((failed, what, extra) -> {
            finishOneShot(failed);
            return true;
        });
        try {
            player.start();
        } catch (RuntimeException error) {
            finishOneShot(player);
        }
    }

    private static void finishOneShot(MediaPlayer player) {
        synchronized (ACTIVE_ONE_SHOTS) {
            ACTIVE_ONE_SHOTS.remove(player);
        }
        release(player);
    }

    public static void stopAndRelease(MediaPlayer player) {
        if (player == null) return;
        try {
            if (player.isPlaying()) player.stop();
        } catch (RuntimeException ignored) {
        }
        release(player);
    }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static void stopPreviewLocked() {
        if (previewPlayer == null) return;
        stopAndRelease(previewPlayer);
        previewPlayer = null;
    }

    private static void release(MediaPlayer player) {
        try {
            player.release();
        } catch (RuntimeException ignored) {
        }
    }
}
