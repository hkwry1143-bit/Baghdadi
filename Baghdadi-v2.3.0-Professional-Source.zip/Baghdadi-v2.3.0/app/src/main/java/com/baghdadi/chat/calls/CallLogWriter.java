package com.baghdadi.chat.calls;

import com.baghdadi.chat.data.FirebaseCore;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.SetOptions;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public final class CallLogWriter {
    private CallLogWriter(){}
    public static void write(String callId){if(callId==null||callId.trim().isEmpty())return;FirebaseCore.firestore().collection("calls").document(callId).get().addOnSuccessListener(s->{if(!s.exists())return;String caller=s.getString("callerId"),callee=s.getString("calleeId");if(caller==null||callee==null)return;String status=normalize(s),type=str(s,"type","audio"),chatId=caller.compareTo(callee)<0?caller+"_"+callee:callee+"_"+caller;long duration=duration(s);DocumentReference msg=FirebaseCore.firestore().collection("chats").document(chatId).collection("messages").document("call_"+callId);Map<String,Object>d=new HashMap<>();d.put("senderId",caller);d.put("type","call");d.put("callId",callId);d.put("callType",type);d.put("callStatus",status);d.put("callerId",caller);d.put("calleeId",callee);d.put("deleted",false);d.put("readBy",Arrays.asList(caller,callee));d.put("deliveredBy",Arrays.asList(caller,callee));d.put("durationSec",duration);Timestamp created=s.getTimestamp("createdAt");d.put("createdAt",created==null?FieldValue.serverTimestamp():created);d.put("updatedAt",FieldValue.serverTimestamp());msg.set(d,SetOptions.merge()).addOnSuccessListener(v->{Map<String,Object>c=new HashMap<>();c.put("lastMessage",preview(status,type,duration));c.put("lastMessageType","call");c.put("lastSenderId",caller);c.put("updatedAt",FieldValue.serverTimestamp());FirebaseCore.firestore().collection("chats").document(chatId).set(c,SetOptions.merge());});});}
    private static String normalize(DocumentSnapshot s){String status=str(s,"status","ended"),reason=str(s,"reason","");if("rejected".equals(status))return "busy".equals(reason)?"busy":"rejected";if(s.getTimestamp("connectedAt")!=null)return "accepted";if("missed".equals(status)||"expired".equals(status)||"no_answer".equals(reason))return "missed";if("cancelled".equals(reason)||"activity_closed".equals(reason)||"hangup".equals(reason))return "cancelled";return "missed";}
    private static long duration(DocumentSnapshot s){Timestamp a=s.getTimestamp("connectedAt"),b=s.getTimestamp("endedAt");return a==null||b==null?0:Math.max(0,(b.toDate().getTime()-a.toDate().getTime())/1000);}
    private static String preview(String status,String type,long duration){String icon="video".equals(type)?"🎥":"📞";if("accepted".equals(status))return icon+" مكالمة "+fmt(duration);if("rejected".equals(status))return icon+" مكالمة مرفوضة";if("busy".equals(status))return icon+" في مكالمة أخرى";return icon+" مكالمة فائتة";}
    private static String fmt(long s){return String.format(java.util.Locale.US,"%02d:%02d",s/60,s%60);}private static String str(DocumentSnapshot s,String k,String f){String v=s.getString(k);return v==null||v.trim().isEmpty()?f:v;}
}
