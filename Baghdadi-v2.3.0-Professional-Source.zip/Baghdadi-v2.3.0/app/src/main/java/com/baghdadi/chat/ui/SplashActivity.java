package com.baghdadi.chat.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.baghdadi.chat.util.Ui;

public final class SplashActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7, 10, 19));
        getWindow().setNavigationBarColor(Color.rgb(7, 10, 19));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(7, 10, 19));

        View glow = new View(this);
        GradientDrawable glowBackground = new GradientDrawable();
        glowBackground.setShape(GradientDrawable.OVAL);
        glowBackground.setColors(new int[]{Color.rgb(124, 58, 237), Color.rgb(8, 145, 178)});
        glow.setBackground(glowBackground);
        glow.setAlpha(0.16f);
        FrameLayout.LayoutParams glowParams = new FrameLayout.LayoutParams(
                Ui.dp(this, 220), Ui.dp(this, 220), Gravity.CENTER);
        root.addView(glow, glowParams);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER);

        TextView mark = new TextView(this);
        mark.setText("ب");
        mark.setTextColor(Color.WHITE);
        mark.setTextSize(54);
        mark.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mark.setGravity(Gravity.CENTER);
        GradientDrawable markBackground = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(124, 58, 237), Color.rgb(8, 145, 178)});
        markBackground.setCornerRadius(Ui.dp(this, 30));
        mark.setBackground(markBackground);
        brand.addView(mark, new LinearLayout.LayoutParams(Ui.dp(this, 108), Ui.dp(this, 108)));

        TextView name = new TextView(this);
        name.setText("بغدادي");
        name.setTextColor(Color.rgb(238, 242, 255));
        name.setTextSize(35);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(-2, Ui.dp(this, 64));
        nameParams.topMargin = Ui.dp(this, 18);
        brand.addView(name, nameParams);

        TextView subtitle = new TextView(this);
        subtitle.setText("تواصل أقرب • أسرع • أوضح");
        subtitle.setTextColor(Color.rgb(143, 154, 182));
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        brand.addView(subtitle, new LinearLayout.LayoutParams(-2, Ui.dp(this, 38)));
        root.addView(brand, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        setContentView(root);

        brand.setAlpha(0f);
        brand.setScaleX(0.86f);
        brand.setScaleY(0.86f);
        brand.setTranslationY(Ui.dp(this, 18));
        brand.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .translationY(0f)
                .setDuration(470)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .start();
        glow.animate()
                .alpha(0.34f)
                .scaleX(1.22f)
                .scaleY(1.22f)
                .setDuration(720)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .start();

        root.postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, 760);
    }
}
