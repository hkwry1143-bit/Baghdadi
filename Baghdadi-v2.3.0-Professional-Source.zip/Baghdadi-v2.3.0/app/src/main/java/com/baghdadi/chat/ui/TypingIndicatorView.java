package com.baghdadi.chat.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

/** A lightweight three-dot Messenger-style typing animation. */
final class TypingIndicatorView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ValueAnimator animator;
    private float progress;

    TypingIndicatorView(Context context) {
        super(context);
        paint.setColor(Color.rgb(174, 184, 211));
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentDescription("الطرف الآخر يكتب الآن");
    }

    void start() {
        if (animator != null && animator.isRunning()) return;
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(900);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.addUpdateListener(value -> {
            progress = (float) value.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    void stop() {
        if (animator != null) animator.cancel();
        animator = null;
        progress = 0f;
        invalidate();
    }

    @Override protected void onDetachedFromWindow() {
        stop();
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float radius = Math.min(getHeight() * .12f, dp(4.2f));
        float gap = radius * 2.7f;
        float start = getWidth() / 2f - gap;
        float centerY = getHeight() / 2f;
        for (int i = 0; i < 3; i++) {
            double phase = (progress * Math.PI * 2) - (i * .72);
            float lift = (float) Math.max(0, Math.sin(phase)) * dp(4.3f);
            float alpha = .48f + (float) Math.max(0, Math.sin(phase)) * .52f;
            paint.setAlpha(Math.round(alpha * 255));
            canvas.drawCircle(start + i * gap, centerY - lift, radius, paint);
        }
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
