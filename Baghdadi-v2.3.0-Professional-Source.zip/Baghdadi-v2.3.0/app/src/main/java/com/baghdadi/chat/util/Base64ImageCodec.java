package com.baghdadi.chat.util;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Compresses user-selected images to Firestore-safe Base64 data URLs. */
public final class Base64ImageCodec {
    private Base64ImageCodec() {}

    public static final class EncodedImage {
        public final String dataUrl;
        public final int byteCount;
        public final int width;
        public final int height;

        EncodedImage(String dataUrl, int byteCount, int width, int height) {
            this.dataUrl = dataUrl;
            this.byteCount = byteCount;
            this.width = width;
            this.height = height;
        }
    }

    public static EncodedImage encode(Context context, Uri uri, int maxDimension, int maxBytes)
            throws Exception {
        ContentResolver resolver = context.getContentResolver();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) throw new IllegalArgumentException("image_unavailable");
            BitmapFactory.decodeStream(input, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new IllegalArgumentException("invalid_image");
        }

        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDimension * 2) {
            sample *= 2;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) throw new IllegalArgumentException("image_unavailable");
            bitmap = BitmapFactory.decodeStream(input, null, options);
        }
        if (bitmap == null) throw new IllegalArgumentException("invalid_image");

        int rotation = imageRotation(resolver, uri);
        if (rotation != 0) {
            Matrix matrix = new Matrix();
            matrix.postRotate(rotation);
            Bitmap rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            if (rotated != bitmap) bitmap.recycle();
            bitmap = rotated;
        }

        int largest = Math.max(bitmap.getWidth(), bitmap.getHeight());
        if (largest > maxDimension) {
            float ratio = maxDimension / (float) largest;
            Bitmap scaled = Bitmap.createScaledBitmap(
                    bitmap,
                    Math.max(1, Math.round(bitmap.getWidth() * ratio)),
                    Math.max(1, Math.round(bitmap.getHeight() * ratio)),
                    true);
            if (scaled != bitmap) bitmap.recycle();
            bitmap = scaled;
        }

        ByteArrayOutputStream output = new ByteArrayOutputStream(Math.min(maxBytes, 256_000));
        int quality = 88;
        byte[] bytes;
        do {
            output.reset();
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)) {
                bitmap.recycle();
                throw new IllegalStateException("image_compression_failed");
            }
            bytes = output.toByteArray();
            quality -= 7;
        } while (bytes.length > maxBytes && quality >= 39);

        while (bytes.length > maxBytes && Math.max(bitmap.getWidth(), bitmap.getHeight()) > 640) {
            Bitmap scaled = Bitmap.createScaledBitmap(bitmap,
                    Math.max(1, Math.round(bitmap.getWidth() * .82f)),
                    Math.max(1, Math.round(bitmap.getHeight() * .82f)), true);
            if (scaled != bitmap) bitmap.recycle();
            bitmap = scaled;
            output.reset();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 72, output);
            bytes = output.toByteArray();
        }
        if (bytes.length > maxBytes) {
            bitmap.recycle();
            throw new IllegalArgumentException("image_too_large");
        }

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        bitmap.recycle();
        return new EncodedImage(
                "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP),
                bytes.length,
                width,
                height);
    }

    public static Bitmap decodeDataUrl(String value) {
        if (value == null || !value.startsWith("data:image/")) return null;
        int separator = value.indexOf(',');
        if (separator < 0 || separator + 1 >= value.length()) return null;
        try {
            byte[] bytes = Base64.decode(value.substring(separator + 1), Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static int imageRotation(ContentResolver resolver, Uri uri) {
        try (Cursor cursor = resolver.query(uri,
                new String[]{MediaStore.Images.ImageColumns.ORIENTATION}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(MediaStore.Images.ImageColumns.ORIENTATION);
                if (column >= 0) return cursor.getInt(column);
            }
        } catch (Exception ignored) {
        }
        return 0;
    }
}
