package com.baghdadi.chat.service;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import com.baghdadi.chat.R;
import com.baghdadi.chat.util.AppSounds;

public final class NotificationChannels {
    public static final String CALLS_PROFESSIONAL = "calls_professional_v3";
    public static final String CALLS_OFFICIAL = "calls_official_v3";
    public static final String ACTIVE_CALL = "active_call_v2";
    public static final String MESSAGES = "messages_custom_v2";

    private NotificationChannels() {}

    public static String selectedCallsChannel(Context context) {
        return AppSounds.isOfficialSelected(context)
                ? CALLS_OFFICIAL : CALLS_PROFESSIONAL;
    }

    public static Uri rawUri(Context context, int rawResource) {
        return Uri.parse("android.resource://" + context.getPackageName() + "/" + rawResource);
    }

    public static void ensureAll(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;

        AudioAttributes ringtoneAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        AudioAttributes messageAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        NotificationChannel professionalCalls = incomingCallsChannel(
                context,
                CALLS_PROFESSIONAL,
                "المكالمات — النغمة الاحترافية",
                R.raw.professional_ringtone,
                ringtoneAttributes);
        NotificationChannel officialCalls = incomingCallsChannel(
                context,
                CALLS_OFFICIAL,
                "المكالمات — النغمة الرسمية",
                R.raw.official_ringtone,
                ringtoneAttributes);

        NotificationChannel active = new NotificationChannel(
                ACTIVE_CALL,
                context.getString(R.string.channel_active_call),
                NotificationManager.IMPORTANCE_LOW);
        active.setSound(null, null);
        active.enableVibration(false);
        active.setShowBadge(false);

        NotificationChannel messages = new NotificationChannel(
                MESSAGES,
                context.getString(R.string.channel_messages),
                NotificationManager.IMPORTANCE_HIGH);
        messages.setDescription(context.getString(R.string.channel_messages_description));
        messages.enableVibration(true);
        messages.setVibrationPattern(new long[]{0, 180, 110, 180});
        messages.setShowBadge(true);
        messages.setSound(rawUri(context, R.raw.notification_tone), messageAttributes);

        manager.createNotificationChannels(java.util.Arrays.asList(
                professionalCalls,
                officialCalls,
                active,
                messages));
    }

    private static NotificationChannel incomingCallsChannel(
            Context context,
            String id,
            String name,
            int rawResource,
            AudioAttributes attributes) {
        NotificationChannel channel = new NotificationChannel(
                id,
                name,
                NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription(context.getString(R.string.channel_calls_description));
        channel.enableVibration(true);
        channel.setVibrationPattern(new long[]{0, 700, 450, 700});
        channel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
        channel.setSound(rawUri(context, rawResource), attributes);
        return channel;
    }
}
