package com.baghdadi.chat.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Person;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.os.Build;
import com.baghdadi.chat.R;
import com.baghdadi.chat.calls.ActiveCallRegistry;
import com.baghdadi.chat.calls.CallLogWriter;
import com.baghdadi.chat.data.DeviceRegistry;
import com.baghdadi.chat.data.FirebaseCore;
import com.baghdadi.chat.data.PushRelay;
import com.baghdadi.chat.runtime.AppVisibility;
import com.baghdadi.chat.settings.AppPreferences;
import com.baghdadi.chat.ui.CallActivity;
import com.baghdadi.chat.ui.MainActivity;
import com.baghdadi.chat.util.AppSounds;
import com.baghdadi.chat.util.Base64ImageCodec;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

public final class BaghdadiMessagingService extends FirebaseMessagingService {
    @Override public void onNewToken(String token) {
        FirebaseCore.init(this);
        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        if(user!=null)DeviceRegistry.register(this,user.getUid(),token);
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        FirebaseCore.init(this);NotificationChannels.ensureAll(this);
        Map<String,String> data=message.getData();String kind=data.get("kind");
        if("call".equals(kind)&&data.get("callId")!=null)claimAndShowCall(data);
        else if("call_end".equals(kind)&&data.get("callId")!=null){cancelCallNotification(data.get("callId"));if("rejected".equals(data.get("status"))||"busy".equals(data.get("reason")))AppSounds.playHangupTone(getApplicationContext());CallLogWriter.write(data.get("callId"));}
        else if("message".equals(kind))handleMessage(data);
        else if(message.getNotification()!=null)showFallbackMessage(message.getNotification().getTitle(),message.getNotification().getBody());
    }

    private void claimAndShowCall(Map<String,String> data){
        String callId=data.get("callId"),callerId=data.get("callerId");FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        if(user==null){showCallNotification(data);return;}
        ActiveCallRegistry.claimIncoming(user.getUid(),callerId,callId,new ActiveCallRegistry.ClaimCallback(){
            @Override public void onClaimed(){acknowledgeAndShowCall(data);}
            @Override public void onBusy(){
                FirebaseCore.firestore().collection("calls").document(callId).update("status","rejected","reason","busy","endedAt",FieldValue.serverTimestamp(),"updatedAt",FieldValue.serverTimestamp()).addOnCompleteListener(task->{if(task.isSuccessful()){PushRelay.notifyCallEnd(getApplicationContext(),callId);CallLogWriter.write(callId);}});
            }
            @Override public void onError(Exception error){acknowledgeAndShowCall(data);}
        });
    }

    private void cancelCallNotification(String callId){NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null)manager.cancel(CallActionReceiver.notificationId(callId));stopService(new Intent(this,CallForegroundService.class));}

    private void acknowledgeAndShowCall(Map<String,String> data){
        String callId=data.get("callId");FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        if(user!=null)FirebaseCore.firestore().collection("calls").document(callId).get().addOnSuccessListener(snapshot->{String status=snapshot.getString("status");if("waiting".equals(status)||"preparing".equals(status))snapshot.getReference().update("status","ringing","deliveredAt",FieldValue.serverTimestamp(),"updatedAt",FieldValue.serverTimestamp());});
        showCallNotification(data);
    }

    private void showCallNotification(Map<String,String> data){Bitmap embedded=Base64ImageCodec.decodeDataUrl(data.get("callerAvatar"));postCallNotification(data,embedded);if(embedded==null&&data.get("callerId")!=null)FirebaseCore.firestore().collection("users").document(data.get("callerId")).get().addOnSuccessListener(snapshot->{Bitmap avatar=Base64ImageCodec.decodeDataUrl(snapshot.getString("avatar"));if(avatar!=null)postCallNotification(data,avatar);});}

    private void postCallNotification(Map<String,String> data,Bitmap avatar){
        String callId=data.get("callId"),callerName=value(data,"callerName","مكالمة واردة"),callType=value(data,"type","audio");
        Intent open=new Intent(this,CallActivity.class).putExtra("callId",callId).putExtra("role","callee").putExtra("type",callType).putExtra("peerUid",data.get("callerId")).putExtra("peerName",callerName).putExtra("peerAvatar",value(data,"callerAvatar","")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content=PendingIntent.getActivity(this,CallActionReceiver.notificationId(callId),open,PendingIntent.FLAG_UPDATE_CURRENT|immutableFlag());
        Intent answerIntent=new Intent(open).putExtra("autoAccept",true);PendingIntent answer=PendingIntent.getActivity(this,CallActionReceiver.notificationId(callId)+2,answerIntent,PendingIntent.FLAG_UPDATE_CURRENT|immutableFlag());
        Intent rejectIntent=new Intent(this,CallActionReceiver.class).setAction(CallActionReceiver.ACTION_REJECT).putExtra("callId",callId);PendingIntent reject=PendingIntent.getBroadcast(this,CallActionReceiver.notificationId(callId)+1,rejectIntent,PendingIntent.FLAG_UPDATE_CURRENT|immutableFlag());
        Notification.Builder builder=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?new Notification.Builder(this,NotificationChannels.selectedCallsChannel(this)):new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_stat_baghdadi).setColor(Color.rgb(124,58,237)).setContentTitle(callerName).setContentText("video".equals(callType)?"مكالمة فيديو واردة":"مكالمة صوتية واردة").setCategory(Notification.CATEGORY_CALL).setPriority(Notification.PRIORITY_MAX).setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(avatar!=null).setContentIntent(content).addAction(new Notification.Action.Builder(null,"رفض",reject).build()).addAction(new Notification.Action.Builder(null,"رد",answer).build());
        if(AppPreferences.useFullScreenCalls(this))builder.setFullScreenIntent(content,true);
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.O)builder.setSound(NotificationChannels.rawUri(this,AppSounds.selectedRingtoneResource(this)));
        if(avatar!=null)builder.setLargeIcon(avatar);if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)builder.setTimeoutAfter(90_000L);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S){Person.Builder p=new Person.Builder().setName(callerName).setImportant(true);if(avatar!=null)p.setIcon(Icon.createWithBitmap(avatar));builder.setStyle(Notification.CallStyle.forIncomingCall(p.build(),reject,answer));}
        NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null)manager.notify(CallActionReceiver.notificationId(callId),builder.build());
    }

    private void handleMessage(Map<String,String> data){
        markDelivered(data);
        String chatId=data.get("chatId");
        if(AppVisibility.isCurrentConversation(chatId)){cancelMessageNotification(chatId);return;}
        Bitmap embedded=Base64ImageCodec.decodeDataUrl(data.get("senderAvatar"));postMessageNotification(data,embedded);String senderId=data.get("senderId");
        if(embedded==null&&senderId!=null&&!senderId.trim().isEmpty())FirebaseCore.firestore().collection("users").document(senderId).get().addOnSuccessListener(snapshot->{Bitmap avatar=Base64ImageCodec.decodeDataUrl(snapshot.getString("avatar"));if(avatar!=null&&!AppVisibility.isCurrentConversation(chatId))postMessageNotification(data,avatar);});
    }

    private void markDelivered(Map<String,String> data){FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();String chatId=data.get("chatId"),messageId=data.get("messageId");if(user==null||chatId==null||messageId==null)return;FirebaseCore.firestore().collection("chats").document(chatId).collection("messages").document(messageId).update("deliveredBy",FieldValue.arrayUnion(user.getUid()),"deliveredAt",FieldValue.serverTimestamp());}

    private void cancelMessageNotification(String chatId){if(chatId==null)return;NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null)manager.cancel(chatId.hashCode());}

    private void postMessageNotification(Map<String,String> data,Bitmap avatar){
        String chatId=data.get("chatId"),senderId=data.get("senderId"),title=value(data,"senderName","بغدادي");boolean contentVisible=AppPreferences.showNotificationContent(this);String body=contentVisible?value(data,"body","رسالة جديدة"):"رسالة جديدة";
        Intent open=new Intent(this,MainActivity.class).putExtra("chatId",chatId).putExtra("peerUid",senderId).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);int id=chatId==null?(int)System.currentTimeMillis():chatId.hashCode();PendingIntent content=PendingIntent.getActivity(this,id,open,PendingIntent.FLAG_UPDATE_CURRENT|immutableFlag());
        Notification.Builder builder=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?new Notification.Builder(this,NotificationChannels.MESSAGES):new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_stat_baghdadi).setColor(Color.rgb(124,58,237)).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setCategory(Notification.CATEGORY_MESSAGE).setPriority(Notification.PRIORITY_HIGH).setVisibility(contentVisible?Notification.VISIBILITY_PRIVATE:Notification.VISIBILITY_SECRET).setAutoCancel(true).setOnlyAlertOnce(avatar!=null).setGroup("baghdadi_messages").setNumber(1).setContentIntent(content);
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.O)builder.setSound(NotificationChannels.rawUri(this,R.raw.notification_tone));if(avatar!=null)builder.setLargeIcon(avatar);NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null)manager.notify(id,builder.build());
    }

    private void showFallbackMessage(String title,String body){if(!AppPreferences.showNotificationContent(this))body="رسالة جديدة";Map<String,String> data=new java.util.HashMap<>();data.put("senderName",title==null?"بغدادي":title);data.put("body",body==null?"رسالة جديدة":body);postMessageNotification(data,null);}
    private static String value(Map<String,String> data,String key,String fallback){String value=data.get(key);return value==null||value.trim().isEmpty()?fallback:value;}
    private static int immutableFlag(){return Build.VERSION.SDK_INT>=Build.VERSION_CODES.M?PendingIntent.FLAG_IMMUTABLE:0;}
}
