package com.baghdadi.chat.ui;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.media.MediaRecorder;
import com.baghdadi.chat.R;
import com.baghdadi.chat.data.FirebaseCore;
import com.baghdadi.chat.data.DeviceRegistry;
import com.baghdadi.chat.data.PushRelay;
import com.baghdadi.chat.calls.ActiveCallRegistry;
import com.baghdadi.chat.runtime.AppVisibility;
import com.baghdadi.chat.settings.AppPreferences;
import com.baghdadi.chat.settings.ChatTheme;
import com.baghdadi.chat.settings.PowerManagement;
import com.baghdadi.chat.ui.widget.VoiceMessageView;
import com.baghdadi.chat.ui.widget.ZoomImageView;
import com.baghdadi.chat.model.*;
import com.baghdadi.chat.security.BiometricGate;
import com.baghdadi.chat.service.NotificationChannels;
import com.baghdadi.chat.util.*;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.*;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.StorageReference;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
 public static final int REQ_MEDIA=1001, REQ_NOTIFY=1002, REQ_FILE=1003, REQ_AVATAR=1004, REQ_SAVE=1005;
 private FirebaseAuth auth; private FirebaseFirestore fs; private FirebaseDatabase rtdb;
 private LinearLayout root,content,chatList,messages,composer; private EditText userInput,passInput,messageInput; private TextView title,status,typing,replyPreview,voiceStatusView,chatCountView,conversationNameView; private ScrollView messageScroll;
 private UserProfile me,peer; private String chatId; private ListenerRegistration messagesReg,chatsReg,peerReg,incomingReg; private ValueEventListener typingReg;
 private DatabaseReference presenceRef,typingRef,typingListenRef; private ValueEventListener connectedListener,peerPresenceListener;
 private Handler handler=new Handler(Looper.getMainLooper()); private Runnable typingStop,incomingTypingHide,presenceTicker; private boolean loginMode=false, authBusy=false,biometricUnlocked=false,filterUnread=false,inConversation=false,inProfile=false,appVisible=false,notificationPromptShown=false,avatarForProfile=false,composerSendMode=false,peerOnline=false; private MediaRecorder recorder; private long recordStart,backgroundAt,peerLastSeen;
 private Runnable recordTicker,voiceTimeout,voicePulse,playbackTicker; private String replyToId,replyToText,loadingUid,pendingChatId,pendingPeerUid,pendingAvatarData="";
 private java.io.File voiceFile,activeVoiceTempFile; private ImageButton voiceButton,composerActionButton; private VoiceMessageView activeVoicePlaybackButton; private Button allChatsTab,unreadChatsTab; private android.media.MediaPlayer activeVoicePlayer; private String activeVoiceMessageId; private boolean voiceStopping=false,callStarting=false,voicePulseLarge=false; private int pendingCallType=0,voicePlaybackToken=0; private long activeVoiceDurationMs=0;
 private View typingContainer; private TypingIndicatorView typingIndicator; private ImageView avatarPreview,profileAvatarView,conversationAvatarView; private ChatTheme activeChatTheme; private String pendingImageSource;
 private static final long MIN_VOICE_MS=650L,MAX_VOICE_MS=90000L; private static final int MAX_VOICE_BYTES=600000;
 private final ArrayList<ChatModel> chats=new ArrayList<>();
 private final ArrayList<String> renderedMessageIds=new ArrayList<>();
 private final HashMap<String,UserProfile> profileCache=new HashMap<>();
 private final HashSet<String> handledIncomingCalls=new HashSet<>();
 private static final int BG=Color.rgb(7,10,19), PANEL=Color.rgb(16,23,41), PANEL2=Color.rgb(21,29,49), TEXT=Color.rgb(238,242,255), MUTED=Color.rgb(143,154,182);
 private final String AV="";
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(true);FirebaseCore.init(this);auth=FirebaseCore.auth();fs=FirebaseCore.firestore();rtdb=FirebaseCore.rtdb();captureDeepLink(getIntent());auth.addAuthStateListener(a->handleAuthUser(a.getCurrentUser()));}
 @Override protected void onStart(){super.onStart();appVisible=true;AppVisibility.setForeground(true);if(inConversation&&chatId!=null)AppVisibility.setCurrentChat(chatId);if(backgroundAt>0&&SystemClock.elapsedRealtime()-backgroundAt>30000&&me!=null&&getPreferences(MODE_PRIVATE).getBoolean("biometric_lock",false)){biometricUnlocked=false;FirebaseUser user=auth.getCurrentUser();if(user!=null)showBiometricGate(user);}backgroundAt=0;if(me!=null){startPresence();listenIncomingCalls();}}
 @Override protected void onStop(){appVisible=false;AppVisibility.setForeground(false);if(!isChangingConfigurations()){backgroundAt=SystemClock.elapsedRealtime();stopPresence();}super.onStop();}
 @Override protected void onPause(){stopTyping();super.onPause();}
 @Override protected void onDestroy(){if(recorder!=null)cancelVoiceRecording();stopActiveVoicePlayback();AppSounds.stopPreview();clearListeners();stopPresence();super.onDestroy();}
 private void base(){stopActiveVoicePlayback();AppSounds.stopPreview();root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackground(Ui.screenGradient());root.setPadding(Ui.dp(this,10),Ui.dp(this,8),Ui.dp(this,10),Ui.dp(this,8));setContentView(root);}
 private TextView label(String s){TextView v=Ui.text(this,s,15,TEXT);v.setTypeface(null,android.graphics.Typeface.BOLD);v.setPadding(0,Ui.dp(this,10),0,Ui.dp(this,5));return v;}
 private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(116,128,157));e.setTextColor(TEXT);e.setTextSize(16);e.setSingleLine(true);e.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL));e.setBackground(Ui.outlined(PANEL2,Color.rgb(45,57,84),18));e.setPadding(Ui.dp(this,17),0,Ui.dp(this,17),0);return e;}
 private Button primary(String s){Button b=Ui.button(this,s);b.setBackground(Ui.gradientRipple());b.setTypeface(null,android.graphics.Typeface.BOLD);return b;}
 private void loadAvatar(ImageView view,String source){com.bumptech.glide.Glide.with(this).load(safeText(source,AV)).circleCrop().placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar).into(view);}
 private void handleAuthUser(FirebaseUser user){if(user==null){clearListeners();stopPresence();loadingUid=null;me=null;biometricUnlocked=false;showAuth(false);return;}boolean lock=getPreferences(MODE_PRIVATE).getBoolean("biometric_lock",false);if(lock&&!biometricUnlocked){showBiometricGate(user);return;}loadProfile(user);}
 private void showBiometricGate(FirebaseUser user){base();LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);card.setPadding(Ui.dp(this,28),Ui.dp(this,28),Ui.dp(this,28),Ui.dp(this,28));TextView mark=Ui.text(this,"ب",52,Color.WHITE);mark.setGravity(Gravity.CENTER);mark.setBackground(Ui.gradient());card.addView(mark,new LinearLayout.LayoutParams(Ui.dp(this,104),Ui.dp(this,104)));TextView brand=Ui.text(this,"بغدادي",31,TEXT);brand.setTypeface(null,android.graphics.Typeface.BOLD);brand.setGravity(Gravity.CENTER);card.addView(brand,new LinearLayout.LayoutParams(-1,Ui.dp(this,72)));TextView privacy=Ui.text(this,"محادثاتك مقفلة على هذا الجهاز",14,MUTED);privacy.setGravity(Gravity.CENTER);card.addView(privacy,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));Button unlock=primary("☝ فتح بالبصمة");card.addView(unlock,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));Button signOut=Ui.button(this,"استخدام حساب آخر");signOut.setBackgroundColor(Color.TRANSPARENT);card.addView(signOut,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));root.addView(card,new LinearLayout.LayoutParams(-1,-1));unlock.setOnClickListener(v->BiometricGate.authenticate(this,new BiometricGate.Callback(){public void onSuccess(){biometricUnlocked=true;loadProfile(user);}public void onFailure(String message){if(message!=null&&!message.trim().isEmpty())toast(message);}}));signOut.setOnClickListener(v->{DeviceRegistry.unregister(this,user.getUid());getPreferences(MODE_PRIVATE).edit().putBoolean("biometric_lock",false).apply();auth.signOut();});}
 private void captureDeepLink(Intent intent){if(intent==null)return;if(intent.getStringExtra("chatId")!=null)pendingChatId=intent.getStringExtra("chatId");if(intent.getStringExtra("peerUid")!=null)pendingPeerUid=intent.getStringExtra("peerUid");}
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);captureDeepLink(intent);if(me!=null)openPendingChat();}
 private void openPendingChat(){if(me==null||pendingChatId==null||pendingPeerUid==null)return;String targetChat=pendingChatId,targetPeer=pendingPeerUid;pendingChatId=null;pendingPeerUid=null;peer=profileCache.get(targetPeer);if(peer==null){peer=new UserProfile();peer.uid=targetPeer;peer.username="مستخدم";peer.avatar=AV;}chatId=targetChat;showConversation();}
 private void showAuth(boolean login){
  loginMode=login;
  if(login)pendingAvatarData="";
  base();
  root.setBackground(Ui.screenGradient());
  root.setPadding(Ui.dp(this,18),Ui.dp(this,12),Ui.dp(this,18),Ui.dp(this,12));
  ScrollView scroll=new ScrollView(this);
  scroll.setFillViewport(true);
  scroll.setVerticalScrollBarEnabled(false);
  LinearLayout shell=new LinearLayout(this);
  shell.setOrientation(LinearLayout.VERTICAL);
  shell.setGravity(Gravity.CENTER_HORIZONTAL);
  shell.setPadding(Ui.dp(this,8),Ui.dp(this,28),Ui.dp(this,8),Ui.dp(this,22));
  scroll.addView(shell,new ScrollView.LayoutParams(-1,-1));
  root.addView(scroll,new LinearLayout.LayoutParams(-1,-1));

  TextView mark=Ui.text(this,"ب",44,Color.WHITE);
  mark.setGravity(Gravity.CENTER);
  mark.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD));
  mark.setBackground(Ui.gradient());
  mark.setElevation(Ui.dp(this,12));
  shell.addView(mark,new LinearLayout.LayoutParams(Ui.dp(this,84),Ui.dp(this,84)));

  TextView brand=Ui.text(this,"بغدادي",26,TEXT);
  brand.setGravity(Gravity.CENTER);
  brand.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD));
  LinearLayout.LayoutParams brandParams=new LinearLayout.LayoutParams(-1,Ui.dp(this,54));
  brandParams.topMargin=Ui.dp(this,5);
  shell.addView(brand,brandParams);

  LinearLayout secureChip=new LinearLayout(this);
  secureChip.setGravity(Gravity.CENTER);
  secureChip.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);
  secureChip.setBackground(Ui.outlined(Color.argb(100,24,33,57),Color.rgb(67,56,111),24));
  ImageView lock=new ImageView(this);lock.setImageResource(R.drawable.ic_lock);lock.setPadding(Ui.dp(this,6),Ui.dp(this,6),Ui.dp(this,6),Ui.dp(this,6));
  TextView secureText=Ui.text(this,"خصوصية وأمان على كل جهاز",12,Color.rgb(205,199,237));
  secureText.setGravity(Gravity.CENTER);
  secureChip.addView(lock,new LinearLayout.LayoutParams(Ui.dp(this,30),Ui.dp(this,30)));
  secureChip.addView(secureText,new LinearLayout.LayoutParams(-2,Ui.dp(this,36)));
  shell.addView(secureChip,new LinearLayout.LayoutParams(-2,Ui.dp(this,38)));

  LinearLayout card=new LinearLayout(this);
  card.setOrientation(LinearLayout.VERTICAL);
  card.setPadding(Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,24),Ui.dp(this,20));
  card.setBackground(Ui.outlined(Color.rgb(14,20,37),Color.rgb(46,58,87),24));
  card.setElevation(Ui.dp(this,10));
  LinearLayout.LayoutParams cardParams=new LinearLayout.LayoutParams(-1,-2);
  cardParams.topMargin=Ui.dp(this,22);
  shell.addView(card,cardParams);

  TextView heading=Ui.text(this,login?"أهلاً بعودتك":"أنشئ حسابك",28,TEXT);
  heading.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD));
  heading.setGravity(Gravity.CENTER);
  card.addView(heading,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
  TextView subtitle=Ui.text(this,login?"تواصل بأمان من حيث توقفت":"ابدأ محادثاتك ومكالماتك خلال لحظات",14,MUTED);
  subtitle.setGravity(Gravity.CENTER);
  card.addView(subtitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));

  if(!login){
   LinearLayout avatarPicker=new LinearLayout(this);
   avatarPicker.setOrientation(LinearLayout.VERTICAL);
   avatarPicker.setGravity(Gravity.CENTER);
   avatarPicker.setPadding(0,Ui.dp(this,8),0,Ui.dp(this,8));
   avatarPreview=new ImageView(this);
   avatarPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
   avatarPreview.setClipToOutline(true);
   avatarPreview.setBackground(Ui.gradientCircle());
   loadAvatar(avatarPreview,pendingAvatarData);
   avatarPicker.addView(avatarPreview,new LinearLayout.LayoutParams(Ui.dp(this,92),Ui.dp(this,92)));
   Button chooseAvatar=Ui.button(this,"إضافة صورة شخصية (اختياري)");
   chooseAvatar.setTextColor(Color.rgb(196,181,253));
   chooseAvatar.setBackground(Ui.ripple(Ui.bg(Color.TRANSPARENT,14)));
   avatarPicker.addView(chooseAvatar,new LinearLayout.LayoutParams(-2,Ui.dp(this,44)));
   TextView avatarHelp=Ui.text(this,"تُضغط وتُحفظ بصيغة Base64 دون Firebase Storage",11,MUTED);
   avatarHelp.setGravity(Gravity.CENTER);
   avatarPicker.addView(avatarHelp,new LinearLayout.LayoutParams(-1,Ui.dp(this,28)));
   card.addView(avatarPicker,new LinearLayout.LayoutParams(-1,Ui.dp(this,178)));
   avatarPreview.setOnClickListener(v->pickAvatar(false));
   chooseAvatar.setOnClickListener(v->pickAvatar(false));
  }

  card.addView(label("اسم المستخدم"));
  userInput=input("username");
  userInput.setTextDirection(View.TEXT_DIRECTION_LTR);
  userInput.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
  card.addView(userInput,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));
  TextView help=Ui.text(this,"أحرف إنجليزية، أرقام، _ أو .",11,MUTED);
  help.setPadding(Ui.dp(this,4),Ui.dp(this,5),Ui.dp(this,4),0);
  card.addView(help,new LinearLayout.LayoutParams(-1,Ui.dp(this,30)));

  card.addView(label("كلمة المرور"));
  passInput=input("8 أحرف على الأقل");
  passInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
  passInput.setTextDirection(View.TEXT_DIRECTION_LTR);
  passInput.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
  card.addView(passInput,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

  Button submit=primary(login?"تسجيل الدخول بأمان":"إنشاء الحساب");
  LinearLayout.LayoutParams submitParams=new LinearLayout.LayoutParams(-1,Ui.dp(this,58));
  submitParams.topMargin=Ui.dp(this,22);
  card.addView(submit,submitParams);
  Button switchBtn=Ui.button(this,login?"مستخدم جديد؟ أنشئ حساباً":"لديك حساب؟ سجّل الدخول");
  switchBtn.setBackground(Ui.ripple(Ui.bg(Color.TRANSPARENT,16)));
  switchBtn.setTextColor(Color.rgb(196,181,253));
  card.addView(switchBtn,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));
  TextView err=Ui.text(this,"",13,Color.rgb(251,113,133));
  err.setGravity(Gravity.CENTER);
  card.addView(err,new LinearLayout.LayoutParams(-1,-2));

  Ui.enter(mark,0);Ui.enter(brand,70);Ui.enter(secureChip,120);Ui.enter(card,170);
  submit.setOnClickListener(v->{if(authBusy)return;authBusy=true;submit.setEnabled(false);submit.setText("جارٍ التحقق…");err.setText("");String u=userInput.getText().toString().trim(),pword=passInput.getText().toString();if(!valid(u)||pword.length()<8){err.setText(!valid(u)?"اسم المستخدم غير صالح.":"كلمة المرور يجب أن تكون 8 أحرف على الأقل.");authBusy=false;submit.setEnabled(true);submit.setText(login?"تسجيل الدخول بأمان":"إنشاء الحساب");return;} if(login){auth.signInWithEmailAndPassword(email(u),pword).addOnCompleteListener(t->{authBusy=false;submit.setEnabled(true);submit.setText("تسجيل الدخول بأمان");if(!t.isSuccessful())err.setText(Errors.text(t.getException()));});}else register(u,pword,err,submit);});
  switchBtn.setOnClickListener(v->showAuth(!loginMode));
 }
 private boolean valid(String u){return u.matches("[A-Za-z0-9_.]{3,30}");} private String email(String u){return u.toLowerCase(Locale.US)+"@baghdadi.app";} private static String safeText(String value,String fallback){return value==null||value.trim().isEmpty()||"null".equals(value)?fallback:value;} private static String transportAvatar(String value){String avatar=safeText(value,"");return avatar.startsWith("data:")||avatar.length()>1500?"":avatar;}
 private void register(String u,String p,TextView err,Button submit){auth.createUserWithEmailAndPassword(email(u),p).addOnCompleteListener(t->{if(!t.isSuccessful()){authBusy=false;submit.setEnabled(true);submit.setText("إنشاء الحساب");err.setText(Errors.text(t.getException()));return;}FirebaseUser uo=t.getResult().getUser();Map<String,Object> user=new HashMap<>();user.put("uid",uo.getUid());user.put("username",u);user.put("usernameLower",u.toLowerCase(Locale.US));user.put("avatar",safeText(pendingAvatarData,AV));user.put("createdAt",FieldValue.serverTimestamp());user.put("lastSeen",FieldValue.serverTimestamp());DocumentReference ur=fs.collection("usernames").document(u.toLowerCase(Locale.US));DocumentReference pr=fs.collection("users").document(uo.getUid());fs.runTransaction(tx->{DocumentSnapshot s=tx.get(ur);if(s.exists())throw new FirebaseFirestoreException("اسم المستخدم مستخدم بالفعل.",FirebaseFirestoreException.Code.ALREADY_EXISTS);Map<String,Object> usernameDoc=new HashMap<>();usernameDoc.put("uid",uo.getUid());usernameDoc.put("username",u);usernameDoc.put("createdAt",FieldValue.serverTimestamp());tx.set(ur,usernameDoc);tx.set(pr,user);return null;}).addOnCompleteListener(x->{if(!x.isSuccessful()){uo.delete();authBusy=false;submit.setEnabled(true);submit.setText("إنشاء الحساب");err.setText(Errors.text(x.getException()));}else{authBusy=false;submit.setEnabled(true);pendingAvatarData="";loadProfile(uo);}});});}
 private void loadProfile(FirebaseUser u){if(u==null||isFinishing())return;if(u.getUid().equals(loadingUid))return;loadingUid=u.getUid();fs.collection("users").document(u.getUid()).get().addOnSuccessListener(d->{loadingUid=null;if(!d.exists()){toast("تعذر العثور على ملف الحساب. حاول تسجيل الدخول مجدداً.");return;}me=profileFrom(d);profileCache.put(me.uid,me);showHome();}).addOnFailureListener(e->{loadingUid=null;if(!isFinishing())toast("تعذر تحميل الحساب: "+Errors.text(e));});}
 private UserProfile profileFrom(DocumentSnapshot d){UserProfile value=new UserProfile();value.uid=d.getId();value.username=safeText(d.getString("username"),"مستخدم");value.usernameLower=safeText(d.getString("usernameLower"),value.username.toLowerCase(Locale.US));value.avatar=safeText(d.getString("avatar"),AV);return value;}
 private void showHome(){
  clearListeners();AppVisibility.clearCurrentChat();inConversation=false;inProfile=false;chatId=null;peer=null;base();
  LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(Ui.dp(this,8),Ui.dp(this,4),Ui.dp(this,8),Ui.dp(this,4));top.setBackground(Ui.elevatedPanel(22));top.setElevation(Ui.dp(this,5));
  TextView mark=Ui.text(this,"ب",21,Color.WHITE);mark.setGravity(Gravity.CENTER);mark.setTypeface(null,android.graphics.Typeface.BOLD);mark.setBackground(Ui.gradient());top.addView(mark,new LinearLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,44)));
  TextView brand=Ui.text(this,"بغدادي",22,TEXT);brand.setTypeface(null,android.graphics.Typeface.BOLD);brand.setPadding(Ui.dp(this,10),0,Ui.dp(this,10),0);top.addView(brand,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1));
  ImageButton search=Ui.imageButton(this,R.drawable.ic_search,"البحث",PANEL2,16);ImageButton add=Ui.imageButton(this,R.drawable.ic_add,"محادثة جديدة",Color.rgb(82,53,168),16);ImageButton profile=Ui.imageButton(this,R.drawable.ic_profile,"الملف الشخصي",PANEL2,16);
  loadAvatar(profile,me==null?AV:me.avatar);
  LinearLayout.LayoutParams iconParams=new LinearLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,44));iconParams.setMargins(Ui.dp(this,3),0,Ui.dp(this,3),0);top.addView(search,iconParams);top.addView(add,new LinearLayout.LayoutParams(iconParams));top.addView(profile,new LinearLayout.LayoutParams(iconParams));root.addView(top);
  LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(Ui.dp(this,2),Ui.dp(this,12),Ui.dp(this,2),0);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout headingRow=new LinearLayout(this);headingRow.setGravity(Gravity.CENTER_VERTICAL);TextView head=Ui.text(this,"الدردشات",28,TEXT);head.setTypeface(null,android.graphics.Typeface.BOLD);headingRow.addView(head,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1));chatCountView=Ui.text(this,"0 محادثة",12,MUTED);chatCountView.setGravity(Gravity.CENTER);chatCountView.setBackground(Ui.outlined(Color.argb(90,30,41,66),Color.argb(100,124,58,237),20));headingRow.addView(chatCountView,new LinearLayout.LayoutParams(Ui.dp(this,104),Ui.dp(this,36)));body.addView(headingRow);
  LinearLayout tabs=new LinearLayout(this);tabs.setPadding(Ui.dp(this,3),Ui.dp(this,3),Ui.dp(this,3),Ui.dp(this,3));tabs.setBackground(Ui.bg(PANEL,18));allChatsTab=Ui.button(this,"الكل (0)");unreadChatsTab=Ui.button(this,"غير مقروءة (0)");allChatsTab.setBackground(Ui.ripple(Ui.bg(Color.rgb(77,55,148),15)));unreadChatsTab.setBackground(Ui.ripple(Ui.bg(PANEL2,15)));tabs.addView(allChatsTab,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));tabs.addView(unreadChatsTab,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));body.addView(tabs);
  chatList=new LinearLayout(this);chatList.setOrientation(LinearLayout.VERTICAL);chatList.setPadding(0,Ui.dp(this,8),0,0);ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);scroll.addView(chatList);body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  Ui.enter(top,0);Ui.enter(body,35);
  allChatsTab.setOnClickListener(v->{filterUnread=false;allChatsTab.setBackground(Ui.ripple(Ui.bg(Color.rgb(77,55,148),15)));unreadChatsTab.setBackground(Ui.ripple(Ui.bg(PANEL2,15)));renderChats();});
  unreadChatsTab.setOnClickListener(v->{filterUnread=true;unreadChatsTab.setBackground(Ui.ripple(Ui.bg(Color.rgb(77,55,148),15)));allChatsTab.setBackground(Ui.ripple(Ui.bg(PANEL2,15)));renderChats();});
  search.setOnClickListener(v->searchUsers());add.setOnClickListener(v->searchUsers());profile.setOnClickListener(v->openProfile());loadChats();startPresence();listenIncomingCalls();requestNotifications();registerFcmToken();PushRelay.retryPending(this);promptBatteryOptimizationOnce();openPendingChat();
 }
 private void loadChats(){
  chatsReg=fs.collection("chats").whereArrayContains("participants",me.uid).addSnapshotListener((snap,e)->{
   if(e!=null){toast("تعذر تحميل الدردشات: "+Errors.text(e));return;}
   chats.clear();
   if(snap!=null)for(DocumentSnapshot d:snap.getDocuments()){
    List<String> participants=(List<String>)d.get("participants");if(participants==null||participants.size()<2)continue;
    Object deletedRaw=d.get("deletedFor");if(deletedRaw instanceof Map&&Boolean.TRUE.equals(((Map<?,?>)deletedRaw).get(me.uid)))continue;
    String peerUid=participants.get(0).equals(me.uid)?participants.get(1):participants.get(0);ChatModel item=new ChatModel();item.id=d.getId();item.peerUid=peerUid;
    item.lastMessage=safeText(d.getString("lastMessage"),"");item.lastMessageType=safeText(d.getString("lastMessageType"),"text");item.lastSenderId=safeText(d.getString("lastSenderId"),"");
    Timestamp updated=d.getTimestamp("updatedAt");if(updated!=null)item.updatedAt=updated.toDate().getTime();Object unread=d.get("unread");if(unread instanceof Map){Object count=((Map<?,?>)unread).get(me.uid);if(count instanceof Number)item.unread=Math.max(0,((Number)count).intValue());}
    Object pinnedRaw=d.get("pinnedBy");item.pinned=pinnedRaw instanceof Map&&Boolean.TRUE.equals(((Map<?,?>)pinnedRaw).get(me.uid));
    UserProfile cached=profileCache.get(peerUid);if(cached!=null){item.peerName=cached.username;item.peerAvatar=cached.avatar;}chats.add(item);
   }
   chats.sort((a,b)->a.pinned!=b.pinned?(a.pinned?-1:1):Long.compare(b.updatedAt,a.updatedAt));renderChats();
  });
 }
 private void renderChats(){
  if(chatList==null)return;chatList.removeAllViews();int unreadChats=0;for(ChatModel item:chats)if(item.unread>0)unreadChats++;
  if(chatCountView!=null)chatCountView.setText(arabicConversationCount(chats.size()));if(allChatsTab!=null)allChatsTab.setText("الكل ("+chats.size()+")");if(unreadChatsTab!=null)unreadChatsTab.setText("غير مقروءة ("+unreadChats+")");int shown=0;
  for(ChatModel item:chats){if(filterUnread&&item.unread==0)continue;
   LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(Ui.dp(this,12),Ui.dp(this,10),Ui.dp(this,12),Ui.dp(this,10));row.setBackground(Ui.ripple(Ui.elevatedPanel(20)));row.setElevation(Ui.dp(this,2));
   FrameLayout avatarStage=new FrameLayout(this);ImageView avatar=new ImageView(this);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setClipToOutline(true);avatar.setBackground(Ui.gradientCircle());avatarStage.addView(avatar,new FrameLayout.LayoutParams(-1,-1));View onlineDot=new View(this);onlineDot.setBackground(Ui.outlined(Color.rgb(34,197,94),PANEL,20));onlineDot.setVisibility(View.GONE);FrameLayout.LayoutParams dotParams=new FrameLayout.LayoutParams(Ui.dp(this,14),Ui.dp(this,14),Gravity.BOTTOM|Gravity.END);avatarStage.addView(onlineDot,dotParams);row.addView(avatarStage,new LinearLayout.LayoutParams(Ui.dp(this,58),Ui.dp(this,58)));
   LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(Ui.dp(this,12),0,Ui.dp(this,6),0);LinearLayout firstLine=new LinearLayout(this);firstLine.setGravity(Gravity.CENTER_VERTICAL);TextView name=Ui.text(this,(item.pinned?"📌  ":"")+safeText(item.peerName,"جارٍ التحميل…"),17,TEXT);name.setTypeface(null,android.graphics.Typeface.BOLD);TextView time=Ui.text(this,formatChatTime(item.updatedAt),10,MUTED);time.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);firstLine.addView(name,new LinearLayout.LayoutParams(0,Ui.dp(this,30),1));firstLine.addView(time,new LinearLayout.LayoutParams(-2,Ui.dp(this,30)));
   TextView last=Ui.text(this,messagePreview(item),12,item.unread>0?Color.rgb(222,228,248):MUTED);last.setSingleLine(true);last.setEllipsize(android.text.TextUtils.TruncateAt.END);if(item.unread>0)last.setTypeface(null,android.graphics.Typeface.BOLD);info.addView(firstLine);info.addView(last,new LinearLayout.LayoutParams(-1,Ui.dp(this,26)));row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
   TextView badge=Ui.text(this,item.unread>99?"99+":item.unread>0?String.valueOf(item.unread):"",11,Color.WHITE);badge.setGravity(Gravity.CENTER);if(item.unread>0)badge.setBackground(Ui.gradientCircle());row.addView(badge,new LinearLayout.LayoutParams(Ui.dp(this,32),Ui.dp(this,32)));
   LinearLayout.LayoutParams rowParams=new LinearLayout.LayoutParams(-1,Ui.dp(this,84));rowParams.setMargins(0,0,0,Ui.dp(this,8));chatList.addView(row,rowParams);row.setOnClickListener(v->openChat(item));row.setOnLongClickListener(v->{showChatMenu(item);return true;});
   UserProfile cached=profileCache.get(item.peerUid);if(cached!=null){applyRowProfile(item,cached,name,avatar);}else fs.collection("users").document(item.peerUid).get().addOnSuccessListener(snapshot->{if(!snapshot.exists()||isFinishing())return;UserProfile loaded=profileFrom(snapshot);profileCache.put(loaded.uid,loaded);applyRowProfile(item,loaded,name,avatar);});if(shown<8)Ui.enter(row,shown*14L);shown++;
  }
  if(shown==0){TextView empty=Ui.text(this,filterUnread?"لا توجد محادثات غير مقروءة":"ابدأ محادثة جديدة من زر +",15,MUTED);empty.setGravity(Gravity.CENTER);chatList.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,180)));}
 }
 private void showChatMenu(ChatModel item){
  ArrayList<String> actions=new ArrayList<>();actions.add(item.pinned?"إلغاء تثبيت الدردشة":"تثبيت الدردشة");actions.add("حذف الدردشة من قائمتي");
  new AlertDialog.Builder(this).setTitle(safeText(item.peerName,"خيارات الدردشة")).setItems(actions.toArray(new String[0]),(dialog,which)->{
   if(which==0){if(!item.pinned){int pinned=0;for(ChatModel c:chats)if(c.pinned)pinned++;if(pinned>=3){toast("يمكن تثبيت ثلاث دردشات فقط.");return;}}boolean previous=item.pinned,next=!previous;item.pinned=next;renderChats();fs.collection("chats").document(item.id).update("pinnedBy."+me.uid,next).addOnFailureListener(e->{item.pinned=previous;renderChats();toast("تعذر تحديث التثبيت.");});}
   else new AlertDialog.Builder(this).setTitle("حذف الدردشة").setMessage("ستختفي الدردشة من قائمتك فقط، وتعود عند وصول رسالة جديدة.").setPositiveButton("حذف",(d,w)->fs.collection("chats").document(item.id).update("deletedFor."+me.uid,true)).setNegativeButton("إلغاء",null).show();
  }).show();
 }
 private void applyRowProfile(ChatModel item,UserProfile loaded,TextView name,ImageView avatar){item.peerName=loaded.username;item.peerAvatar=loaded.avatar;name.setText((item.pinned?"📌  ":"")+loaded.username);loadAvatar(avatar,loaded.avatar);}
 private String messagePreview(ChatModel item){String value=safeText(item.lastMessage,"");if(value.isEmpty())return "ابدأ المحادثة";return me!=null&&me.uid.equals(item.lastSenderId)?"أنت: "+value:value;}
 private String arabicConversationCount(int count){if(count==0)return "لا توجد محادثات";if(count==1)return "محادثة واحدة";if(count==2)return "محادثتان";return count+" محادثة";}
 private String formatChatTime(long time){if(time<=0)return "";Calendar now=Calendar.getInstance(),then=Calendar.getInstance();then.setTimeInMillis(time);if(now.get(Calendar.YEAR)==then.get(Calendar.YEAR)&&now.get(Calendar.DAY_OF_YEAR)==then.get(Calendar.DAY_OF_YEAR))return new SimpleDateFormat("HH:mm",Locale.US).format(new Date(time));return new SimpleDateFormat("dd/MM",Locale.US).format(new Date(time));}
 private void openChat(ChatModel item){
  peer=profileCache.get(item.peerUid);
  if(peer==null){peer=new UserProfile();peer.uid=item.peerUid;peer.username=safeText(item.peerName,"مستخدم");peer.avatar=safeText(item.peerAvatar,AV);}
  chatId=item.id;
  showConversation();
 }
 private void showConversation(){
  clearListeners();renderedMessageIds.clear();inConversation=true;inProfile=false;base();AppVisibility.setCurrentChat(chatId);activeChatTheme=ChatTheme.load(this,chatId);root.setBackground(activeChatTheme.screen());cancelConversationNotification();
  LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(Ui.dp(this,6),Ui.dp(this,4),Ui.dp(this,6),Ui.dp(this,4));top.setBackground(activeChatTheme.panel(Ui.dp(this,22)));top.setElevation(Ui.dp(this,6));
  ImageButton back=Ui.imageButton(this,R.drawable.ic_back,"العودة",PANEL2,16);top.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,44),Ui.dp(this,44)));
  conversationAvatarView=new ImageView(this);conversationAvatarView.setScaleType(ImageView.ScaleType.CENTER_CROP);conversationAvatarView.setBackground(Ui.gradientCircle());conversationAvatarView.setClipToOutline(true);LinearLayout.LayoutParams peerImageParams=new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,46));peerImageParams.setMargins(Ui.dp(this,7),0,Ui.dp(this,7),0);top.addView(conversationAvatarView,peerImageParams);loadAvatar(conversationAvatarView,peer.avatar);
  LinearLayout peerInfo=new LinearLayout(this);peerInfo.setOrientation(LinearLayout.VERTICAL);conversationNameView=Ui.text(this,safeText(peer.username,"مستخدم"),17,TEXT);conversationNameView.setTypeface(null,android.graphics.Typeface.BOLD);status=Ui.text(this,"جارٍ التحقق من حالة الاتصال…",11,MUTED);peerInfo.addView(conversationNameView);peerInfo.addView(status);top.addView(peerInfo,new LinearLayout.LayoutParams(0,-2,1));
  TextView palette=Ui.text(this,"🎨",20,Color.WHITE);palette.setGravity(Gravity.CENTER);palette.setBackground(Ui.ripple(Ui.bg(Color.argb(90,255,255,255),16)));top.addView(palette,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42)));
  ImageButton audio=Ui.imageButton(this,R.drawable.ic_audio_call,"اتصال صوتي",PANEL2,17);ImageButton video=Ui.imageButton(this,R.drawable.ic_video_call,"اتصال فيديو",PANEL2,17);LinearLayout.LayoutParams callParams=new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,46));callParams.setMargins(Ui.dp(this,3),0,Ui.dp(this,3),0);top.addView(audio,callParams);top.addView(video,new LinearLayout.LayoutParams(callParams));root.addView(top,new LinearLayout.LayoutParams(-1,Ui.dp(this,62)));

  messages=new LinearLayout(this);messages.setOrientation(LinearLayout.VERTICAL);messages.setPadding(Ui.dp(this,7),Ui.dp(this,13),Ui.dp(this,7),Ui.dp(this,13));messageScroll=new ScrollView(this);messageScroll.setFillViewport(true);messageScroll.setVerticalScrollBarEnabled(false);messageScroll.setClipToPadding(false);messageScroll.addView(messages);root.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout typingRow=new LinearLayout(this);typingRow.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);typingRow.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);typingRow.setBackground(activeChatTheme.panel(Ui.dp(this,18)));typingIndicator=new TypingIndicatorView(this);typing=Ui.text(this,"يكتب الآن",11,Color.rgb(174,184,211));typingRow.addView(typingIndicator,new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,34)));typingRow.addView(typing,new LinearLayout.LayoutParams(-2,Ui.dp(this,34)));typingContainer=typingRow;typingContainer.setVisibility(View.GONE);root.addView(typingContainer,new LinearLayout.LayoutParams(-1,Ui.dp(this,36)));
  replyPreview=Ui.text(this,"",12,Color.rgb(196,181,253));replyPreview.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);replyPreview.setBackground(activeChatTheme.panel(Ui.dp(this,13)));replyPreview.setVisibility(View.GONE);root.addView(replyPreview,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));
  voiceStatusView=Ui.text(this,"",13,Color.rgb(253,164,175));voiceStatusView.setGravity(Gravity.CENTER);voiceStatusView.setTypeface(null,android.graphics.Typeface.BOLD);voiceStatusView.setBackground(Ui.outlined(Color.rgb(39,21,42),Color.rgb(105,36,58),14));voiceStatusView.setVisibility(View.GONE);root.addView(voiceStatusView,new LinearLayout.LayoutParams(-1,Ui.dp(this,40)));

  composer=new LinearLayout(this);composer.setGravity(Gravity.BOTTOM);composer.setPadding(Ui.dp(this,5),Ui.dp(this,6),Ui.dp(this,5),Ui.dp(this,6));composer.setBackground(activeChatTheme.panel(Ui.dp(this,22)));composer.setElevation(Ui.dp(this,8));
  ImageButton attach=Ui.imageButton(this,R.drawable.ic_attach,"إرفاق صورة أو ملف",PANEL2,17);messageInput=new EditText(this);messageInput.setHint("اكتب رسالة…");messageInput.setTextColor(TEXT);messageInput.setHintTextColor(MUTED);messageInput.setTextSize(15);messageInput.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL));messageInput.setBackground(activeChatTheme.incoming(Ui.dp(this,20)));messageInput.setPadding(Ui.dp(this,16),Ui.dp(this,10),Ui.dp(this,16),Ui.dp(this,10));messageInput.setMinHeight(Ui.dp(this,48));messageInput.setMaxHeight(Ui.dp(this,112));messageInput.setMaxLines(4);messageInput.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
  composerActionButton=Ui.imageButton(this,R.drawable.ic_mic_active,"تسجيل رسالة صوتية",Color.TRANSPARENT,24);composerActionButton.setPadding(Ui.dp(this,3),Ui.dp(this,3),Ui.dp(this,3),Ui.dp(this,3));
  composer.addView(attach,new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,48)));LinearLayout.LayoutParams messageParams=new LinearLayout.LayoutParams(0,-2,1);messageParams.setMargins(Ui.dp(this,5),0,Ui.dp(this,5),0);composer.addView(messageInput,messageParams);composer.addView(composerActionButton,new LinearLayout.LayoutParams(Ui.dp(this,50),Ui.dp(this,50)));LinearLayout.LayoutParams composerParams=new LinearLayout.LayoutParams(-1,-2);composerParams.topMargin=Ui.dp(this,4);root.addView(composer,composerParams);
  Ui.enter(top,0);Ui.enter(messageScroll,20);Ui.enter(composer,35);
  back.setOnClickListener(v->showHome());palette.setOnClickListener(v->showChatThemePicker());replyPreview.setOnClickListener(v->clearReply());audio.setOnClickListener(v->startCall(false));video.setOnClickListener(v->startCall(true));messageInput.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){boolean hasText=!s.toString().trim().isEmpty();setTyping(hasText);updateComposerAction(hasText);}public void afterTextChanged(android.text.Editable e){}});messageInput.setOnFocusChangeListener((v,focused)->{if(focused&&messageScroll!=null)messageScroll.postDelayed(()->messageScroll.fullScroll(View.FOCUS_DOWN),180);});attach.setOnClickListener(v->pickFile());composerSendMode=true;updateComposerAction(false);listenMessages();listenTyping();listenPeer();listenIncomingCalls();
 }
 private void listenMessages(){messagesReg=fs.collection("chats").document(chatId).collection("messages").orderBy("createdAt",Query.Direction.ASCENDING).limitToLast(250).addSnapshotListener(com.google.firebase.firestore.MetadataChanges.INCLUDE,(snapshot,error)->{if(error!=null){toast("تعذر تحميل الرسائل: "+Errors.text(error));return;}if(snapshot==null||messages==null)return;List<DocumentSnapshot> docs=snapshot.getDocuments();boolean appendOnly=!renderedMessageIds.isEmpty()&&docs.size()>=renderedMessageIds.size();if(appendOnly){for(int i=0;i<renderedMessageIds.size();i++)if(!renderedMessageIds.get(i).equals(docs.get(i).getId())){appendOnly=false;break;}if(appendOnly)for(DocumentChange change:snapshot.getDocumentChanges())if(change.getType()!=DocumentChange.Type.ADDED){appendOnly=false;break;}}if(!appendOnly){messages.removeAllViews();renderedMessageIds.clear();}int start=appendOnly?renderedMessageIds.size():0;for(int i=start;i<docs.size();i++){renderMessage(docs.get(i));renderedMessageIds.add(docs.get(i).getId());}markConversationRead(docs);if(messageScroll!=null)messageScroll.post(()->messageScroll.fullScroll(View.FOCUS_DOWN));});}
 private void markConversationRead(List<DocumentSnapshot> docs){if(chatId==null||me==null)return;com.google.firebase.firestore.WriteBatch batch=fs.batch();boolean changed=true;batch.update(fs.collection("chats").document(chatId),"unread."+me.uid,0);for(DocumentSnapshot d:docs){if(me.uid.equals(d.getString("senderId")))continue;List<String> read=(List<String>)d.get("readBy"),delivered=(List<String>)d.get("deliveredBy");if((read==null||!read.contains(me.uid))||(delivered==null||!delivered.contains(me.uid))){batch.update(d.getReference(),"deliveredBy",FieldValue.arrayUnion(me.uid),"readBy",FieldValue.arrayUnion(me.uid),"readAt",FieldValue.serverTimestamp());changed=true;}}if(changed)batch.commit();}
 private void renderMessage(DocumentSnapshot document){
  String sender=safeText(document.getString("senderId"),"");boolean mine=me.uid.equals(sender);String type=safeText(document.getString("type"),"text");String text=safeText(document.getString("text"),"");boolean deleted=Boolean.TRUE.equals(document.get("deleted"));if(deleted)text="تم حذف هذه الرسالة";final String messageText=text;boolean pending=document.getMetadata().hasPendingWrites();
  LinearLayout bubble=new LinearLayout(this);bubble.setOrientation(LinearLayout.VERTICAL);bubble.setPadding("audio".equals(type)?0:Ui.dp(this,14),"audio".equals(type)?0:Ui.dp(this,10),"audio".equals(type)?0:Ui.dp(this,14),Ui.dp(this,8));
  if("audio".equals(type))bubble.setBackgroundColor(Color.TRANSPARENT);else bubble.setBackground(mine?activeChatTheme.outgoing(Ui.dp(this,20)):activeChatTheme.incoming(Ui.dp(this,20)));bubble.setElevation("audio".equals(type)?0:Ui.dp(this,1));
  int maxBubbleWidth=(int)(getResources().getDisplayMetrics().widthPixels*.80f);String replied=document.getString("replyText");if(replied!=null&&!replied.trim().isEmpty()){TextView reply=Ui.text(this,"↩  "+replied,11,Color.rgb(224,228,248));reply.setMaxWidth(maxBubbleWidth);reply.setSingleLine(true);reply.setEllipsize(android.text.TextUtils.TruncateAt.END);reply.setPadding(Ui.dp(this,8),Ui.dp(this,5),Ui.dp(this,8),Ui.dp(this,5));reply.setBackground(Ui.bg(Color.argb(80,6,10,20),10));bubble.addView(reply,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));}
  String url=safeText(document.getString("url"),""),base64=safeText(document.getString("base64"),"");
  if(deleted){TextView deletedText=Ui.text(this,"⊘  "+text,14,MUTED);deletedText.setMaxWidth(maxBubbleWidth);bubble.addView(deletedText);}
  else if("image".equals(type)){String source=!base64.isEmpty()?base64:url;ImageView image=new ImageView(this);image.setAdjustViewBounds(true);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setMaxWidth(Math.min(maxBubbleWidth,Ui.dp(this,310)));image.setMaxHeight(Ui.dp(this,390));image.setBackground(Ui.bg(Color.rgb(9,14,27),14));image.setClipToOutline(true);com.bumptech.glide.Glide.with(this).load(source).placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar).into(image);bubble.addView(image,new LinearLayout.LayoutParams(Math.min(maxBubbleWidth,Ui.dp(this,310)),-2));image.setOnClickListener(v->showImageViewer(source));}
  else if("video".equals(type)){TextView video=attachmentLabel("▶",safeText(document.getString("name"),"فيديو"));bubble.addView(video,new LinearLayout.LayoutParams(Math.min(maxBubbleWidth,Ui.dp(this,270)),Ui.dp(this,54)));video.setOnClickListener(v->openExternal(url,safeText(document.getString("mime"),"video/*")));}
  else if("audio".equals(type)){Object raw=document.get("durationMs");long durationMs=raw instanceof Number?((Number)raw).longValue():0L;VoiceMessageView audio=new VoiceMessageView(this,mine,activeChatTheme.first,activeChatTheme.second);audio.setContentDescription("تشغيل أو إيقاف الرسالة الصوتية");audio.setState(durationMs,false,false,0,false);bubble.addView(audio,new LinearLayout.LayoutParams(Math.min(maxBubbleWidth,Ui.dp(this,282)),Ui.dp(this,62)));if(document.getId().equals(activeVoiceMessageId)){activeVoicePlaybackButton=audio;updateVoicePlaybackButton();}audio.setOnClickListener(v->playVoiceMessage(document,audio,durationMs));}
  else if("file".equals(type)){TextView file=attachmentLabel("↗",safeText(document.getString("name"),"ملف مرفق"));bubble.addView(file,new LinearLayout.LayoutParams(Math.min(maxBubbleWidth,Ui.dp(this,270)),Ui.dp(this,54)));file.setOnClickListener(v->openExternal(url,safeText(document.getString("mime"),"*/*")));}
  else if("call".equals(type)){TextView call=Ui.text(this,callLogText(document,mine),14,TEXT);call.setTypeface(null,android.graphics.Typeface.BOLD);call.setPadding(Ui.dp(this,6),Ui.dp(this,5),Ui.dp(this,6),Ui.dp(this,5));call.setMaxWidth(maxBubbleWidth);bubble.addView(call,new LinearLayout.LayoutParams(Math.min(maxBubbleWidth,Ui.dp(this,270)),Ui.dp(this,52)));}
  else{TextView body=Ui.text(this,text,15,TEXT);body.setMaxWidth(maxBubbleWidth);body.setTextIsSelectable(false);body.setLineSpacing(0,1.08f);bubble.addView(body);}
  String edited=document.get("editedAt")!=null?"معدلة  •  ":"",reactionText="";Object reactions=document.get("reactions");if(reactions instanceof Map&&!((Map<?,?>)reactions).isEmpty())reactionText="  ❤️ "+((Map<?,?>)reactions).size();else if(document.get("reaction")!=null)reactionText="  "+String.valueOf(document.get("reaction"));Timestamp created=document.getTimestamp("createdAt");if(created==null)created=document.getTimestamp("clientCreatedAt");String timestamp=created==null?"الآن":new SimpleDateFormat("HH:mm",Locale.US).format(created.toDate());
  LinearLayout metaRow=new LinearLayout(this);metaRow.setGravity(Gravity.CENTER_VERTICAL|Gravity.END);TextView meta=Ui.text(this,edited+timestamp+reactionText,10,mine?Color.rgb(226,229,247):Color.rgb(168,180,204));metaRow.addView(meta,new LinearLayout.LayoutParams(-2,Ui.dp(this,23)));if(mine&&!"call".equals(type)){List<String> delivered=(List<String>)document.get("deliveredBy"),read=(List<String>)document.get("readBy");boolean readByPeer=peer!=null&&read!=null&&read.contains(peer.uid),deliveredToPeer=peer!=null&&delivered!=null&&delivered.contains(peer.uid);String state=pending?" ◷":readByPeer?" ✓✓":deliveredToPeer?" ✓✓":" ✓";TextView ticks=Ui.text(this,state,11,readByPeer?Color.rgb(73,176,255):Color.rgb(220,226,241));ticks.setTypeface(null,android.graphics.Typeface.BOLD);metaRow.addView(ticks,new LinearLayout.LayoutParams(-2,Ui.dp(this,23)));}bubble.addView(metaRow,new LinearLayout.LayoutParams(-1,Ui.dp(this,24)));
  LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-2,-2);params.gravity=mine?Gravity.END:Gravity.START;params.setMargins(mine?Ui.dp(this,36):0,Ui.dp(this,3),mine?0:Ui.dp(this,36),Ui.dp(this,4));messages.addView(bubble,params);if(!deleted&&!"call".equals(type)){bubble.setOnLongClickListener(v->{showMessageMenu(bubble,document,messageText);return true;});attachSwipeToReply(bubble,document,messageText);}
 }
 private String callLogText(DocumentSnapshot document,boolean mine){String status=safeText(document.getString("callStatus"),"missed"),callType=safeText(document.getString("callType"),"audio");long duration=document.getLong("durationSec")==null?0:document.getLong("durationSec");String icon="video".equals(callType)?"🎥":"📞",direction=mine?"↗":"↙";if("accepted".equals(status))return icon+"  "+direction+" مكالمة  •  "+formatTime(duration*1000);if("rejected".equals(status))return icon+"  "+direction+" مكالمة مرفوضة";if("busy".equals(status))return icon+"  "+direction+" في مكالمة أخرى";if("cancelled".equals(status))return icon+"  "+direction+" مكالمة ملغاة";return icon+"  "+direction+" مكالمة فائتة";}
 private TextView attachmentLabel(String icon,String name){TextView view=Ui.text(this,icon+"   "+name,14,TEXT);view.setGravity(Gravity.CENTER_VERTICAL);view.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);view.setSingleLine(true);view.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);view.setBackground(Ui.bg(Color.argb(105,6,12,25),14));return view;}
 private void showImageViewer(String source){if(source==null||source.trim().isEmpty())return;Dialog dialog=new Dialog(this,android.R.style.Theme_Black_NoTitleBar_Fullscreen);FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(Color.rgb(3,5,11));ZoomImageView image=new ZoomImageView(this);frame.addView(image,new FrameLayout.LayoutParams(-1,-1));com.bumptech.glide.Glide.with(this).load(source).into(image);LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);actions.setPadding(Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,5));actions.setBackground(Ui.bg(Color.argb(190,15,23,42),24));TextView save=Ui.text(this,"⬇  حفظ",14,Color.WHITE);save.setGravity(Gravity.CENTER);TextView close=Ui.text(this,"✕",22,Color.WHITE);close.setGravity(Gravity.CENTER);actions.addView(save,new LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,48)));actions.addView(close,new LinearLayout.LayoutParams(Ui.dp(this,54),Ui.dp(this,48)));FrameLayout.LayoutParams actionParams=new FrameLayout.LayoutParams(-2,Ui.dp(this,58),Gravity.TOP|Gravity.END);actionParams.setMargins(0,Ui.dp(this,18),Ui.dp(this,14),0);frame.addView(actions,actionParams);close.setOnClickListener(v->dialog.dismiss());save.setOnClickListener(v->saveImageToGallery(source));dialog.setContentView(frame);dialog.show();}
 private void saveImageToGallery(String source){if(Build.VERSION.SDK_INT<29&&checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){pendingImageSource=source;requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},REQ_SAVE);return;}toast("جارٍ حفظ الصورة…");new Thread(()->{try{byte[] bytes=readImageBytes(source);String name="Baghdadi_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".jpg";if(Build.VERSION.SDK_INT>=29){android.content.ContentValues values=new android.content.ContentValues();values.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,name);values.put(android.provider.MediaStore.Images.Media.MIME_TYPE,"image/jpeg");values.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,android.os.Environment.DIRECTORY_PICTURES+"/Baghdadi");values.put(android.provider.MediaStore.Images.Media.IS_PENDING,1);Uri uri=getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new java.io.IOException("insert_failed");try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new java.io.IOException("open_failed");out.write(bytes);}values.clear();values.put(android.provider.MediaStore.Images.Media.IS_PENDING,0);getContentResolver().update(uri,values,null,null);}else{java.io.File dir=new java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES),"Baghdadi");if(!dir.exists()&&!dir.mkdirs())throw new java.io.IOException("mkdir_failed");try(java.io.FileOutputStream out=new java.io.FileOutputStream(new java.io.File(dir,name))){out.write(bytes);}}handler.post(()->toast("تم حفظ الصورة في Pictures/Baghdadi ✓"));}catch(Exception e){handler.post(()->toast("تعذر حفظ الصورة."));}},"BaghdadiImageSaver").start();}
 private byte[] readImageBytes(String source)throws Exception{if(source.startsWith("data:")){int comma=source.indexOf(',');if(comma<0)throw new java.io.IOException("invalid_data");return android.util.Base64.decode(source.substring(comma+1),android.util.Base64.DEFAULT);}java.net.HttpURLConnection connection=(java.net.HttpURLConnection)new java.net.URL(source).openConnection();connection.setConnectTimeout(12000);connection.setReadTimeout(20000);connection.setInstanceFollowRedirects(true);try(java.io.InputStream in=connection.getInputStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] buffer=new byte[8192];int read,total=0;while((read=in.read(buffer))!=-1){total+=read;if(total>20_000_000)throw new java.io.IOException("too_large");out.write(buffer,0,read);}return out.toByteArray();}finally{connection.disconnect();}}
 private void openExternal(String url,String mime){try{Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url));if(mime!=null&&!mime.equals("null")&&!mime.trim().isEmpty())intent.setDataAndType(Uri.parse(url),mime);startActivity(intent);}catch(Exception e){toast("لا يوجد تطبيق مناسب لفتح هذا الملف.");}}
 private void setReplyFromMessage(DocumentSnapshot d,String txt){replyToId=d.getId();replyToText=txt==null||txt.trim().isEmpty()?messageTypeLabel(safeText(d.getString("type"),"text")):txt;replyPreview.setText("↩ الرد على: "+replyToText+"   ×");replyPreview.setVisibility(View.VISIBLE);messageInput.requestFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(messageInput,InputMethodManager.SHOW_IMPLICIT);}
 private String messageTypeLabel(String type){if("image".equals(type))return "صورة";if("video".equals(type))return "فيديو";if("audio".equals(type))return "رسالة صوتية";if("file".equals(type))return "ملف";return "رسالة";}
 private void attachSwipeToReply(View bubble,DocumentSnapshot d,String txt){final float[] down={0,0};final boolean[] horizontal={false};bubble.setClickable(true);bubble.setOnTouchListener((v,event)->{switch(event.getActionMasked()){case MotionEvent.ACTION_DOWN:down[0]=event.getRawX();down[1]=event.getRawY();horizontal[0]=false;return false;case MotionEvent.ACTION_MOVE:float dx=event.getRawX()-down[0],dy=event.getRawY()-down[1];if(!horizontal[0]&&Math.abs(dx)>Ui.dp(this,10)&&Math.abs(dx)>Math.abs(dy)*1.25f)horizontal[0]=true;if(horizontal[0]){v.getParent().requestDisallowInterceptTouchEvent(true);v.setTranslationX(Math.max(0,Math.min(dx,Ui.dp(this,92))));return true;}return false;case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:float moved=v.getTranslationX();v.animate().translationX(0).setDuration(180).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();v.getParent().requestDisallowInterceptTouchEvent(false);if(moved>Ui.dp(this,66)){v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);setReplyFromMessage(d,txt);}return horizontal[0];default:return false;}});}
 private void showMessageMenu(View anchor,DocumentSnapshot d,String txt){if(Build.VERSION.SDK_INT>=31&&root!=null)root.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(12f,12f,android.graphics.Shader.TileMode.CLAMP));LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,12),Ui.dp(this,10));panel.setBackground(Ui.outlined(Color.argb(245,24,30,49),Color.argb(190,130,106,255),22));LinearLayout reactions=new LinearLayout(this);reactions.setGravity(Gravity.CENTER);String[] emojis={"❤️","😂","😮","😢","👍","🔥"};PopupWindow popup=new PopupWindow(panel,Ui.dp(this,300),-2,true);for(String emoji:emojis){TextView reaction=Ui.text(this,emoji,23,Color.WHITE);reaction.setGravity(Gravity.CENTER);reactions.addView(reaction,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));reaction.setOnClickListener(v->{d.getReference().update("reactions."+me.uid,emoji);popup.dismiss();});}panel.addView(reactions,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));boolean mine=me.uid.equals(d.getString("senderId"));ArrayList<String> actions=new ArrayList<>();actions.add("↩  رد");if("text".equals(d.getString("type")))actions.add("⧉  نسخ");if(mine&&"text".equals(d.getString("type")))actions.add("✎  تعديل");if(mine)actions.add("⌫  حذف لدى الجميع");for(String action:actions){TextView item=Ui.text(this,action,14,action.contains("حذف")?Color.rgb(253,164,175):TEXT);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(Ui.dp(this,14),0,Ui.dp(this,14),0);panel.addView(item,new LinearLayout.LayoutParams(-1,Ui.dp(this,44)));item.setOnClickListener(v->{popup.dismiss();if(action.contains("رد"))setReplyFromMessage(d,txt);else if(action.contains("نسخ")){android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);clipboard.setPrimaryClip(android.content.ClipData.newPlainText("رسالة بغدادي",txt));toast("تم النسخ ✓");}else if(action.contains("تعديل"))editMessage(d,txt);else d.getReference().update("deleted",true,"text","","url","","base64","","editedAt",FieldValue.serverTimestamp());});}popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));popup.setOutsideTouchable(true);popup.setElevation(Ui.dp(this,18));popup.setOnDismissListener(()->{if(Build.VERSION.SDK_INT>=31&&root!=null)root.setRenderEffect(null);});panel.measure(View.MeasureSpec.makeMeasureSpec(Ui.dp(this,300),View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED));int x=anchor.getWidth()/2-Ui.dp(this,150),y=-anchor.getHeight()-panel.getMeasuredHeight()-Ui.dp(this,6);popup.showAsDropDown(anchor,x,y);}
 private void editMessage(DocumentSnapshot d,String current){EditText edit=input("نص الرسالة");edit.setText(current);edit.setSelection(edit.length());new AlertDialog.Builder(this).setTitle("تعديل الرسالة").setView(edit).setPositiveButton("حفظ",(dialog,which)->{String value=edit.getText().toString().trim();if(!value.isEmpty())d.getReference().update("text",value,"editedAt",FieldValue.serverTimestamp());}).setNegativeButton("إلغاء",null).show();}
 private void clearReply(){replyToId=null;replyToText=null;if(replyPreview!=null){replyPreview.setText("");replyPreview.setVisibility(View.GONE);}}
 private void sendText(){String text=messageInput.getText().toString().trim();if(text.isEmpty())return;Map<String,Object> message=new HashMap<>();message.put("senderId",me.uid);message.put("type","text");message.put("text",text);sendMessage(message,text,()->{messageInput.setText("");clearReply();stopTyping();});}
 private void sendMessage(Map<String,Object> message,String preview,Runnable success){sendQueuedMessage(chatId,peer==null?null:peer.uid,message,preview,String.valueOf(message.get("type")),replyToId,replyToText,success);}
 private void sendQueuedMessage(String targetChat,String targetPeer,Map<String,Object> message,String preview,String messageType,String capturedReplyId,String capturedReplyText,Runnable queued){if(targetChat==null||me==null)return;DocumentReference ref=fs.collection("chats").document(targetChat).collection("messages").document();PushRelay.rememberMessage(this,targetChat,ref.getId());message.put("createdAt",FieldValue.serverTimestamp());message.put("clientCreatedAt",new Timestamp(new Date()));message.put("readBy",Collections.singletonList(me.uid));message.put("deliveredBy",Collections.singletonList(me.uid));message.put("deleted",false);if(capturedReplyId!=null){message.put("replyTo",capturedReplyId);message.put("replyText",capturedReplyText);}afterMessageCreated(targetChat,targetPeer,ref.getId(),preview,messageType);if(queued!=null)queued.run();ref.set(message).addOnSuccessListener(unused->PushRelay.notifyMessage(this,targetChat,ref.getId())).addOnFailureListener(e->toast("ستبقى الرسالة معلقة حتى يعود الإنترنت."));}
 private void afterMessageCreated(String targetChat,String targetPeer,String messageId,String preview,String messageType){
  Map<String,Object> update=new HashMap<>();
  update.put("lastMessage",preview==null||preview.trim().isEmpty()?"رسالة جديدة":preview);
  update.put("lastMessageType",messageType==null?"text":messageType);
  update.put("lastSenderId",me==null?"":me.uid);
  update.put("updatedAt",FieldValue.serverTimestamp());
  if(targetPeer!=null&&!targetPeer.trim().isEmpty()){update.put("unread."+targetPeer,FieldValue.increment(1));update.put("deletedFor."+targetPeer,false);}if(me!=null)update.put("deletedFor."+me.uid,false);
  fs.collection("chats").document(targetChat).set(update,com.google.firebase.firestore.SetOptions.merge());
 }
 private void searchUsers(){
  final Dialog dialog=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(Ui.dp(this,20),Ui.dp(this,20),Ui.dp(this,20),Ui.dp(this,16));box.setBackground(Ui.elevatedPanel(24));TextView heading=Ui.text(this,"محادثة جديدة",24,TEXT);heading.setTypeface(null,android.graphics.Typeface.BOLD);box.addView(heading,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));TextView hint=Ui.text(this,"ابحث باسم المستخدم الفريد",13,MUTED);box.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));EditText query=input("اكتب اسم المستخدم…");box.addView(query,new LinearLayout.LayoutParams(-1,Ui.dp(this,56)));LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);results.setPadding(0,Ui.dp(this,10),0,0);ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);scroll.addView(results);box.addView(scroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,360)));dialog.setContentView(box);dialog.show();Window window=dialog.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24),Ui.dp(this,430)),Ui.dp(this,540));window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);}
  query.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){String value=s.toString().trim().toLowerCase(Locale.US);results.removeAllViews();if(value.length()<2){TextView empty=Ui.text(MainActivity.this,"اكتب حرفين على الأقل",13,MUTED);empty.setGravity(Gravity.CENTER);results.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(MainActivity.this,90)));return;}fs.collection("users").whereGreaterThanOrEqualTo("usernameLower",value).whereLessThanOrEqualTo("usernameLower",value+"\uf8ff").limit(12).get().addOnSuccessListener(snapshot->{if(!query.getText().toString().trim().toLowerCase(Locale.US).equals(value))return;results.removeAllViews();for(DocumentSnapshot user:snapshot){if(me==null||user.getId().equals(me.uid))continue;UserProfile found=profileFrom(user);LinearLayout row=new LinearLayout(MainActivity.this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(Ui.dp(MainActivity.this,10),Ui.dp(MainActivity.this,7),Ui.dp(MainActivity.this,10),Ui.dp(MainActivity.this,7));row.setBackground(Ui.ripple(Ui.bg(PANEL2,17)));ImageView avatar=new ImageView(MainActivity.this);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setClipToOutline(true);loadAvatar(avatar,found.avatar);row.addView(avatar,new LinearLayout.LayoutParams(Ui.dp(MainActivity.this,46),Ui.dp(MainActivity.this,46)));TextView name=Ui.text(MainActivity.this,"@"+found.username,16,TEXT);name.setTypeface(null,android.graphics.Typeface.BOLD);name.setPadding(Ui.dp(MainActivity.this,12),0,Ui.dp(MainActivity.this,12),0);row.addView(name,new LinearLayout.LayoutParams(0,Ui.dp(MainActivity.this,52),1));TextView open=Ui.text(MainActivity.this,"بدء ›",12,Color.rgb(196,181,253));row.addView(open,new LinearLayout.LayoutParams(-2,Ui.dp(MainActivity.this,52)));LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,Ui.dp(MainActivity.this,64));params.setMargins(0,0,0,Ui.dp(MainActivity.this,6));results.addView(row,params);row.setOnClickListener(v->openFoundUser(dialog,found));}if(results.getChildCount()==0){TextView empty=Ui.text(MainActivity.this,"لا يوجد مستخدم بهذا الاسم",13,MUTED);empty.setGravity(Gravity.CENTER);results.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(MainActivity.this,100)));}});}public void afterTextChanged(android.text.Editable editable){}});query.requestFocus();
 }
 private void openFoundUser(Dialog dialog,UserProfile found){String id=cid(me.uid,found.uid);DocumentReference reference=fs.collection("chats").document(id);fs.runTransaction(transaction->{DocumentSnapshot existing=transaction.get(reference);if(!existing.exists()){Map<String,Object> chat=new HashMap<>();chat.put("participants",Arrays.asList(me.uid,found.uid));chat.put("type","direct");chat.put("updatedAt",FieldValue.serverTimestamp());chat.put("lastMessage","");chat.put("lastMessageType","text");chat.put("lastSenderId","");Map<String,Object> unread=new HashMap<>();unread.put(me.uid,0);unread.put(found.uid,0);chat.put("unread",unread);transaction.set(reference,chat);}return null;}).addOnSuccessListener(unused->{dialog.dismiss();profileCache.put(found.uid,found);ChatModel item=new ChatModel();item.id=id;item.peerUid=found.uid;item.peerName=found.username;item.peerAvatar=found.avatar;openChat(item);}).addOnFailureListener(error->toast("تعذر فتح المحادثة: "+Errors.text(error)));}
 private String cid(String a,String b){return a.compareTo(b)<0?a+"_"+b:b+"_"+a;}
 private void listenPeer(){
  peerReg=fs.collection("users").document(peer.uid).addSnapshotListener((snapshot,error)->{if(snapshot==null||!snapshot.exists())return;UserProfile loaded=profileFrom(snapshot);profileCache.put(loaded.uid,loaded);peer=loaded;if(conversationNameView!=null)conversationNameView.setText(loaded.username);if(conversationAvatarView!=null)loadAvatar(conversationAvatarView,loaded.avatar);});
  DatabaseReference reference=rtdb.getReference("presence").child(peer.uid);
  peerPresenceListener=reference.addValueEventListener(new ValueEventListener(){public void onDataChange(DataSnapshot snapshot){boolean online=false;long latest=0;for(DataSnapshot connection:snapshot.child("connections").getChildren()){String state=connection.child("state").getValue(String.class);Object changed=connection.child("last_changed").getValue();if(changed instanceof Number)latest=Math.max(latest,((Number)changed).longValue());if("online".equals(state))online=true;}peerOnline=online;peerLastSeen=latest;updatePresenceLabel();}public void onCancelled(DatabaseError error){peerOnline=false;updatePresenceLabel();}});
  if(presenceTicker!=null)handler.removeCallbacks(presenceTicker);presenceTicker=new Runnable(){@Override public void run(){updatePresenceLabel();if(inConversation)handler.postDelayed(this,30000);}};handler.post(presenceTicker);
 }
 private void updatePresenceLabel(){if(status==null)return;if(peerOnline){status.setText("● متصل الآن");status.setTextColor(Color.rgb(74,222,128));return;}status.setTextColor(MUTED);if(peerLastSeen<=0){status.setText("غير متصل");return;}long age=System.currentTimeMillis()-peerLastSeen;if(age<60000){status.setText("آخر ظهور الآن");return;}Calendar now=Calendar.getInstance(),then=Calendar.getInstance();then.setTimeInMillis(peerLastSeen);String clock=new SimpleDateFormat("HH:mm",Locale.US).format(new Date(peerLastSeen));if(now.get(Calendar.YEAR)==then.get(Calendar.YEAR)&&now.get(Calendar.DAY_OF_YEAR)==then.get(Calendar.DAY_OF_YEAR))status.setText("آخر ظهور اليوم، "+clock);else if(now.get(Calendar.YEAR)==then.get(Calendar.YEAR)&&now.get(Calendar.DAY_OF_YEAR)-then.get(Calendar.DAY_OF_YEAR)==1)status.setText("آخر ظهور أمس، "+clock);else status.setText("آخر ظهور "+new SimpleDateFormat("dd/MM/yyyy، HH:mm",Locale.US).format(new Date(peerLastSeen)));}
 private void listenTyping(){if(typingListenRef!=null&&typingReg!=null)typingListenRef.removeEventListener(typingReg);typingListenRef=rtdb.getReference("typing").child(chatId).child(peer.uid);typingReg=new ValueEventListener(){public void onDataChange(DataSnapshot snapshot){showIncomingTyping(Boolean.TRUE.equals(snapshot.getValue(Boolean.class)));}public void onCancelled(DatabaseError error){showIncomingTyping(false);}};typingListenRef.addValueEventListener(typingReg);}
 private void showIncomingTyping(boolean visible){if(typingContainer==null)return;if(incomingTypingHide!=null)handler.removeCallbacks(incomingTypingHide);if(!visible){typingContainer.setVisibility(View.GONE);if(typingIndicator!=null)typingIndicator.stop();return;}typingContainer.setVisibility(View.VISIBLE);typingContainer.setAlpha(0f);typingContainer.animate().alpha(1f).setDuration(150).start();if(typingIndicator!=null)typingIndicator.start();incomingTypingHide=()->showIncomingTyping(false);handler.postDelayed(incomingTypingHide,2600);}
 private void setTyping(boolean on){if(typingRef==null)typingRef=rtdb.getReference("typing").child(chatId).child(me.uid);if(on){typingRef.onDisconnect().removeValue();typingRef.setValue(true);if(typingStop!=null)handler.removeCallbacks(typingStop);typingStop=()->stopTyping();handler.postDelayed(typingStop,1800);}else stopTyping();}
 private void stopTyping(){if(typingRef!=null)typingRef.removeValue();if(typingStop!=null)handler.removeCallbacks(typingStop);}
 private void startPresence(){stopPresence();DatabaseReference connected=rtdb.getReference(".info/connected");presenceRef=rtdb.getReference("presence").child(me.uid).child("connections").child(UUID.randomUUID().toString());connectedListener=connected.addValueEventListener(new ValueEventListener(){public void onDataChange(DataSnapshot s){if(Boolean.TRUE.equals(s.getValue(Boolean.class))){Map<String,Object> off=new HashMap<>();off.put("state","offline");off.put("last_changed",ServerValue.TIMESTAMP);presenceRef.onDisconnect().setValue(off);Map<String,Object> on=new HashMap<>();on.put("state","online");on.put("last_changed",ServerValue.TIMESTAMP);presenceRef.setValue(on);}}public void onCancelled(DatabaseError e){}});}
 private void stopPresence(){if(connectedListener!=null&&me!=null)rtdb.getReference(".info/connected").removeEventListener(connectedListener);if(presenceRef!=null){Map<String,Object> off=new HashMap<>();off.put("state","offline");off.put("last_changed",ServerValue.TIMESTAMP);presenceRef.setValue(off);}connectedListener=null;presenceRef=null;}
 private void listenIncomingCalls(){
   if(incomingReg!=null) incomingReg.remove();
   incomingReg=fs.collection("calls").whereEqualTo("calleeId",me.uid).limit(10).addSnapshotListener((snap,e)->{
     if(e!=null||snap==null)return;
     for(DocumentChange c:snap.getDocumentChanges()){
      if(c.getType()==DocumentChange.Type.REMOVED)continue;
      DocumentSnapshot d=c.getDocument();
      String callStatus=d.getString("status");
      if("ended".equals(callStatus)||"rejected".equals(callStatus)||"missed".equals(callStatus)||"expired".equals(callStatus)){handledIncomingCalls.remove(d.getId());continue;}
      if(!("waiting".equals(callStatus)||"preparing".equals(callStatus)||"ringing".equals(callStatus)))continue;
      Timestamp created=d.getTimestamp("createdAt");
      if(created!=null&&System.currentTimeMillis()-created.toDate().getTime()>15*60*1000L)continue;
      if("waiting".equals(callStatus)||"preparing".equals(callStatus))d.getReference().update("status","ringing","deliveredAt",FieldValue.serverTimestamp(),"updatedAt",FieldValue.serverTimestamp());
      if(!appVisible||!AppPreferences.useFullScreenCalls(this)||handledIncomingCalls.contains(d.getId()))continue;
      handledIncomingCalls.add(d.getId());
      Intent i=new Intent(this,CallActivity.class);i.putExtra("callId",d.getId());i.putExtra("role","callee");i.putExtra("type",String.valueOf(d.get("type")));i.putExtra("peerUid",String.valueOf(d.get("callerId")));i.putExtra("peerName",safeText(d.getString("callerName"),"مكالمة واردة"));i.putExtra("peerAvatar",safeText(d.getString("callerAvatar"),""));startActivity(i);break;
     }
   });
  }
 private void registerFcmToken(){FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token->{if(me!=null)DeviceRegistry.register(this,me.uid,token);});}
 private void startCall(boolean video){
  if(callStarting)return;
  if(recorder!=null){toast("ارفع إصبعك لإرسال التسجيل أولاً.");return;}
  if(peer==null||me==null)return;
  if(video&&!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)){toast("هذا الجهاز لا يحتوي على كاميرا متاحة.");return;}
  boolean microphoneMissing=checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED;
  boolean cameraMissing=video&&checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED;
  if(microphoneMissing||cameraMissing){pendingCallType=video?2:1;requestMedia(video);return;}
  pendingCallType=0;callStarting=true;
  DocumentReference ref=fs.collection("calls").document();
  ActiveCallRegistry.checkPeerAvailableAndReserve(me.uid,peer.uid,ref.getId(),new ActiveCallRegistry.ClaimCallback(){
   @Override public void onClaimed(){
    Map<String,Object> c=new HashMap<>();
    c.put("callerId",me.uid);c.put("calleeId",peer.uid);c.put("type",video?"video":"audio");
    c.put("callerName",me.username);c.put("callerAvatar",transportAvatar(me.avatar));c.put("calleeName",peer.username);c.put("calleeAvatar",transportAvatar(peer.avatar));
    c.put("status","waiting");c.put("createdAt",FieldValue.serverTimestamp());c.put("updatedAt",FieldValue.serverTimestamp());
    c.put("expiresAt",new Timestamp(new java.util.Date(System.currentTimeMillis()+90*1000L)));
    ref.set(c).addOnSuccessListener(unused->{
     PushRelay.notifyCall(MainActivity.this,ref.getId());
     try{Intent i=new Intent(MainActivity.this,CallActivity.class);i.putExtra("callId",ref.getId());i.putExtra("role","caller");i.putExtra("type",video?"video":"audio");i.putExtra("peerUid",peer.uid);i.putExtra("peerName",peer.username);i.putExtra("peerAvatar",transportAvatar(peer.avatar));startActivity(i);}
     catch(RuntimeException error){ref.update("status","ended","reason","activity_start_failed","endedAt",FieldValue.serverTimestamp());ActiveCallRegistry.release(me.uid,ref.getId());toast("تعذر فتح شاشة الاتصال. أعد المحاولة.");}
    }).addOnFailureListener(e->{ActiveCallRegistry.release(me.uid,ref.getId());toast("تعذر إنشاء المكالمة: "+Errors.text(e));}).addOnCompleteListener(t->callStarting=false);
   }
   @Override public void onBusy(){callStarting=false;AppSounds.playHangupTone(getApplicationContext());toast("الشخص في مكالمة أخرى.");}
   @Override public void onError(Exception error){callStarting=false;toast("تعذر التحقق من حالة المكالمة: "+Errors.text(error));}
  });
 }
 private void requestMedia(boolean camera){
  ArrayList<String> permissions=new ArrayList<>();
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)permissions.add(Manifest.permission.RECORD_AUDIO);
  if(camera&&checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)permissions.add(Manifest.permission.CAMERA);
  if(!permissions.isEmpty())requestPermissions(permissions.toArray(new String[0]),REQ_MEDIA);
 }
 private void requestNotifications(){
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFY);return;}
  verifyNotificationSettings();
 }
 private void verifyNotificationSettings(){
  NotificationManager manager=getSystemService(NotificationManager.class);
  if(manager==null)return;
  if(!manager.areNotificationsEnabled()){
   showNotificationSettingsPrompt("الإشعارات متوقفة لهذا التطبيق. فعّلها كي تصلك الرسائل والمكالمات عند إغلاق التطبيق.",false);
   return;
  }
  if(Build.VERSION.SDK_INT>=26){
   NotificationChannel calls=manager.getNotificationChannel(NotificationChannels.selectedCallsChannel(this));
   if(calls!=null&&calls.getImportance()==NotificationManager.IMPORTANCE_NONE){
    showNotificationSettingsPrompt("فئة إشعارات المكالمات متوقفة. فعّلها مع الصوت كي يظهر الاتصال الوارد ويصدر الرنين.",false);
    return;
   }
  }
  if(AppPreferences.useFullScreenCalls(this)&&Build.VERSION.SDK_INT>=34&&!manager.canUseFullScreenIntent())showNotificationSettingsPrompt("اسمح بعرض إشعارات المكالمات بملء الشاشة كي تظهر شاشة المتصل والهاتف مقفل.",true);
 }
 private void showNotificationSettingsPrompt(String message,boolean fullScreen){
  if(notificationPromptShown||isFinishing())return;
  notificationPromptShown=true;
  Intent settingsIntent;
  if(fullScreen&&Build.VERSION.SDK_INT>=34)settingsIntent=new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName()));
  else{settingsIntent=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);settingsIntent.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());}
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle("تفعيل إشعارات بغدادي").setMessage(message).setPositiveButton("فتح الإعدادات",(d,w)->{try{startActivity(settingsIntent);}catch(Exception ignored){startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}}).setNegativeButton("لاحقًا",null).create();
  dialog.setOnDismissListener(d->notificationPromptShown=false);
  dialog.show();
 }
 @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
  super.onRequestPermissionsResult(requestCode,permissions,results);
  if(requestCode==REQ_NOTIFY){
   if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)verifyNotificationSettings();
   else showNotificationSettingsPrompt("بدون إذن الإشعارات لن تظهر الرسائل أو المكالمات عند إغلاق التطبيق.",false);
   return;
  }
  if(requestCode==REQ_SAVE){
   boolean granted=Build.VERSION.SDK_INT>=29||(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED);
   String source=pendingImageSource;pendingImageSource=null;if(granted&&source!=null)saveImageToGallery(source);else if(!granted)toast("تعذر الحفظ بدون صلاحية التخزين.");return;
  }
  if(requestCode!=REQ_MEDIA)return;
  boolean granted=results.length>0;
  for(int result:results)granted&=result==PackageManager.PERMISSION_GRANTED;
  int requestedCall=pendingCallType;
  pendingCallType=0;
  if(!granted){toast("امنح الميكروفون/الكاميرا من إعدادات Android ثم أعد المحاولة.");return;}
  if(requestedCall!=0)handler.post(()->startCall(requestedCall==2));
  else toast("تم منح صلاحية الميكروفون — اضغط باستمرار للتسجيل.");
 }
 private void pickFile(){Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.setType("*/*");intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*","application/pdf","application/zip"});intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(intent,REQ_FILE);}
 private void pickAvatar(boolean forProfile){avatarForProfile=forProfile;Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.setType("image/*");intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(intent,REQ_AVATAR);}
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
  super.onActivityResult(requestCode,resultCode,data);
  if(requestCode==BiometricGate.REQUEST_DEVICE_CREDENTIAL){if(resultCode==RESULT_OK){biometricUnlocked=true;FirebaseUser user=auth.getCurrentUser();if(user!=null){if(me==null)loadProfile(user);else getPreferences(MODE_PRIVATE).edit().putBoolean("biometric_lock",true).apply();}}return;}
  if(resultCode!=RESULT_OK||data==null)return;
  if(requestCode==REQ_AVATAR){Uri uri=data.getData();if(uri!=null)encodeAvatar(uri,avatarForProfile);return;}
  if(requestCode!=REQ_FILE)return;
  int count=data.getClipData()!=null?data.getClipData().getItemCount():1;
  for(int index=0;index<count;index++){Uri uri=data.getClipData()!=null?data.getClipData().getItemAt(index).getUri():data.getData();if(uri!=null)uploadFile(uri);}
 }
 private void encodeAvatar(Uri uri,boolean updateProfile){
  toast("جارٍ تجهيز الصورة…");
  new Thread(()->{try{Base64ImageCodec.EncodedImage encoded=Base64ImageCodec.encode(this,uri,480,115000);handler.post(()->{if(isFinishing())return;if(updateProfile&&me!=null){fs.collection("users").document(me.uid).update("avatar",encoded.dataUrl,"updatedAt",FieldValue.serverTimestamp()).addOnSuccessListener(unused->{me.avatar=encoded.dataUrl;profileCache.put(me.uid,me);if(profileAvatarView!=null)loadAvatar(profileAvatarView,me.avatar);toast("تم تحديث الصورة الشخصية ✓");}).addOnFailureListener(error->toast("تعذر حفظ الصورة: "+Errors.text(error)));}else{pendingAvatarData=encoded.dataUrl;if(avatarPreview!=null)loadAvatar(avatarPreview,pendingAvatarData);toast("تم اختيار الصورة ✓");}});}catch(Exception error){handler.post(()->toast("تعذر تجهيز الصورة. اختر صورة أخرى."));}},"BaghdadiAvatarEncoder").start();
 }
 private void uploadFile(Uri uri){
  try{
   String detected=getContentResolver().getType(uri);final String mime=detected==null?"application/octet-stream":detected;String path=uri.getLastPathSegment();final String name=path==null?"file":path;
   if(mime.startsWith("image/")){sendImageBase64(uri,name);return;}
   final String targetChat=chatId;final String targetPeer=peer==null?null:peer.uid;StorageReference reference=FirebaseCore.storage().getReference().child("chatFiles").child(targetChat).child(me.uid).child(System.currentTimeMillis()+"_"+name.replaceAll("[^A-Za-z0-9._-]","_"));
   reference.putFile(uri).continueWithTask(task->{if(!task.isSuccessful())throw task.getException();return reference.getDownloadUrl();}).addOnSuccessListener(url->{String type=mime.startsWith("video/")?"video":"file";String preview="video".equals(type)?"🎬 فيديو":"📎 ملف";Map<String,Object> message=new HashMap<>();message.put("senderId",me.uid);message.put("type",type);message.put("url",url.toString());message.put("name",name);message.put("mime",mime);sendMessage(message,preview,()->toast("تم إرسال المرفق ✓"));}).addOnFailureListener(error->toast("تعذر رفع الملف. الصور فقط لا تحتاج إلى Storage."));
  }catch(Exception error){toast("تعذر قراءة الملف: "+Errors.text(error));}
 }
 private void sendImageBase64(Uri uri,String name){
  final String targetChat=chatId,targetPeer=peer==null?null:peer.uid,sender=me==null?null:me.uid,capturedReplyId=replyToId,capturedReplyText=replyToText;
  toast("جارٍ ضغط الصورة…");
  new Thread(()->{try{Base64ImageCodec.EncodedImage encoded=Base64ImageCodec.encode(this,uri,1440,500000);handler.post(()->{if(targetChat==null||sender==null)return;Map<String,Object> message=new HashMap<>();message.put("senderId",sender);message.put("type","image");message.put("base64",encoded.dataUrl);message.put("encoding","base64");message.put("mime","image/jpeg");message.put("name",safeText(name,"صورة.jpg"));message.put("sizeBytes",encoded.byteCount);message.put("width",encoded.width);message.put("height",encoded.height);sendQueuedMessage(targetChat,targetPeer,message,"🖼 صورة","image",capturedReplyId,capturedReplyText,()->{if(targetChat.equals(chatId)&&Objects.equals(replyToId,capturedReplyId))clearReply();toast("تمت إضافة الصورة إلى قائمة الإرسال ✓");});});}catch(Exception error){handler.post(()->toast("الصورة كبيرة أو غير صالحة. اختر صورة أخرى."));}},"BaghdadiImageEncoder").start();
 }
 private void updateComposerAction(boolean sendMode){
  if(composerActionButton==null||composerSendMode==sendMode)return;composerSendMode=sendMode;composerActionButton.animate().cancel();composerActionButton.setRotation(sendMode?-35f:35f);composerActionButton.animate().rotation(0f).scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start();
  if(sendMode){composerActionButton.setImageResource(R.drawable.ic_send);composerActionButton.setContentDescription("إرسال الرسالة");composerActionButton.setBackground(Ui.gradientRipple());composerActionButton.setOnTouchListener(null);Ui.pressFeedback(composerActionButton);composerActionButton.setOnClickListener(v->sendText());}
  else{composerActionButton.setBackground(Ui.ripple(Ui.bg(Color.TRANSPARENT,24)));configureVoiceButton(composerActionButton);}
 }
 @android.annotation.SuppressLint("ClickableViewAccessibility")
 private void configureVoiceButton(ImageButton mic){
  voiceButton=mic;
  mic.setContentDescription("اضغط باستمرار لتسجيل رسالة صوتية، وارفع إصبعك للإرسال");
  mic.setImageResource(R.drawable.ic_mic_active);
  mic.setOnClickListener(null);
  mic.setOnLongClickListener(null);
  mic.setOnTouchListener((view,event)->{
   int action=event.getActionMasked();
   if(action==MotionEvent.ACTION_DOWN){
    if(view.getParent()!=null)view.getParent().requestDisallowInterceptTouchEvent(true);
    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    view.animate().scaleX(.86f).scaleY(.86f).setDuration(80).start();
    startVoice();
    return true;
   }
   if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){
    if(view.getParent()!=null)view.getParent().requestDisallowInterceptTouchEvent(false);
    view.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
    if(action==MotionEvent.ACTION_UP)view.performClick();
    if(recorder!=null)stopVoice();
    return true;
   }
   return true;
  });
 }

 private void startVoice(){
  if(recorder!=null||voiceStopping)return;
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
   requestMedia(false);
   toast("امنح صلاحية الميكروفون، ثم اضغط باستمرار مرة أخرى.");
   return;
  }
  try{
   voiceFile=new java.io.File(getCacheDir(),"voice_"+System.currentTimeMillis()+".m4a");
   recorder=Build.VERSION.SDK_INT>=31?new MediaRecorder(this):new MediaRecorder();
   recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
   recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
   recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
   recorder.setAudioEncodingBitRate(32000);
   recorder.setAudioSamplingRate(22050);
   recorder.setOutputFile(voiceFile.getAbsolutePath());
   recorder.prepare();
   recorder.start();
   recordStart=System.currentTimeMillis();
   if(voiceButton!=null){
     voiceButton.setImageResource(R.drawable.ic_mic_muted);
   }
   if(voiceStatusView!=null){
    voiceStatusView.setText("● تسجيل 00:00   ▁▂▃   ارفع إصبعك للإرسال");
    voiceStatusView.setVisibility(View.VISIBLE);
    voiceStatusView.setAlpha(0f);
    voiceStatusView.animate().alpha(1f).setDuration(180).start();
   }
   voicePulseLarge=false;
   voicePulse=new Runnable(){
    @Override public void run(){
     if(recorder==null||voiceButton==null)return;
     voicePulseLarge=!voicePulseLarge;
     float scale=voicePulseLarge?1.10f:.92f;
     float alpha=voicePulseLarge?1f:.72f;
     voiceButton.animate().scaleX(scale).scaleY(scale).alpha(alpha).setDuration(360)
      .withEndAction(()->{if(recorder!=null)handler.postDelayed(this,40);}).start();
    }
   };
   handler.post(voicePulse);
   recorder.setOnErrorListener((active,what,extra)->handler.post(()->{
    if(recorder==active){toast("توقف التسجيل بسبب خطأ في الميكروفون.");cancelVoiceRecording();}
   }));
   recordTicker=()->{
    if(recorder!=null){
     long seconds=(System.currentTimeMillis()-recordStart)/1000;
     int amplitude=0;
     try{amplitude=recorder.getMaxAmplitude();}catch(RuntimeException ignored){}
     if(voiceStatusView!=null)voiceStatusView.setText("● تسجيل "+formatTime(seconds*1000)+"   "+amplitudeMeter(amplitude)+"   ارفع للإرسال");
     setTitle("بغدادي • تسجيل "+(seconds/60)+":"+String.format(Locale.US,"%02d",seconds%60));
     handler.postDelayed(recordTicker,250);
    }
   };
   voiceTimeout=()->{
    if(recorder!=null){toast("تم بلوغ الحد الأقصى للتسجيل (90 ثانية).");stopVoice();}
   };
   handler.post(recordTicker);
   handler.postDelayed(voiceTimeout,MAX_VOICE_MS);
  }catch(Exception error){
   cancelVoiceRecording();
   toast("تعذر تشغيل الميكروفون: "+Errors.text(error));
  }
 }

 private void stopVoice(){
  if(recorder==null||voiceStopping)return;
  long duration=System.currentTimeMillis()-recordStart;
  if(duration<MIN_VOICE_MS){
   cancelVoiceRecording();
   toast("استمر بالضغط قليلاً لتسجيل الرسالة.");
   return;
  }
  MediaRecorder active=recorder;
  recorder=null;
  java.io.File file=voiceFile;
  voiceFile=null;
  boolean valid=true;
  try{active.setOnErrorListener(null);active.stop();}catch(RuntimeException error){valid=false;}
  try{active.release();}catch(RuntimeException ignored){}
  clearVoiceUi();
  if(!valid||file==null||!file.exists()||file.length()==0){
   if(file!=null&&file.exists())file.delete();
   toast("لم يكتمل التسجيل. حاول مرة أخرى.");
   return;
  }
  if(file.length()>MAX_VOICE_BYTES){
   file.delete();
   toast("التسجيل أكبر من حد Base64 الآمن. سجّل رسالة أقصر.");
   return;
  }
  final String targetChat=chatId;
  final String sender=me==null?null:me.uid;
  final String capturedReplyId=replyToId;
  final String capturedReplyText=replyToText;
  final long capturedDuration=duration;
  voiceStopping=true;
  new Thread(()->{
   try(java.io.FileInputStream input=new java.io.FileInputStream(file);
       java.io.ByteArrayOutputStream output=new java.io.ByteArrayOutputStream((int)file.length())){
    byte[] buffer=new byte[8192];
    int read;
    while((read=input.read(buffer))!=-1){
     output.write(buffer,0,read);
     if(output.size()>MAX_VOICE_BYTES)throw new java.io.IOException("voice_too_large");
    }
    byte[] bytes=output.toByteArray();
    String encoded=android.util.Base64.encodeToString(bytes,android.util.Base64.NO_WRAP);
    handler.post(()->sendVoiceBase64(targetChat,sender,encoded,bytes.length,capturedDuration,capturedReplyId,capturedReplyText));
   }catch(Exception error){
    handler.post(()->{voiceStopping=false;toast("تعذر تجهيز التسجيل للإرسال.");});
   }finally{
    if(file.exists())file.delete();
   }
  },"BaghdadiVoiceEncoder").start();
 }

 private void sendVoiceBase64(String targetChat,String sender,String encoded,int byteCount,long duration,String capturedReplyId,String capturedReplyText){
  voiceStopping=false;
  if(targetChat==null||sender==null||encoded==null||encoded.length()>850000){toast("تعذر إرسال التسجيل بأمان.");return;}
  Map<String,Object> message=new HashMap<>();message.put("senderId",sender);message.put("type","audio");message.put("base64",encoded);message.put("encoding","base64");message.put("mime","audio/mp4");message.put("name","رسالة صوتية.m4a");message.put("durationMs",duration);message.put("sizeBytes",byteCount);
  sendQueuedMessage(targetChat,peerUidForChat(targetChat),message,"🎙 رسالة صوتية","audio",capturedReplyId,capturedReplyText,()->{if(targetChat.equals(chatId)&&Objects.equals(replyToId,capturedReplyId))clearReply();toast("تمت إضافة الرسالة الصوتية إلى قائمة الإرسال ✓");});
 }
 private String peerUidForChat(String targetChat){
  if(targetChat!=null&&targetChat.equals(chatId)&&peer!=null)return peer.uid;
  for(ChatModel item:chats)if(targetChat!=null&&targetChat.equals(item.id))return item.peerUid;
  return null;
 }

 private void cancelVoiceRecording(){
  MediaRecorder active=recorder;
  recorder=null;
  if(active!=null){
   try{active.setOnErrorListener(null);active.stop();}catch(RuntimeException ignored){}
   try{active.release();}catch(RuntimeException ignored){}
  }
  java.io.File file=voiceFile;
  voiceFile=null;
  if(file!=null&&file.exists())file.delete();
  voiceStopping=false;
  clearVoiceUi();
 }

 private void clearVoiceUi(){
  if(recordTicker!=null)handler.removeCallbacks(recordTicker);
  if(voiceTimeout!=null)handler.removeCallbacks(voiceTimeout);
  if(voicePulse!=null)handler.removeCallbacks(voicePulse);
  recordTicker=null;
  voiceTimeout=null;
  voicePulse=null;
  setTitle("بغدادي");
  if(voiceStatusView!=null){
   voiceStatusView.animate().alpha(0f).setDuration(140).withEndAction(()->voiceStatusView.setVisibility(View.GONE)).start();
  }
  if(voiceButton!=null){
    voiceButton.setImageResource(R.drawable.ic_mic_active);
   voiceButton.animate().cancel();
   voiceButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).start();
   voiceButton.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
  }
 }

 private String amplitudeMeter(int amplitude){
  final String levels="▁▂▃▄▅▆▇█";
  int level=Math.min(levels.length()-1,Math.max(0,amplitude/4096));
  char active=levels.charAt(level);
  return "▁"+active+"▃"+active+"▁";
 }

 private void playVoiceMessage(DocumentSnapshot message,VoiceMessageView button,long durationMs){
  if(message.getId().equals(activeVoiceMessageId)){
   if(activeVoicePlayer==null){stopActiveVoicePlayback();return;}
   try{
    if(activeVoicePlayer.isPlaying()){
     activeVoicePlayer.pause();
     if(playbackTicker!=null)handler.removeCallbacks(playbackTicker);
    }else{
     activeVoicePlayer.start();
     startPlaybackTicker();
    }
    updateVoicePlaybackButton();
   }catch(RuntimeException error){stopActiveVoicePlayback();toast("تعذر تغيير حالة التشغيل.");}
   return;
  }

  stopActiveVoicePlayback();
  final int requestToken=++voicePlaybackToken;
  activeVoiceMessageId=message.getId();
  activeVoicePlaybackButton=button;
  activeVoiceDurationMs=durationMs;
  button.setState(durationMs,false,false,0,true);

  String encoded=message.getString("base64");
  if(encoded==null||encoded.trim().isEmpty()){
   String url=message.getString("url");
   if(url==null||url.trim().isEmpty()){stopActiveVoicePlayback();toast("التسجيل غير متاح.");return;}
   playAudioSource(url,null,button,durationMs,requestToken);
   return;
  }
  if(encoded.length()>850000){stopActiveVoicePlayback();toast("حجم التسجيل غير صالح.");return;}
  new Thread(()->{
   java.io.File cached=new java.io.File(getCacheDir(),"voice_play_"+message.getId()+"_"+System.nanoTime()+".m4a");
   try(java.io.FileOutputStream output=new java.io.FileOutputStream(cached)){
    output.write(android.util.Base64.decode(encoded,android.util.Base64.DEFAULT));
    handler.post(()->{
     if(isFinishing()||requestToken!=voicePlaybackToken){cached.delete();return;}
     playAudioSource(cached.getAbsolutePath(),cached,button,durationMs,requestToken);
    });
   }catch(Exception error){
    if(cached.exists())cached.delete();
    handler.post(()->{if(requestToken==voicePlaybackToken){stopActiveVoicePlayback();toast("تعذر فك ترميز التسجيل.");}});
   }
  },"BaghdadiVoiceDecoder").start();
 }

 private void playAudioSource(String source,java.io.File temporaryFile,VoiceMessageView button,long durationMs,int requestToken){
  android.media.MediaPlayer player=new android.media.MediaPlayer();
  activeVoicePlayer=player;
  activeVoiceTempFile=temporaryFile;
  try{
   player.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
   player.setDataSource(source);
   player.setOnPreparedListener(prepared->{
    if(requestToken!=voicePlaybackToken){prepared.release();if(temporaryFile!=null)temporaryFile.delete();return;}
    try{
     activeVoiceDurationMs=prepared.getDuration()>0?prepared.getDuration():durationMs;
     prepared.start();
     button.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
     updateVoicePlaybackButton();
     startPlaybackTicker();
    }catch(RuntimeException error){stopActiveVoicePlayback();toast("تعذر تشغيل التسجيل.");}
   });
   player.setOnCompletionListener(completed->{
    if(requestToken==voicePlaybackToken)stopActiveVoicePlayback();
    else{completed.release();if(temporaryFile!=null)temporaryFile.delete();}
   });
   player.setOnErrorListener((failed,what,extra)->{
    if(requestToken==voicePlaybackToken){stopActiveVoicePlayback();toast("تعذر تشغيل التسجيل.");}
    else{failed.release();if(temporaryFile!=null)temporaryFile.delete();}
    return true;
   });
   player.prepareAsync();
  }catch(Exception error){
   try{player.release();}catch(RuntimeException ignored){}
   if(temporaryFile!=null)temporaryFile.delete();
   if(requestToken==voicePlaybackToken){stopActiveVoicePlayback();toast("تعذر تشغيل التسجيل.");}
  }
 }

 private void startPlaybackTicker(){
  if(playbackTicker!=null)handler.removeCallbacks(playbackTicker);
  playbackTicker=new Runnable(){
   @Override public void run(){
    if(activeVoicePlayer==null)return;
    updateVoicePlaybackButton();
    try{if(activeVoicePlayer.isPlaying())handler.postDelayed(this,250);}catch(RuntimeException ignored){}
   }
  };
  handler.post(playbackTicker);
 }

 private void updateVoicePlaybackButton(){
  if(activeVoicePlaybackButton==null)return;
  boolean playing=false;
  int position=0;
  try{
   if(activeVoicePlayer!=null){playing=activeVoicePlayer.isPlaying();position=Math.max(0,activeVoicePlayer.getCurrentPosition());}
  }catch(RuntimeException ignored){}
  boolean paused=activeVoicePlayer!=null&&!playing&&position>0;
  activeVoicePlaybackButton.setState(activeVoiceDurationMs,playing,paused,position,false);
 }

 private String voicePlaybackLabel(long durationMs,boolean playing,boolean paused,long positionMs){
  if(playing)return "⏸ تعمل  "+formatTime(positionMs)+" / "+formatTime(durationMs);
  if(paused)return "▶ متوقفة  "+formatTime(positionMs)+" / "+formatTime(durationMs);
  return "▶ تشغيل البصمة  ·  "+formatTime(durationMs);
 }

 private String formatTime(long milliseconds){
  long seconds=Math.max(0,milliseconds)/1000;
  return String.format(Locale.US,"%02d:%02d",seconds/60,seconds%60);
 }

 private void stopActiveVoicePlayback(){
  voicePlaybackToken++;
  if(playbackTicker!=null)handler.removeCallbacks(playbackTicker);
  playbackTicker=null;
  android.media.MediaPlayer player=activeVoicePlayer;
  activeVoicePlayer=null;
  if(player!=null){
   try{player.setOnPreparedListener(null);player.setOnCompletionListener(null);player.setOnErrorListener(null);player.stop();}catch(RuntimeException ignored){}
   try{player.release();}catch(RuntimeException ignored){}
  }
  if(activeVoiceTempFile!=null&&activeVoiceTempFile.exists())activeVoiceTempFile.delete();
  activeVoiceTempFile=null;
  if(activeVoicePlaybackButton!=null){
   activeVoicePlaybackButton.setState(activeVoiceDurationMs,false,false,0,false);
  }
  activeVoicePlaybackButton=null;
  activeVoiceMessageId=null;
  activeVoiceDurationMs=0;
 }
 private void openProfile(){
  clearListeners();inConversation=false;inProfile=true;base();
  LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(Ui.dp(this,6),Ui.dp(this,4),Ui.dp(this,6),Ui.dp(this,4));top.setBackground(Ui.elevatedPanel(22));ImageButton back=Ui.imageButton(this,R.drawable.ic_back,"العودة",PANEL2,16);top.addView(back,new LinearLayout.LayoutParams(Ui.dp(this,46),Ui.dp(this,46)));TextView heading=Ui.text(this,"الملف الشخصي",22,TEXT);heading.setTypeface(null,android.graphics.Typeface.BOLD);heading.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);top.addView(heading,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1));root.addView(top);
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setGravity(Gravity.CENTER_HORIZONTAL);page.setPadding(Ui.dp(this,12),Ui.dp(this,22),Ui.dp(this,12),Ui.dp(this,24));scroll.addView(page);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  FrameLayout avatarStage=new FrameLayout(this);View glow=new View(this);glow.setBackground(Ui.gradientCircle());glow.setAlpha(.26f);avatarStage.addView(glow,new FrameLayout.LayoutParams(Ui.dp(this,142),Ui.dp(this,142),Gravity.CENTER));profileAvatarView=new ImageView(this);profileAvatarView.setScaleType(ImageView.ScaleType.CENTER_CROP);profileAvatarView.setClipToOutline(true);profileAvatarView.setBackground(Ui.gradientCircle());FrameLayout.LayoutParams avatarParams=new FrameLayout.LayoutParams(Ui.dp(this,116),Ui.dp(this,116),Gravity.CENTER);avatarStage.addView(profileAvatarView,avatarParams);loadAvatar(profileAvatarView,me==null?AV:me.avatar);page.addView(avatarStage,new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,150)));
  Button changeAvatar=Ui.button(this,"تغيير الصورة الشخصية");changeAvatar.setTextColor(Color.rgb(196,181,253));changeAvatar.setBackground(Ui.ripple(Ui.bg(Color.TRANSPARENT,15)));page.addView(changeAvatar,new LinearLayout.LayoutParams(-2,Ui.dp(this,44)));
  TextView username=Ui.text(this,"@"+(me==null?"":me.username),27,TEXT);username.setTypeface(null,android.graphics.Typeface.BOLD);username.setGravity(Gravity.CENTER);page.addView(username,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));TextView connected=Ui.text(this,"●  الحساب متصل ومحمي",13,Color.rgb(74,222,128));connected.setGravity(Gravity.CENTER);connected.setBackground(Ui.outlined(Color.argb(90,17,61,45),Color.argb(110,34,197,94),18));page.addView(connected,new LinearLayout.LayoutParams(Ui.dp(this,210),Ui.dp(this,38)));
  LinearLayout securityCard=new LinearLayout(this);securityCard.setOrientation(LinearLayout.VERTICAL);securityCard.setPadding(Ui.dp(this,18),Ui.dp(this,16),Ui.dp(this,18),Ui.dp(this,16));securityCard.setBackground(Ui.elevatedPanel(22));LinearLayout.LayoutParams cardParams=new LinearLayout.LayoutParams(-1,-2);cardParams.topMargin=Ui.dp(this,24);page.addView(securityCard,cardParams);TextView securityTitle=Ui.text(this,"الخصوصية وصلاحيات الجهاز",18,TEXT);securityTitle.setTypeface(null,android.graphics.Typeface.BOLD);securityCard.addView(securityTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));securityCard.addView(profileStatusRow("الميكروفون",checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED));securityCard.addView(profileStatusRow("الكاميرا",checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED));securityCard.addView(profileStatusRow("الإشعارات",Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED));
  boolean locked=getPreferences(MODE_PRIVATE).getBoolean("biometric_lock",false);Button biometric=primary(locked?"إيقاف القفل بالبصمة":"تفعيل القفل بالبصمة");LinearLayout.LayoutParams actionParams=new LinearLayout.LayoutParams(-1,Ui.dp(this,54));actionParams.topMargin=Ui.dp(this,12);securityCard.addView(biometric,actionParams);Button permissions=Ui.button(this,"إدارة الصلاحيات من إعدادات Android");permissions.setBackground(Ui.ripple(Ui.bg(PANEL2,16)));securityCard.addView(permissions,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
  LinearLayout soundCard=new LinearLayout(this);soundCard.setOrientation(LinearLayout.VERTICAL);soundCard.setPadding(Ui.dp(this,18),Ui.dp(this,16),Ui.dp(this,18),Ui.dp(this,16));soundCard.setBackground(Ui.elevatedPanel(22));LinearLayout.LayoutParams soundCardParams=new LinearLayout.LayoutParams(-1,-2);soundCardParams.topMargin=Ui.dp(this,14);page.addView(soundCard,soundCardParams);TextView soundTitle=Ui.text(this,"أصوات المكالمات والإشعارات",18,TEXT);soundTitle.setTypeface(null,android.graphics.Typeface.BOLD);soundCard.addView(soundTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));TextView soundHint=Ui.text(this,"اختر نغمة الاتصال الوارد. صوت انتظار الطرف الآخر والإشعارات مضبوط تلقائياً.",13,MUTED);soundHint.setPadding(0,0,0,Ui.dp(this,10));soundCard.addView(soundHint,new LinearLayout.LayoutParams(-1,-2));Button chooseRingtone=Ui.button(this,ringtoneButtonLabel());chooseRingtone.setBackground(Ui.ripple(Ui.bg(PANEL2,16)));soundCard.addView(chooseRingtone,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));Button previewRingtone=Ui.button(this,"▶ معاينة النغمة المختارة");previewRingtone.setTextColor(Color.rgb(196,181,253));previewRingtone.setBackground(Ui.ripple(Ui.bg(Color.TRANSPARENT,16)));soundCard.addView(previewRingtone,new LinearLayout.LayoutParams(-1,Ui.dp(this,50)));
  LinearLayout notificationCard=new LinearLayout(this);notificationCard.setOrientation(LinearLayout.VERTICAL);notificationCard.setPadding(Ui.dp(this,18),Ui.dp(this,16),Ui.dp(this,18),Ui.dp(this,16));notificationCard.setBackground(Ui.elevatedPanel(22));LinearLayout.LayoutParams notificationParams=new LinearLayout.LayoutParams(-1,-2);notificationParams.topMargin=Ui.dp(this,14);page.addView(notificationCard,notificationParams);TextView notificationTitle=Ui.text(this,"الإشعارات والعمل في الخلفية",18,TEXT);notificationTitle.setTypeface(null,android.graphics.Typeface.BOLD);notificationCard.addView(notificationTitle,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));
  android.widget.Switch contentSwitch=new android.widget.Switch(this);contentSwitch.setText("إظهار محتوى الرسالة في الإشعار");contentSwitch.setTextColor(TEXT);contentSwitch.setChecked(AppPreferences.showNotificationContent(this));notificationCard.addView(contentSwitch,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));
  android.widget.Switch fullScreenSwitch=new android.widget.Switch(this);fullScreenSwitch.setText("فتح شاشة الاتصال الوارد بملء الشاشة");fullScreenSwitch.setTextColor(TEXT);fullScreenSwitch.setChecked(AppPreferences.useFullScreenCalls(this));notificationCard.addView(fullScreenSwitch,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));
  TextView powerState=Ui.text(this,PowerManagement.isIgnoringOptimizations(this)?"البطارية: غير مقيّد ✓":"البطارية: مقيّد — قد تتأخر بعض التنبيهات",13,PowerManagement.isIgnoringOptimizations(this)?Color.rgb(74,222,128):Color.rgb(251,146,60));notificationCard.addView(powerState,new LinearLayout.LayoutParams(-1,Ui.dp(this,42)));Button batteryButton=Ui.button(this,PowerManagement.isIgnoringOptimizations(this)?"فتح إعدادات عمل التطبيق":"السماح بالعمل دون تقييد البطارية");batteryButton.setBackground(Ui.ripple(Ui.bg(PANEL2,16)));notificationCard.addView(batteryButton,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));
  Button logout=Ui.button(this,"تسجيل الخروج");logout.setTextColor(Color.rgb(255,228,230));logout.setBackground(Ui.ripple(Ui.outlined(Color.rgb(68,20,35),Color.rgb(159,45,68),18)));LinearLayout.LayoutParams logoutParams=new LinearLayout.LayoutParams(-1,Ui.dp(this,56));logoutParams.topMargin=Ui.dp(this,18);page.addView(logout,logoutParams);
  back.setOnClickListener(v->showHome());
  changeAvatar.setOnClickListener(v->pickAvatar(true));
  profileAvatarView.setOnClickListener(v->pickAvatar(true));
  permissions.setOnClickListener(v->startActivity(new Intent(
          Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))));
  chooseRingtone.setOnClickListener(v->showRingtonePicker(chooseRingtone));
  previewRingtone.setOnClickListener(v->{AppSounds.previewSelectedRingtone(this);toast("تشغيل معاينة لمدة قصيرة…");});
  contentSwitch.setOnCheckedChangeListener((button,checked)->{AppPreferences.setShowNotificationContent(this,checked);NotificationChannels.ensureAll(this);toast(checked?"سيظهر محتوى الرسائل في الإشعارات.":"سيتم إخفاء محتوى الرسائل من الإشعارات.");});
  fullScreenSwitch.setOnCheckedChangeListener((button,checked)->{AppPreferences.setUseFullScreenCalls(this,checked);NotificationChannels.ensureAll(this);if(checked&&Build.VERSION.SDK_INT>=34){NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null&&!manager.canUseFullScreenIntent())showNotificationSettingsPrompt("اسمح لبغدادي بعرض إشعارات المكالمات بملء الشاشة.",true);}toast(checked?"تم تفعيل شاشة الاتصال الكاملة.":"ستظهر المكالمات كإشعار علوي فقط.");});
  batteryButton.setOnClickListener(v->{if(PowerManagement.isIgnoringOptimizations(this))PowerManagement.openBackgroundSettings(this);else PowerManagement.requestIgnoreOptimizations(this);});
  biometric.setOnClickListener(v->{boolean nowLocked=getPreferences(MODE_PRIVATE).getBoolean("biometric_lock",false);if(nowLocked){getPreferences(MODE_PRIVATE).edit().putBoolean("biometric_lock",false).apply();biometric.setText("تفعيل القفل بالبصمة");toast("تم إيقاف القفل بالبصمة.");}else if(!BiometricGate.isAvailable(this)){toast("أضف بصمة أو قفل شاشة آمن من إعدادات الجهاز أولاً.");}else BiometricGate.authenticate(this,new BiometricGate.Callback(){public void onSuccess(){biometricUnlocked=true;getPreferences(MODE_PRIVATE).edit().putBoolean("biometric_lock",true).apply();biometric.setText("إيقاف القفل بالبصمة");toast("تم تفعيل القفل بالبصمة ✓");}public void onFailure(String message){toast(message);}});});
  logout.setOnClickListener(v->{if(me==null)return;DeviceRegistry.unregister(this,me.uid);stopPresence();getPreferences(MODE_PRIVATE).edit().putBoolean("biometric_lock",false).apply();auth.signOut();});
  listenIncomingCalls();Ui.enter(top,0);Ui.enter(avatarStage,30);Ui.enter(securityCard,60);
 }
 private void cancelConversationNotification(){if(chatId==null)return;NotificationManager manager=getSystemService(NotificationManager.class);if(manager!=null)manager.cancel(chatId.hashCode());}
 private void promptBatteryOptimizationOnce(){
  if(Build.VERSION.SDK_INT<Build.VERSION_CODES.M||PowerManagement.isIgnoringOptimizations(this))return;
  android.content.SharedPreferences prefs=getSharedPreferences("baghdadi_power_prompt",MODE_PRIVATE);if(prefs.getBoolean("shown_v3",false))return;prefs.edit().putBoolean("shown_v3",true).apply();
  new AlertDialog.Builder(this).setTitle("السماح بالعمل في الخلفية").setMessage("لرفع موثوقية وصول المكالمات والرسائل بعد إغلاق التطبيق، اسمح لبغدادي بالعمل دون تقييد البطارية. القرار النهائي يبقى لنظام Android والشركة المصنّعة.").setPositiveButton("السماح",(d,w)->PowerManagement.requestIgnoreOptimizations(this)).setNegativeButton("لاحقاً",null).show();
 }
 private void showChatThemePicker(){
  if(chatId==null)return;String[] names={"بنفسجي سماوي — افتراضي","أزرق ليلي","أخضر زمردي","وردي بنفسجي","ذهبي داكن","لون مخصص","إعادة الضبط"};
  int[][] colors={{Color.rgb(76,29,149),Color.rgb(8,145,178)},{Color.rgb(30,64,175),Color.rgb(14,116,144)},{Color.rgb(4,120,87),Color.rgb(22,101,52)},{Color.rgb(190,24,93),Color.rgb(109,40,217)},{Color.rgb(180,83,9),Color.rgb(120,53,15)}};
  new AlertDialog.Builder(this).setTitle("ألوان هذه المحادثة").setItems(names,(dialog,which)->{if(which<5){ChatTheme.save(this,chatId,colors[which][0],colors[which][1],which!=4);showConversation();}else if(which==5)showCustomChatTheme();else{ChatTheme.reset(this,chatId);showConversation();}}).show();
 }
 private void showCustomChatTheme(){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(Ui.dp(this,22),Ui.dp(this,8),Ui.dp(this,22),0);EditText first=input("اللون الأول مثل #6D28D9");EditText second=input("اللون الثاني مثل #0891B2");first.setText(String.format(Locale.US,"#%06X",0xFFFFFF&activeChatTheme.first));second.setText(String.format(Locale.US,"#%06X",0xFFFFFF&activeChatTheme.second));android.widget.Switch gradient=new android.widget.Switch(this);gradient.setText("استخدام تدرج لوني");gradient.setTextColor(TEXT);gradient.setChecked(activeChatTheme.gradient);box.addView(first,new LinearLayout.LayoutParams(-1,Ui.dp(this,56)));LinearLayout.LayoutParams secondParams=new LinearLayout.LayoutParams(-1,Ui.dp(this,56));secondParams.topMargin=Ui.dp(this,10);box.addView(second,secondParams);box.addView(gradient,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
  AlertDialog d=new AlertDialog.Builder(this).setTitle("تخصيص ألوان الدردشة").setView(box).setPositiveButton("حفظ",null).setNegativeButton("إلغاء",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{int a=Color.parseColor(first.getText().toString().trim()),b=Color.parseColor(second.getText().toString().trim());ChatTheme.save(this,chatId,a,b,gradient.isChecked());d.dismiss();showConversation();}catch(IllegalArgumentException e){first.setError("أدخل لوناً صحيحاً بصيغة #RRGGBB");}}));d.show();
 }
 private String ringtoneButtonLabel(){return "نغمة الاتصال الوارد: "+AppSounds.selectedRingtoneLabel(this)+"  ›";}
 private void showRingtonePicker(Button target){
  String[] options={"النغمة الاحترافية — افتراضية","النغمة الرسمية"};
  int checked=AppSounds.isOfficialSelected(this)?1:0;
  new AlertDialog.Builder(this).setTitle("اختيار نغمة الرنين").setSingleChoiceItems(options,checked,(dialog,which)->{
   AppSounds.selectRingtone(this,which==1?AppSounds.RINGTONE_OFFICIAL:AppSounds.RINGTONE_PROFESSIONAL);
   NotificationChannels.ensureAll(this);
   target.setText(ringtoneButtonLabel());
   dialog.dismiss();
   AppSounds.previewSelectedRingtone(this);
   toast("تم اعتماد "+AppSounds.selectedRingtoneLabel(this)+" ✓");
  }).setNegativeButton("إلغاء",null).show();
 }
 private LinearLayout profileStatusRow(String label,boolean granted){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView name=Ui.text(this,label,14,TEXT);TextView state=Ui.text(this,granted?"مسموح ✓":"يحتاج تفعيل",12,granted?Color.rgb(74,222,128):Color.rgb(251,146,60));state.setGravity(Gravity.CENTER);row.addView(name,new LinearLayout.LayoutParams(0,Ui.dp(this,38),1));row.addView(state,new LinearLayout.LayoutParams(Ui.dp(this,96),Ui.dp(this,32)));return row;}
 @Override public void onBackPressed(){if(inConversation||inProfile){showHome();}else{super.onBackPressed();}}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 private void clearListeners(){if(chatsReg!=null){chatsReg.remove();chatsReg=null;}if(messagesReg!=null){messagesReg.remove();messagesReg=null;}if(peerReg!=null){peerReg.remove();peerReg=null;}if(peerPresenceListener!=null&&peer!=null){rtdb.getReference("presence").child(peer.uid).removeEventListener(peerPresenceListener);peerPresenceListener=null;}if(typingListenRef!=null&&typingReg!=null){typingListenRef.removeEventListener(typingReg);typingListenRef=null;typingReg=null;}if(typingRef!=null)typingRef.removeValue();typingRef=null;if(incomingReg!=null){incomingReg.remove();incomingReg=null;}if(presenceTicker!=null)handler.removeCallbacks(presenceTicker);presenceTicker=null;if(incomingTypingHide!=null)handler.removeCallbacks(incomingTypingHide);incomingTypingHide=null;if(typingIndicator!=null)typingIndicator.stop();}
}
