# نشر بغدادي للإنتاج

## 1. خدمات Firebase المطلوبة

فعّل Email/Password Authentication وFirestore وRealtime Database وStorage وCloud Messaging في المشروع `chat-d61b6`.

## 2. حساب خدمة الإشعارات

أنشئ حساب خدمة مخصصاً للـWorker ولا تستخدم حساباً شخصياً. امنحه فقط الصلاحيات اللازمة لقراءة مستندات Firestore وإرسال FCM واستهلاك واجهات المشروع. نزّل مفتاح JSON مرة واحدة، ارفعه إلى أسرار Cloudflare كما في الخطوة التالية، ثم خزنه في مكان خاص خارج المستودع.

## 3. نشر Cloudflare Worker المجاني

من داخل `push-relay`:

```bash
npx wrangler login
npx wrangler deploy
npx wrangler secret put GOOGLE_CLIENT_EMAIL
npx wrangler secret put GOOGLE_PRIVATE_KEY
```

ضع قيمة `client_email` من ملف حساب الخدمة في السر الأول، وضع `private_key` كاملاً في الثاني. لا تضعهما في `wrangler.toml` ولا في GitHub. القيمة العامة `GOOGLE_PROJECT_ID` موجودة في `wrangler.toml`.

بعد النشر، ضع رابط Worker في `BAGHDADI_PUSH_RELAY_URL` وقت البناء أو عدّل القيمة الافتراضية في `app/build.gradle`. الرابط الحالي للإصدار الجاهز هو:

```text
https://baghdadi-push.majid2025almu22.workers.dev
```

## 4. نشر قواعد Firebase فقط

```bash
firebase login
firebase use chat-d61b6
firebase deploy --only firestore:rules,firestore:indexes,database,storage
```

لا تضف `functions` إلى أمر النشر في الإعداد المجاني. مجلد `functions/` بديل اختياري فقط، وتشغيله بالتزامن مع Worker قد يكرر الإشعارات.

## 5. TURN للمكالمات المضمونة

أضف خادم TURN يدعم UDP وTCP وTLS، واستخدم بيانات اعتماد قصيرة العمر يولدها خادم موثوق. وجود STUN وحده يكفي لكثير من الشبكات لكنه لا يعبر بعض شبكات CGNAT وSymmetric NAT.

## 6. اختبارات ما قبل النشر

- هاتفان حقيقيان على شبكتين مختلفتين، ومنها بيانات الهاتف.
- مكالمة والطرف المستقبل مغلق التطبيق، ثم تجربة دون إنترنت وإعادته خلال مدة الطلب.
- Android 8 و12 و13 و14 و15 على الأقل، مع قبول ورفض صلاحية الإشعارات.
- إرسال نص وصورة وفيديو وملف، وتسجيل الصوت بالضغط المستمر ثم رفع الإصبع، والتحقق أن حقل `base64` يصل ويعمل على الجهاز الثاني مع تبدل زر التشغيل بين «تعمل» و«متوقفة».
- قفل البصمة، تسجيل الخروج، تدوير الشاشة الرئيسية، وإنهاء المكالمة من الإشعار.
- تسجيل SHA-256 الخاص بمفتاح الإصدار في Firebase إن فُعّلت App Check أو خدمات تتطلبه.
- التحقق من أن الإشعار يصل بعد إزالة التطبيق من الحديثة أو إنهاء عمليته، مع ملاحظة أن «فرض الإيقاف» يمنع Android نفسه من تسليم FCM حتى فتح التطبيق من جديد.
- إنهاء المتصل للمكالمة قبل الرد والتحقق من اختفاء إشعار الرنين لدى الطرف الآخر.
