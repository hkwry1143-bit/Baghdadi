const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();
const db = getFirestore();

async function tokensFor(uid) {
  const devices = await db.collection('users').doc(uid)
    .collection('devices').where('active', '==', true).get();
  const tokens = devices.docs.map((doc) => doc.get('token')).filter(Boolean);
  if (tokens.length) return [...new Set(tokens)].slice(0, 500);
  const legacy = await db.collection('users').doc(uid).get();
  return legacy.get('fcmToken') ? [legacy.get('fcmToken')] : [];
}

async function sendToUser(uid, payload, label) {
  const tokens = await tokensFor(uid);
  if (!tokens.length) {
    console.warn(`${label}: no active notification token for ${uid}`);
    return 0;
  }
  const response = await getMessaging().sendEachForMulticast({
    tokens,
    data: payload,
    android: {
      priority: 'high',
      ttl: label === 'call' ? 60 * 1000 : 28 * 24 * 60 * 60 * 1000
    }
  });
  console.log(`${label}: ${response.successCount}/${tokens.length} notification(s) accepted by FCM`);
  response.responses.forEach((result, index) => {
    if (!result.success) console.warn(`${label}: token ${index} failed`, result.error?.code || 'unknown');
  });
  return response.successCount;
}

exports.notifyIncomingCall = onDocumentCreated('calls/{callId}', async (event) => {
  const snap = event.data;
  if (!snap) return;
  const call = snap.data();
  if (!call || !['waiting', 'preparing'].includes(call.status) || !call.calleeId) return;

  const callerSnap = await db.collection('users').doc(call.callerId).get();
  const caller = callerSnap.data() || {};
  await sendToUser(call.calleeId, {
    kind: 'call',
    callId: snap.id,
    callerId: call.callerId,
    callerName: String(caller.username || 'مستخدم'),
    callerAvatar: /^https:\/\//i.test(String(caller.avatar || '')) && String(caller.avatar || '').length <= 1500
      ? String(caller.avatar) : '',
    type: String(call.type || 'audio')
  }, 'call');
  await snap.ref.update({
    pushSentAt: FieldValue.serverTimestamp()
  });
});

exports.notifyNewMessage = onDocumentCreated(
  'chats/{chatId}/messages/{messageId}',
  async (event) => {
    const snap = event.data;
    if (!snap) return;
    const message = snap.data();
    if (!message || !message.senderId || message.type === 'call') return;

    const chatSnap = await db.collection('chats').doc(event.params.chatId).get();
    if (!chatSnap.exists) return;
    const participants = chatSnap.get('participants') || [];
    const recipients = participants.filter((uid) => uid !== message.senderId);
    if (!recipients.length) return;

    const summaryByType = {
      image: '🖼 صورة', video: '🎬 فيديو', audio: '🎙 رسالة صوتية', file: '📎 ملف'
    };
    const summary = message.type === 'text'
      ? String(message.text || '').slice(0, 180)
      : (summaryByType[message.type] || 'رسالة جديدة');
    const chatUpdate = {
      lastMessage: summary,
      lastMessageType: String(message.type || 'text'),
      lastSenderId: String(message.senderId),
      updatedAt: FieldValue.serverTimestamp()
    };
    recipients.forEach((uid) => {
      chatUpdate[`unread.${uid}`] = FieldValue.increment(1);
    });
    await chatSnap.ref.update(chatUpdate);

    const senderSnap = await db.collection('users').doc(message.senderId).get();
    const senderName = String(senderSnap.get('username') || 'مستخدم');
    const senderAvatarValue = String(senderSnap.get('avatar') || '');
    const senderAvatar = /^https:\/\//i.test(senderAvatarValue) && senderAvatarValue.length <= 1500 ? senderAvatarValue : '';
    await Promise.all(recipients.map(async (uid) => {
      await sendToUser(uid, {
        kind: 'message',
        chatId: event.params.chatId,
        senderId: String(message.senderId),
        senderName,
        senderAvatar,
        messageId: event.params.messageId,
        messageType: String(message.type || 'text'),
        body: summary
      }, 'message');
    }));
  }
);
