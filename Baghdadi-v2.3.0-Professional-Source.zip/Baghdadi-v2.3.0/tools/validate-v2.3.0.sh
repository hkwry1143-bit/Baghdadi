#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./tools/clean-android-resources.sh
node --check push-relay/src/index.js
node --check functions/index.js
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
for path in Path('app/src/main/res').rglob('*.xml'):
    ET.parse(path)
ET.parse('app/src/main/AndroidManifest.xml')
for path in Path('app/src/main/java').rglob('*.java'):
    text=path.read_text(encoding='utf-8')
    assert '.isBlank()' not in text, path
    assert 'Map.of(' not in text, path
print('Static project validation passed.')
PY
